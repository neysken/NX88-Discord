@echo off
setlocal

cd /d "%~dp0"

title ROYAL BACCARAT BOT
color 0A
cls

echo.
echo ============================================================
echo          ROYAL BACCARAT BOT + ANTIRAID V2
echo ============================================================
echo.

:: Kiem tra Node.js
node -v >nul 2>&1
if errorlevel 1 (
    color 0C
    echo [LOI] Chua cai Node.js!
    echo Tai tai: https://nodejs.org
    echo.
    pause
    exit /b
)

for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
echo [OK] Node.js %NODE_VER%

:: Kiem tra token
findstr /i "TOKEN_CUA_BAN_O_DAY" config.json >nul 2>&1
if not errorlevel 1 (
    color 0E
    echo.
    echo [!] Chua dien token vao config.json!
    echo     Mo file config.json va dien token, clientId, guildId vao.
    echo.
    set /p OPEN=Mo config.json ngay bay gio? (y/n): 
    if /i "%OPEN%"=="y" notepad config.json
    echo.
    echo Sau khi luu xong, chay lai start.bat
    pause
    exit /b
)

:: Cai thu vien lan dau neu chua co
if not exist "node_modules\discord.js" (
    echo [INFO] Cai dat thu vien lan dau...
    echo ------------------------------------------------------------
    call npm install
    if errorlevel 1 (
        color 0C
        echo [LOI] npm install that bai!
        pause
        exit /b
    )
    echo.
)

cls
echo.
echo ============================================================
echo          DANG KHOI DONG BOT...
echo ============================================================
echo.
echo Nhan Ctrl+C de dung bot.
echo ------------------------------------------------------------
echo.

node index.js

echo.
color 0C
echo ============================================================
echo          BOT DA DUNG.
echo ============================================================
echo.
pause
