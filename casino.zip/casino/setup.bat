@echo off
setlocal

cd /d "%~dp0"

title ROYAL BACCARAT BOT
color 0A
cls

echo.
echo ============================================================
echo          ROYAL BACCARAT BOT + ANTIRAID V2
echo ============================================================
echo.

node -v >nul 2>&1
if errorlevel 1 (
    color 0C
    echo [LOI] Chua cai Node.js!
    echo Tai tai: https://nodejs.org
    echo.
    pause
    exit /b
)

if not exist "node_modules\discord.js" (
    echo [INFO] Dang cai thu vien lan dau...
    echo ------------------------------------------------------------
    call npm install
    echo.
)

cls
echo.
echo ============================================================
echo          DANG KHOI DONG BOT...
echo ============================================================
echo.
echo Launching Discord Bot + AntiRaid V2...
echo ------------------------------------------------------------
echo.

node index.js

echo.
echo ============================================================
echo          BOT STOPPED / CRASHED
echo ============================================================
echo.
pause