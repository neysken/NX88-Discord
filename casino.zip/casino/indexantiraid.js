'use strict';

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║   ANTI-RAID V2 — Discord Casino Bot Security System             ║
 * ║   Production-Grade | Discord.js v14 | Modular Architecture      ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * USAGE in index.js:
 *   const antiRaidV2 = require('./anti-raid-v2');
 *   antiRaidV2.init(client, options);
 *
 * In interactionCreate:
 *   const handled = await antiRaidV2.handleCommand(interaction);
 *   if (handled) return;
 *
 * REQUIRED INTENTS:
 *   GuildMembers, GuildModeration, GuildWebhooks, MessageContent,
 *   GuildMessages, Guilds
 *
 * BOT PERMISSIONS:
 *   ManageMessages, ModerateMembers, KickMembers, BanMembers,
 *   ManageChannels, ManageRoles, ViewAuditLog, ManageWebhooks,
 *   ReadMessageHistory
 */

const EventHandler  = require('./systems/eventHandler');
const { commandDefs, handleAntiRaidCommands } = require('./commands/antiRaidCommands');
const cfg = require('./config/config');

let _instance = null;

/**
 * Initialize AntiRaid V2.
 * @param {import('discord.js').Client} client
 * @param {object} [options]
 */
function init(client, options = {}) {
  if (_instance) {
    console.warn('[AntiRaid V2] Already initialized.');
    return _instance;
  }

  // Apply runtime config
  _applyOptions(options);

  _instance = new EventHandler(client);
  _instance.register();

  console.log('[AntiRaid V2] ✓ System initialized');
  _logConfig();

  return _instance;
}

/**
 * Handle AntiRaid slash commands. Call inside interactionCreate.
 * Returns true if the command was handled.
 */
async function handleCommand(interaction) {
  if (!_instance) return false;
  const AR_COMMANDS = ['antiraid', 'lockdown', 'unlockdown', 'panic', 'panic-off', 'whitelist', 'logs'];
  if (!AR_COMMANDS.includes(interaction.commandName)) return false;
  try {
    return await handleAntiRaidCommands(interaction, _instance);
  } catch (e) {
    console.error('[AntiRaid V2] handleCommand error:', e.message);
    return false;
  }
}

function getInstance() { return _instance; }
function getCommandDefs() { return commandDefs; }

function destroy() {
  if (_instance) {
    _instance.destroy();
    _instance = null;
    console.log('[AntiRaid V2] Destroyed.');
  }
}

function _applyOptions(opt) {
  if (opt.logChannelId)       cfg.logging.logChannelId = opt.logChannelId;
  if (opt.modLogChannelId)    cfg.logging.modLogChannelId = opt.modLogChannelId;
  if (opt.raidAlertChannelId) cfg.logging.raidAlertChannelId = opt.raidAlertChannelId;
  if (opt.trustedRoles?.length) cfg.security.trustedRoles.push(...opt.trustedRoles);
  if (opt.trustedUsers?.length) cfg.security.trustedUsers.push(...opt.trustedUsers);
  if (opt.staffRoles?.length)   cfg.security.staffRoles.push(...opt.staffRoles);
  if (opt.ownerIds?.length)     cfg.security.ownerIds.push(...opt.ownerIds);
}

function _logConfig() {
  const l = cfg.logging;
  console.log(`[AntiRaid V2] Log: ${l.logChannelId ? '✓' : '✗'} | ModLog: ${l.modLogChannelId ? '✓' : '✗'} | Alert: ${l.raidAlertChannelId ? '✓' : '✗'}`);
  console.log(`[AntiRaid V2] Trusted roles: ${cfg.security.trustedRoles.length} | users: ${cfg.security.trustedUsers.length}`);
}

module.exports = { init, handleCommand, getInstance, getCommandDefs, destroy, config: cfg };
