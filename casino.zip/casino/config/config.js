'use strict';

module.exports = {
  // ─── SPAM THRESHOLDS ──────────────────────────────────────────────────────
  spam: {
    message:   { limit: 6,  window: 4000 },
    burst:     { limit: 12, window: 8000 },
    mention:   { limit: 5,  window: 6000 },
    emoji:     { limit: 20, window: 5000 },
    link:      { limit: 4,  window: 8000 },
    invite:    { limit: 2,  window: 10000 },
    duplicate: { limit: 3,  window: 10000, similarity: 0.80 },
    command:   { limit: 8,  window: 6000 },
    nickname:  { limit: 3,  window: 30000 },
    unicode:   { ratio: 0.6, minLen: 10 },  // % unicode chars in message
    invisible: { enabled: true },           // zero-width / invisible chars
    embed:     { limit: 5,  window: 10000 },
  },

  // ─── RAID THRESHOLDS ─────────────────────────────────────────────────────
  raid: {
    joinSpike:      { limit: 12,  window: 10000 },
    newAccount:     { ageDays: 7 },
    channelCreate:  { limit: 3,   window: 10000 },
    roleCreate:     { limit: 3,   window: 10000 },
    webhookCreate:  { limit: 2,   window: 10000 },
    massDelete:     { limit: 10,  window: 5000  },
    massKick:       { limit: 3,   window: 10000 },
    massBan:        { limit: 3,   window: 10000 },
    permAbuse:      { enabled: true },
    nukeAttempt:    { channelDelete: 2, window: 15000 },
  },

  // ─── ACTIONS ─────────────────────────────────────────────────────────────
  actions: {
    warn:    { threshold: 1 },
    slowmode:{ threshold: 2, seconds: 10 },
    timeout: { threshold: 2, baseSec: 300, maxSec: 86400, escalate: true },
    kick:    { threshold: 5 },
    ban:     { threshold: 7, delMsgDays: 1 },
    lockChannel: { enabled: true, autoUnlockMs: 180000 },
  },

  // ─── LOCKDOWN ─────────────────────────────────────────────────────────────
  lockdown: {
    triggerViolations: 25,  // total server violations → full lockdown
    joinRaidTrigger: true,
    autoUnlockMs: 600000,   // 10 min
    slowmodeSeconds: 30,
  },

  // ─── PANIC MODE ───────────────────────────────────────────────────────────
  panic: {
    maxJoinPerMin: 5,       // in panic: kick anyone joining faster than this
    blockNewAccounts: true,
    notifyOwner: true,
  },

  // ─── BULK DELETE ─────────────────────────────────────────────────────────
  bulkDelete: {
    batchSize: 100,
    delayMs: 1200,
    maxAgeDays: 14,
    concurrentChannels: 5,
  },

  // ─── SMART DETECTION ─────────────────────────────────────────────────────
  smart: {
    altAccountScore: {
      newAccount: 30,      // < 7 days old
      noAvatar: 15,
      defaultUsername: 10,
      noRoles5min: 10,
    },
    suspiciousScore: 50,  // threshold to flag as suspicious
    maliciousLinks: [
      /discord\.gift/i, /discordnitro\.gift/i, /free-nitro/i,
      /nitro-generator/i, /steamcommunity\.ru/i, /discord-gifts?\./i,
      /claimnitro/i, /getnitro/i, /crypto-?giveaway/i, /airdrop.*token/i,
    ],
    scamDomains: [
      'discordapp.gift', 'discord.gg.to', 'discordd.com',
      'steamcommunity.ru', 'discord-nitro.ru',
    ],
  },

  // ─── SECURITY ─────────────────────────────────────────────────────────────
  security: {
    immunePermissions: ['Administrator', 'ManageGuild'],
    trustedRoles: [],    // populated at runtime from config.json
    trustedUsers: [],
    staffRoles: [],
    ownerIds: [],
  },

  // ─── LOGGING ──────────────────────────────────────────────────────────────
  logging: {
    enabled: true,
    logChannelId: null,
    modLogChannelId: null,
    raidAlertChannelId: null,
    flushIntervalMs: 1500,
    maxQueueSize: 50,
    colors: {
      warn:     0xFFA500,
      timeout:  0xFF6600,
      kick:     0xFF3300,
      ban:      0xFF0000,
      raid:     0x8B0000,
      lockdown: 0x4B0082,
      panic:    0x000000,
      info:     0x00AAFF,
      resolved: 0x00FF88,
      nuke:     0xDC143C,
    },
  },

  // ─── PERFORMANCE ──────────────────────────────────────────────────────────
  performance: {
    cacheCleanupMs: 60000,
    maxCacheEntries: 15000,
    gcThreshold: 12000,
    rateLimitBufferMs: 250,
    maxEventQueueSize: 500,
  },

  // ─── WEBHOOK DEFENSE ─────────────────────────────────────────────────────
  webhook: {
    autoDisableOnRaid: true,
    auditCheckDelaySec: 3,
    maxWebhooksPerChannel: 3,
  },
};
