const {
  REST,
  Routes,
  SlashCommandBuilder,
  PermissionFlagsBits
} = require("discord.js");

const config = require("./config.json");

// ===== DEPLOY COMMANDS =====
// Chạy: node deploy.js
// config.json cần có: token, clientId, guildId

const commands = [

  // ===== NẠP =====
  new SlashCommandBuilder()
    .setName("nap")
    .setDescription("Nạp tiền cho người chơi")
    .addUserOption(o =>
      o.setName("user").setDescription("Người dùng").setRequired(true)
    )
    .addStringOption(o =>
      o.setName("amount").setDescription("Số tiền (VD: 250m, 1b, 500k)").setRequired(true)
    ),

  // ===== RÚT =====
  new SlashCommandBuilder()
    .setName("rut")
    .setDescription("Rút tiền của người chơi")
    .addUserOption(o =>
      o.setName("user").setDescription("Người dùng").setRequired(true)
    )
    .addStringOption(o =>
      o.setName("amount").setDescription("Số tiền (VD: 250m, 1b, 500k)").setRequired(true)
    ),

  // ===== ĐẶT CƯỢC BACCARAT =====
  new SlashCommandBuilder()
    .setName("dat")
    .setDescription("Đặt cược Baccarat")
    .addStringOption(o =>
      o.setName("type").setDescription("PLAYER hoặc BANKER").setRequired(true)
        .addChoices(
          { name: "PLAYER", value: "PLAYER" },
          { name: "BANKER", value: "BANKER" }
        )
    )
    .addStringOption(o =>
      o.setName("amount").setDescription("Số tiền cược (VD: 50m, 1b, 500k)").setRequired(true)
    ),

  // ===== HOÀN TRẢ =====
  new SlashCommandBuilder()
    .setName("hoantra")
    .setDescription("Nhận hoàn trả VIP"),

  // ===== VIP =====
  new SlashCommandBuilder()
    .setName("vip")
    .setDescription("Xem thông tin VIP")
    .addUserOption(o =>
      o.setName("user").setDescription("Người chơi (để trống = chính mình)").setRequired(false)
    ),

  // ===== KẾT QUẢ =====
  new SlashCommandBuilder()
    .setName("ketqua")
    .setDescription("Đóng cược & chọn kết quả Baccarat (Admin)"),

  // ===== BẮT ĐẦU =====
  new SlashCommandBuilder()
    .setName("batdau")
    .setDescription("Mở phiên cược Baccarat mới (Admin)"),

  // ===== SỐ DƯ =====
  new SlashCommandBuilder()
    .setName("sodu")
    .setDescription("Top 10 đại gia giàu nhất"),

  // ===== QUAY HŨ =====
  new SlashCommandBuilder()
    .setName("quayhu")
    .setDescription("Quay hũ may mắn AI Casino")
    .addStringOption(o =>
      o.setName("amount").setDescription("Tiền cược mỗi vòng (VD: 50m, 1b, 500k)").setRequired(true)
    )
    .addIntegerOption(o =>
      o.setName("spin").setDescription("Số vòng quay (tối đa 10)").setRequired(false).setMinValue(1).setMaxValue(10)
    ),

  // ===== KÉO BÚA BAO =====
  new SlashCommandBuilder()
    .setName("keobuabao")
    .setDescription("Kéo búa bao PvP")
    .addUserOption(o =>
      o.setName("user").setDescription("Đối thủ").setRequired(true)
    )
    .addStringOption(o =>
      o.setName("tien").setDescription("Tiền cược (VD: 50m, 1b, 500k)").setRequired(true)
    ),

  // ===== GIỚI THIỆU =====
  new SlashCommandBuilder()
    .setName("gioithieu")
    .setDescription("Gửi yêu cầu referral cho người giới thiệu bạn")
    .addUserOption(o =>
      o.setName("user").setDescription("Người giới thiệu (inviter)").setRequired(true)
    ),

  // ===== NHẬN THƯỞNG REFERRAL =====
  new SlashCommandBuilder()
    .setName("gioithieunhan")
    .setDescription("Nhận hoa hồng referral tích lũy"),

  // ===== THỐNG KÊ REFERRAL =====
  new SlashCommandBuilder()
    .setName("gioithieuinfo")
    .setDescription("Xem thống kê referral")
    .addUserOption(o =>
      o.setName("user").setDescription("Người chơi (để trống = chính mình)").setRequired(false)
    ),

  // ===== ĐÁ GÀ =====
  new SlashCommandBuilder()
    .setName("ga")
    .setDescription("🐔 Hệ thống đá gà casino")

    // /ga kho
    .addSubcommand(sub =>
      sub.setName("kho").setDescription("📦 Xem kho gà của bạn")
    )

    // /ga info — Bot tự hiện Select Menu chọn gà
    .addSubcommand(sub =>
      sub.setName("info").setDescription("📋 Xem chi tiết một con gà")
    )

    // /ga muatrung
    .addSubcommand(sub =>
      sub.setName("muatrung").setDescription("🥚 Mua trứng để nhận gà ngẫu nhiên")
    )

    // /ga nangcap — Bot tự hiện Select Menu chọn gà
    .addSubcommand(sub =>
      sub.setName("nangcap").setDescription("⬆️ Nâng cấp level gà")
    )

    // /ga nangdo — Bot tự hiện Select Menu chọn gà
    .addSubcommand(sub =>
      sub.setName("nangdo").setDescription("⚒️ Nâng độ gà (+N, vô hạn)")
    )

    // /ga choan — Bot tự hiện Select Menu chọn gà
    .addSubcommand(sub =>
      sub.setName("choan").setDescription("🍗 Cho gà ăn miễn phí (giảm 20 đói)")
    )

    // /ga muadoan
    .addSubcommand(sub =>
      sub.setName("muadoan").setDescription("🛒 Mua đồ ăn cho gà")
    )

    // /ga doan — Bot hiện 2 menu liên tiếp: chọn đồ ăn → chọn gà
    .addSubcommand(sub =>
      sub.setName("doan").setDescription("🍗 Dùng đồ ăn cho gà")
    )

    // /ga muaskill
    .addSubcommand(sub =>
      sub.setName("muaskill").setDescription("📚 Mua sách skill ngẫu nhiên")
    )

    // /ga hochoi — Bot hiện 2 menu liên tiếp: chọn gà → chọn skill
    .addSubcommand(sub =>
      sub.setName("hochoi").setDescription("📖 Dạy gà học một skill")
    )

    // /ga sell — Bot tự hiện Select Menu chọn gà
    .addSubcommand(sub =>
      sub.setName("sell").setDescription("💰 Bán gà lấy tiền")
    )

    // /ga top
    .addSubcommand(sub =>
      sub.setName("top").setDescription("📊 Bảng xếp hạng chiến kê")
    )

    // /ga epskill
    .addSubcommand(sub =>
      sub.setName("epskill").setDescription("⚗️ Ép 2 sách chiêu thức để ra chiêu mạnh hơn")
    )

    // /ga daga — user + tien giữ nguyên; gà được chọn bằng Select Menu sau khi accept
    .addSubcommand(sub =>
      sub
        .setName("daga")
        .setDescription("⚔️ Thách đấu gà PvP")
        .addUserOption(o =>
          o.setName("user").setDescription("Đối thủ").setRequired(true)
        )
        .addIntegerOption(o =>
          o.setName("tien").setDescription("Tiền cược (VD: 50m, 1b, 500k)").setRequired(true)
        )
    )

    // /ga choban — chỉ cần gia; gà được chọn bằng Select Menu
    .addSubcommand(sub =>
      sub.setName("choban").setDescription("🏪 Đăng bán gà lên chợ người chơi")
        .addIntegerOption(o =>
          o.setName("gia").setDescription("Giá bán (số tiền)").setRequired(true).setMinValue(1000)
        )
    )

    // /ga choxem
    .addSubcommand(sub =>
      sub.setName("choxem").setDescription("🔍 Xem chợ gà người chơi")
    )

    // /ga chohuy
    .addSubcommand(sub =>
      sub.setName("chohuy").setDescription("❌ Hủy đăng bán gà")
    )

    // /ga chotop
    .addSubcommand(sub =>
      sub.setName("chotop").setDescription("🏆 Top gà lực chiến cao nhất trong chợ")
    ),

  // ===== HỒNG BAO =====
  new SlashCommandBuilder()
    .setName("hongbao")
    .setDescription("🧧 Tạo hồng bao may mắn cho mọi người")
    .addStringOption(o =>
      o.setName("sotien").setDescription("Tổng số tiền hồng bao (VD: 50m, 1b, 500k)").setRequired(true)
    )
    .addIntegerOption(o =>
      o.setName("soluong").setDescription("Số người được nhận (tối đa 200)").setRequired(true).setMinValue(1).setMaxValue(200)
    ),


  // ===== CLEAR =====
  new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Xóa tin nhắn trong kênh (Admin)")
    .addIntegerOption(o =>
      o.setName("soluong").setDescription("Số tin nhắn cần xóa (1-1000)").setRequired(true).setMinValue(1).setMaxValue(1000)
    )
    .addStringOption(o =>
      o.setName("users").setDescription("Chỉ xóa của user này (nhập ID, cách nhau bằng dấu phẩy)").setRequired(false)
    ),


  // ===== ANTI-RAID V2 =====
  new SlashCommandBuilder()
    .setName("antiraid")
    .setDescription("🛡️ Quản lý hệ thống Anti-Raid V2")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName("on").setDescription("Bật Anti-Raid"))
    .addSubcommand(s => s.setName("off").setDescription("Tắt Anti-Raid"))
    .addSubcommand(s => s.setName("status").setDescription("Xem trạng thái hệ thống")),

  new SlashCommandBuilder()
    .setName("lockdown")
    .setDescription("🔒 Lockdown toàn bộ server ngay lập tức")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("unlockdown")
    .setDescription("🔓 Mở khóa server")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("panic")
    .setDescription("🚨 Kích hoạt PANIC MODE - bảo vệ tối đa")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("panic-off")
    .setDescription("✅ Tắt Panic Mode")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("whitelist")
    .setDescription("✅ Quản lý danh sách miễn trừ Anti-Raid")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s =>
      s.setName("add-user").setDescription("Thêm user vào whitelist")
        .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    )
    .addSubcommand(s =>
      s.setName("remove-user").setDescription("Xóa user khỏi whitelist")
        .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    )
    .addSubcommand(s =>
      s.setName("add-role").setDescription("Thêm role vào whitelist")
        .addRoleOption(o => o.setName("role").setDescription("Role").setRequired(true))
    )
    .addSubcommand(s =>
      s.setName("remove-role").setDescription("Xóa role khỏi whitelist")
        .addRoleOption(o => o.setName("role").setDescription("Role").setRequired(true))
    )
    .addSubcommand(s => s.setName("list").setDescription("Xem danh sách whitelist")),

  new SlashCommandBuilder()
    .setName("logs")
    .setDescription("📋 Xem log Anti-Raid của user")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(o => o.setName("user").setDescription("User cần xem log").setRequired(false)),


  // ===== ANTI-LINK =====
  new SlashCommandBuilder()
    .setName("antilink")
    .setDescription("Quan ly he thong chong link")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName("on").setDescription("Bat Anti-Link"))
    .addSubcommand(s => s.setName("off").setDescription("Tat Anti-Link"))
    .addSubcommand(s => s.setName("status").setDescription("Xem trang thai Anti-Link"))
    .addSubcommand(s =>
      s.setName("whitelist-channel")
        .setDescription("Them/xoa kenh khoi whitelist")
        .addChannelOption(o => o.setName("channel").setDescription("Kenh").setRequired(true))
        .addBooleanOption(o => o.setName("add").setDescription("true=them, false=xoa").setRequired(false))
    )
    .addSubcommand(s =>
      s.setName("whitelist-role")
        .setDescription("Them/xoa role khoi whitelist")
        .addRoleOption(o => o.setName("role").setDescription("Role").setRequired(true))
        .addBooleanOption(o => o.setName("add").setDescription("true=them, false=xoa").setRequired(false))
    ),

  // ===== PANEL ADMIN =====
  new SlashCommandBuilder()
    .setName("paneladmin")
    .setDescription("🛡️ Panel quản trị Admin")

].map(x => x.toJSON());

// ===== REST =====
const rest = new REST({ version: "10" }).setToken(config.token);

// ===== DEPLOY =====
(async () => {
  try {
    console.log(`⏳ Đang deploy ${commands.length} slash commands...`);

    await rest.put(
      Routes.applicationGuildCommands(config.clientId, config.guildId),
      { body: commands }
    );

    console.log("✅ Deploy thành công!");
    process.exit(0);

  } catch (err) {
    console.error("❌ Deploy lỗi:");
    console.error(err);
    process.exit(1);
  }
})();