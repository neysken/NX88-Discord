'use strict';

/**
 * ╔══════════════════════════════════════════════════════╗
 * ║   ANTI-LINK SYSTEM — Discord Casino Bot             ║
 * ║   Production-Grade | Discord.js v14                 ║
 * ╚══════════════════════════════════════════════════════╝
 */

const { PermissionFlagsBits, EmbedBuilder } = require('discord.js');

// ─── CONFIG ───────────────────────────────────────────────────────────────────
const cfg = {
  enabled: true,

  // Số lần gửi link trước khi bị timeout
  warnLimit: 2,      // warn sau N lần
  timeoutLimit: 3,   // timeout sau N lần
  timeoutDuration: 300, // seconds (5 phút)
  trackWindow: 60000,   // reset count sau 60s

  // Whitelist channel IDs — bot không check trong kênh này
  whitelistChannels: [],

  // Whitelist role IDs — role này được gửi link tự do
  whitelistRoles: [],

  // Log channel ID
  logChannelId: null,
};

// ─── REGEX PATTERNS ────────────────────────────────────────────────────────────
// Tất cả compile 1 lần lúc khởi động — zero cost lúc runtime
const PATTERNS = {
  // URL thường: http/https
  url: /https?:\/\/[^\s<>)"'`]+/gi,

  // Discord invite — bắt mọi dạng
  discordInvite: /(?:discord(?:app)?\.(?:com|gg)\/(?:invite\/)?|dsc\.gg\/|discord\.link\/|invite\.gg\/)[a-zA-Z0-9\-_]+/gi,

  // Masked markdown links: [text](url)
  markdownLink: /\[.+?\]\((https?:\/\/[^)]+)\)/gi,

  // Anti-bypass: link bị tách bằng khoảng trắng hoặc zero-width chars
  splitUrl: /h\s*t\s*t\s*p/gi,

  // Shortened URLs phổ biến
  shortened: /(?:bit\.ly|tinyurl\.com|goo\.gl|ow\.ly|t\.co|rb\.gy|cutt\.ly|short\.gg|shorte\.st|adf\.ly)\/\S+/gi,

  // Anti invisible/zero-width bypass
  invisible: /[\u200B-\u200F\u2028-\u202F\u205F-\u206F\uFEFF\u00AD]/g,

  // Domain dạng: word.com / word.net / word.xyz — bắt domain không cần http
  bareUrl: /(?<![a-zA-Z0-9@.])(?:[a-zA-Z0-9\-]+\.)+(?:com|net|org|io|gg|xyz|co|me|tv|live|site|online|store|shop|ru|tk|ml|cf|ga|pw|top|click|link|info|app|dev|ai)\b(?:\/\S*)?/gi,
};

// Scam domains bị block thêm
const SCAM_DOMAINS = new Set([
  'discord.gift', 'discordapp.gift', 'discord-gift.com',
  'steamcommunity.ru', 'steampowered.gift',
  'nitro-generator.com', 'free-nitro.ru',
]);

// ─── TRACKER ──────────────────────────────────────────────────────────────────
// userId → { count, ts }
const linkTracker = new Map();

function trackLink(userId) {
  const now = Date.now();
  const e   = linkTracker.get(userId) ?? { count: 0, ts: now };
  if (now - e.ts > cfg.trackWindow) { e.count = 0; e.ts = now; }
  e.count++;
  linkTracker.set(userId, e);
  return e.count;
}

// Cleanup mỗi 2 phút để tránh memory leak
setInterval(() => {
  const now = Date.now();
  for (const [k, e] of linkTracker) {
    if (now - e.ts > cfg.trackWindow * 2) linkTracker.delete(k);
  }
}, 120000).unref();

// ─── DETECTION ────────────────────────────────────────────────────────────────
function detectLink(content) {
  // 1. Xóa invisible chars rồi check
  const clean = content.replace(PATTERNS.invisible, '');

  if (PATTERNS.url.test(clean))          { PATTERNS.url.lastIndex = 0; return true; }
  if (PATTERNS.discordInvite.test(clean)){ PATTERNS.discordInvite.lastIndex = 0; return true; }
  if (PATTERNS.markdownLink.test(clean)) { PATTERNS.markdownLink.lastIndex = 0; return true; }
  if (PATTERNS.splitUrl.test(clean))     { PATTERNS.splitUrl.lastIndex = 0; return true; }
  if (PATTERNS.shortened.test(clean))    { PATTERNS.shortened.lastIndex = 0; return true; }
  if (PATTERNS.bareUrl.test(clean))      { PATTERNS.bareUrl.lastIndex = 0; return true; }

  // 2. Check scam domain riêng
  const urls = clean.match(/(?:https?:\/\/)?([a-zA-Z0-9\-]+\.[a-zA-Z]{2,})/) ?? [];
  for (const u of urls) {
    try {
      const host = new URL(u.startsWith('http') ? u : 'https://' + u).hostname.toLowerCase();
      if (SCAM_DOMAINS.has(host)) return true;
    } catch {}
  }

  return false;
}

// ─── PERMISSION CHECK ─────────────────────────────────────────────────────────
function isAllowed(message) {
  const member = message.member;
  if (!member) return true;

  // Guild owner + Administrator luôn bypass
  if (message.guild.ownerId === member.id) return true;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.permissions.has(PermissionFlagsBits.ManageMessages)) return true;

  // Whitelist role
  if (cfg.whitelistRoles.some(r => member.roles.cache.has(r))) return true;

  // Whitelist channel
  if (cfg.whitelistChannels.includes(message.channel.id)) return true;

  return false;
}

// ─── LOGGER ───────────────────────────────────────────────────────────────────
async function sendLog(client, guild, { member, channel, content, action }) {
  if (!cfg.logChannelId) return;
  let logCh;
  try { logCh = await guild.channels.fetch(cfg.logChannelId); } catch { return; }
  if (!logCh?.isTextBased()) return;

  const embed = new EmbedBuilder()
    .setTitle('🔗 Anti-Link — Link Bị Chặn')
    .setColor(0xE67E22)
    .setThumbnail(member.user.displayAvatarURL({ size: 64 }))
    .addFields(
      { name: 'Người dùng', value: `${member.user.tag} (\`${member.id}\`)`, inline: true },
      { name: 'Kênh',       value: `${channel}`,                             inline: true },
      { name: 'Hành động',  value: action,                                   inline: true },
      { name: 'Nội dung',   value: `\`\`\`${content.slice(0, 300)}\`\`\`` },
    )
    .setTimestamp();

  await logCh.send({ embeds: [embed] }).catch(() => {});
}

// ─── MAIN HANDLER ─────────────────────────────────────────────────────────────
async function handleAntiLink(message, client) {
  if (!cfg.enabled) return;
  if (!message.guild) return;
  if (message.author.bot) return;
  if (!message.member) return;
  if (isAllowed(message)) return;
  if (!detectLink(message.content)) return;

  // Xóa message ngay lập tức
  await message.delete().catch(() => {});

  const count  = trackLink(message.author.id);
  let action   = 'Xóa tin nhắn';
  let warnText = `⚠️ ${message.author} **không được gửi link** trong server này. Tin nhắn đã bị xóa.`;

  // Timeout nếu tái phạm nhiều lần
  if (count >= cfg.timeoutLimit) {
    const dur = cfg.timeoutDuration * 1000;
    await message.member.timeout(dur, 'AntiLink: Spam link nhiều lần').catch(() => {});
    action   = `Timeout ${cfg.timeoutDuration}s`;
    warnText = `⛔ ${message.author} đã bị **timeout ${cfg.timeoutDuration / 60} phút** vì spam link liên tục.`;
  } else if (count >= cfg.warnLimit) {
    warnText = `🚫 ${message.author} **cảnh báo lần ${count}!** Tiếp tục sẽ bị timeout.`;
    action   = `Cảnh báo lần ${count}`;
  }

  // Gửi cảnh báo → tự xóa sau 5s
  const warn = await message.channel.send(warnText).catch(() => null);
  if (warn) setTimeout(() => warn.delete().catch(() => {}), 5000);

  // Log
  await sendLog(client, message.guild, {
    member:  message.member,
    channel: message.channel,
    content: message.content,
    action,
  });
}

// ─── SLASH COMMAND HANDLER ────────────────────────────────────────────────────
async function handleAntiLinkCommand(interaction) {
  if (!interaction.isChatInputCommand()) return false;
  const cmd = interaction.commandName;
  const sub = interaction.options.getSubcommand?.(false);

  if (cmd !== 'antilink') return false;

  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Chỉ Admin mới dùng được lệnh này!', ephemeral: true });
    return true;
  }

  await interaction.deferReply({ ephemeral: true });
  const embed = (title, color, desc) =>
    new EmbedBuilder().setTitle(title).setColor(color).setDescription(desc).setTimestamp();

  if (sub === 'on') {
    cfg.enabled = true;
    return interaction.editReply({ embeds: [embed('✅ Anti-Link BẬT', 0x00FF88, 'Hệ thống chặn link đang hoạt động.')] });
  }

  if (sub === 'off') {
    cfg.enabled = false;
    return interaction.editReply({ embeds: [embed('⚠️ Anti-Link TẮT', 0xFF6600, 'Bot sẽ không chặn link cho đến khi bật lại.')] });
  }

  if (sub === 'status') {
    return interaction.editReply({
      embeds: [new EmbedBuilder()
        .setTitle('🔗 Anti-Link — Trạng thái')
        .setColor(cfg.enabled ? 0x00FF88 : 0xFF6600)
        .addFields(
          { name: 'Trạng thái',        value: cfg.enabled ? '✅ BẬT' : '❌ TẮT',   inline: true },
          { name: 'Kênh whitelist',    value: `${cfg.whitelistChannels.length} kênh`, inline: true },
          { name: 'Role whitelist',    value: `${cfg.whitelistRoles.length} role`,    inline: true },
          { name: 'Ngưỡng cảnh báo',  value: `${cfg.warnLimit} lần`,               inline: true },
          { name: 'Ngưỡng timeout',   value: `${cfg.timeoutLimit} lần`,             inline: true },
          { name: 'Thời gian timeout', value: `${cfg.timeoutDuration}s`,            inline: true },
        )
        .setTimestamp()],
    });
  }

  if (sub === 'whitelist-channel') {
    const ch = interaction.options.getChannel('channel');
    const add = interaction.options.getBoolean('add') ?? true;
    if (add) {
      if (!cfg.whitelistChannels.includes(ch.id)) cfg.whitelistChannels.push(ch.id);
      return interaction.editReply({ embeds: [embed('✅ Whitelist Channel', 0x00FF88, `${ch} đã được thêm vào whitelist.\nBot sẽ không chặn link trong kênh này.`)] });
    } else {
      cfg.whitelistChannels = cfg.whitelistChannels.filter(id => id !== ch.id);
      return interaction.editReply({ embeds: [embed('✅ Whitelist Channel', 0xFFA500, `${ch} đã bị xóa khỏi whitelist.`)] });
    }
  }

  if (sub === 'whitelist-role') {
    const role = interaction.options.getRole('role');
    const add  = interaction.options.getBoolean('add') ?? true;
    if (add) {
      if (!cfg.whitelistRoles.includes(role.id)) cfg.whitelistRoles.push(role.id);
      return interaction.editReply({ embeds: [embed('✅ Whitelist Role', 0x00FF88, `Role ${role.name} đã được thêm.\nThành viên có role này được gửi link.`)] });
    } else {
      cfg.whitelistRoles = cfg.whitelistRoles.filter(id => id !== role.id);
      return interaction.editReply({ embeds: [embed('✅ Whitelist Role', 0xFFA500, `Role ${role.name} đã bị xóa khỏi whitelist.`)] });
    }
  }

  return true;
}

// Expose config để index.js có thể set logChannelId từ config.json
function setLogChannel(id)          { if (id) cfg.logChannelId = id; }
function setWhitelistChannels(ids)  { if (ids?.length) cfg.whitelistChannels = ids; }
function setWhitelistRoles(ids)     { if (ids?.length) cfg.whitelistRoles = ids; }

module.exports = {
  handleAntiLink,
  handleAntiLinkCommand,
  setLogChannel,
  setWhitelistChannels,
  setWhitelistRoles,
  cfg,
};
