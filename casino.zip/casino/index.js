const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  PermissionsBitField
} = require("discord.js");

// ===== MODULE ĐÁ GÀ =====
const { handleDaGa } = require("./daga");

// ===== MODULE HONG BAO =====
const { handleHongBao, handleHongBaoButton, startHongBaoCleanup } = require("./hongbao");

// ===== MODULE PANEL ADMIN =====
const {
  handlePanelAdmin,
  updateAdminProgress,
  getAdminModeOverride,
  logTransaction,
  logJackpot,
  logError
} = require("./paneladmin");

// ===== ANTI-RAID V2 SYSTEM =====
const antiRaidV2 = require("./indexantiraid");

// ===== ANTI-LINK SYSTEM =====
const { handleAntiLink, handleAntiLinkCommand, setLogChannel, setWhitelistChannels, setWhitelistRoles } = require("./antilink");

const fs = require("fs");
const config = require("./config.json");

// ===== CLIENT — thêm đủ intents cho Anti-Raid =====
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,       // AntiRaid V2: join raid
    GatewayIntentBits.GuildModeration,    // AntiRaid V2: timeout/ban
    GatewayIntentBits.GuildWebhooks,      // AntiRaid V2: webhook raid
  ]
});

// ===== SAFE — bắt lỗi toàn cục =====
process.on("unhandledRejection", (err) => console.error("[unhandledRejection]", err));
process.on("uncaughtException",  (err) => console.error("[uncaughtException]",  err));

// ===== FORMAT =====
const formatMoney = (x) => Number(x || 0).toLocaleString("vi-VN");

// ===== PARSE MONEY =====
function parseMoney(str) {
  if (str === null || str === undefined) return null;
  str = str.toString().trim().toLowerCase().replace(/,/g, "").replace(/\./g, "");
  str = str.replace(/^(\d+)[.,](\d+)/, "$1.$2");
  const match = str.match(/^(\d+(?:\.\d+)?)\s*([kmbt]?)$/);
  if (!match) {
    const n = parseInt(str.replace(/[^0-9]/g, ""));
    return isNaN(n) || n <= 0 ? null : n;
  }
  const units = { k: 1_000, m: 1_000_000, b: 1_000_000_000, t: 1_000_000_000_000 };
  const num   = parseFloat(match[1]);
  const unit  = units[match[2]] || 1;
  const result = Math.floor(num * unit);
  return isNaN(result) || result <= 0 ? null : result;
}

// ===== UI =====
function ui(title, color, desc) {
  return new EmbedBuilder()
    .setTitle(title)
    .setColor(color)
    .setDescription(desc)
    .setFooter({ text: "🎰 Royal Baccarat" })
    .setTimestamp();
}

// ===== SAFE SAVE =====
function save(f, d) {
  const tmp = f + ".tmp";
  try {
    fs.writeFileSync(tmp, JSON.stringify(d, null, 2));
    fs.renameSync(tmp, f);
  } catch (err) {
    console.error(`[save error] ${f}:`, err);
    try { fs.unlinkSync(tmp); } catch {}
  }
}

// ===== SAFE LOAD =====
function load(f) {
  try {
    if (!fs.existsSync(f)) return {};
    const raw = fs.readFileSync(f, "utf8");
    return JSON.parse(raw);
  } catch (err) {
    console.error(`[load error] ${f}:`, err);
    return {};
  }
}

// ===== DATA =====
let wallet        = load("wallet.json");
let bets          = load("bets.json");
let hoantra       = load("hoantra.json");
let hoantraluutru = load("hoantraluutru.json");
let vipData       = load("vipData.json");
let referral      = load("referral.json");
let referralReward= load("referralReward.json");
let referralStats = load("referralStats.json");
let pendingReferral = load("pendingReferral.json");

// ===== NOHU DATA =====
let nohu = load("nohu.json");
if (!nohu.bankroll)   nohu.bankroll   = 500000000;
if (!nohu.totalBet)   nohu.totalBet   = 0;
if (!nohu.totalPayout)nohu.totalPayout= 0;
if (!nohu.userStats)  nohu.userStats  = {};
if (!nohu.lastJackpot)nohu.lastJackpot= 0;
save("nohu.json", nohu);

// ===== SESSION =====
let session = { open: false };

// ===== SLOT ANTI SPAM =====
const spinLock = new Map();
const spinCooldown = new Map();
const SPIN_COOLDOWN_MS = 3000;
const rewardPaid = new Set();

// ===== BALANCE =====
const getBalance = (id) => Number(wallet[id] || 0);
const setBalance = (id, v) => {
  wallet[id] = Number(v);
  save("wallet.json", wallet);
};

// ===== VIP =====
function getVip(id) {
  const vip = Math.floor((vipData[id] || 0) / 100000000) + 1;
  return Math.min(vip, 64);
}
function addVip(id, amount) {
  vipData[id] = (vipData[id] || 0) + amount;
  save("vipData.json", vipData);
}
function vipName(vip) {
  if (vip >= 64) return "ĐẾ VƯƠNG";
  if (vip >= 50) return "HOÀNG ĐẾ";
  if (vip >= 40) return "ĐẠI GIA";
  if (vip >= 30) return "THƯỢNG KHÁCH";
  if (vip >= 20) return "TÀI PHÚ";
  if (vip >= 10) return "ÔNG CHỦ";
  return "TÂN THỦ";
}
function vipTag(id, username) {
  const vip = getVip(id);
  return `👑 VIP ${vip} | ${vipName(vip)} | ${username}`;
}

// ===== SLOT SYMBOLS =====
const SLOT_SYMBOLS = [
  { icon: "🍒", weight: 35, multi: 1.8  },
  { icon: "🍋", weight: 28, multi: 2.5  },
  { icon: "🔔", weight: 18, multi: 4    },
  { icon: "7️⃣", weight: 10, multi: 10   },
  { icon: "💎", weight: 6,  multi: 25   },
  { icon: "👑", weight: 3,  multi: 80   }
];
const NUMBERS = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"];

function getCurrentRTP() {
  if (nohu.totalBet <= 0) return 50;
  return (nohu.totalPayout / nohu.totalBet) * 100;
}
function weightedRandom(pool) {
  const total = pool.reduce((a, b) => a + b.weight, 0);
  let rand = Math.random() * total;
  for (const item of pool) {
    rand -= item.weight;
    if (rand <= 0) return item;
  }
  return pool[0];
}
function getUserStats(id) {
  if (!nohu.userStats[id]) {
    nohu.userStats[id] = {
      loseStreak: 0, winStreak: 0,
      spins: 0, totalBet: 0, totalWin: 0,
      lastBet: 0, avgBet: 0, heat: 0,
      emotional: 0, delayedCounter: 0, recoveryLock: 0
    };
  }
  return nohu.userStats[id];
}
function getAIMode(userId, amount) {
  const stats = getUserStats(userId);
  const rtp   = getCurrentRTP();
  let mode = "NORMAL";
  if (stats.winStreak >= 2) stats.emotional += 2;
  if (stats.loseStreak >= 3) stats.emotional += 1;
  if (stats.emotional > 10) stats.emotional = 10;
  if (stats.totalWin > stats.totalBet * 0.7) stats.heat += amount * 0.3;
  if (stats.spins <= 5) mode = "LOOSE";
  if (stats.loseStreak >= 6) {
    stats.delayedCounter++;
    if (stats.delayedCounter >= 4) { mode = "LOOSE"; stats.delayedCounter = 0; }
    else mode = "TIGHT";
  }
  if (stats.avgBet > 0 && amount >= stats.avgBet * 3) mode = "TIGHT";
  if (stats.emotional >= 6) mode = "TIGHT";
  if (stats.loseStreak >= 2 && stats.loseStreak <= 5) mode = "TIGHT";
  if (stats.loseStreak >= 10) {
    stats.recoveryLock++;
    if (stats.recoveryLock >= 3) mode = "LOOSE";
  }
  if (rtp >= 60) mode = "TIGHT";
  if (rtp <= 42 && Math.random() < 0.25) mode = "LOOSE";
  if (Date.now() - nohu.lastJackpot < 1000 * 60 * 20) mode = "TIGHT";
  if (nohu.bankroll <= 0) mode = "TIGHT";
  const adminOverride = getAdminModeOverride(userId);
  if (adminOverride) mode = adminOverride;
  return mode;
}
function generateSpin(userId, amount) {
  const mode  = getAIMode(userId, amount);
  const stats = getUserStats(userId);
  let pool = JSON.parse(JSON.stringify(SLOT_SYMBOLS));
  if (mode === "LOOSE" || stats.loseStreak >= 5) {
    for (const p of pool) {
      if (p.icon === "🍒" || p.icon === "🍋" || p.icon === "🔔") p.weight += 15;
    }
  }
  if (mode === "TIGHT") {
    for (const p of pool) {
      if (p.icon === "👑" || p.icon === "💎") p.weight = 1;
    }
  }
  const a = weightedRandom(pool).icon;
  const b = weightedRandom(pool).icon;
  const c = weightedRandom(pool).icon;
  const d = weightedRandom(pool).icon;
  const e = weightedRandom(pool).icon;
  let final = [a, b, c, d, e];
  const nearMiss = Math.random() < 0.45;
  if (nearMiss && mode === "TIGHT") {
    const rare = ["👑", "💎", "7️⃣"];
    const pick = rare[Math.floor(Math.random() * rare.length)];
    final = [pick, pick, weightedRandom(pool).icon, d, e];
  }
  const releaseMode = stats.loseStreak >= 10 && Math.random() < 0.30;
  if (releaseMode) {
    const easy = ["🍒", "🍋", "🔔", "7️⃣"];
    const pick = easy[Math.floor(Math.random() * easy.length)];
    final = [pick, pick, pick, weightedRandom(pool).icon, weightedRandom(pool).icon];
  }
  const looseWin = Math.random() < 0.05;
  if (looseWin && mode === "LOOSE") {
    const easy = ["🍒", "🍋", "🔔"];
    const pick = easy[Math.floor(Math.random() * easy.length)];
    final = [pick, pick, pick, d, e];
  }
  if (!Array.isArray(final) || final.length < 5) {
    final = ["🍒", "🍋", "🔔", "🍒", "🍋"];
  }
  return final;
}

// ===== REFERRAL =====
function addReferralReward(userId, betAmount) {
  if (!referral[userId]) return;
  const inviter = referral[userId].inviter;
  if (!inviter) return;
  const reward = Math.floor(betAmount * 0.01);
  if (reward <= 0) return;
  referralReward[inviter] = (referralReward[inviter] || 0) + reward;
  save("referralReward.json", referralReward);
  if (!referralStats[inviter]) referralStats[inviter] = { totalEarned: 0, invitees: [] };
  referralStats[inviter].totalEarned = (referralStats[inviter].totalEarned || 0) + reward;
  save("referralStats.json", referralStats);
}

// ===== READY =====
client.once("ready", () => {
  console.log("🤖 BOT READY:", client.user.tag);

  // ===== KHỞI ĐỘNG ANTI-RAID V2 =====
  antiRaidV2.init(client, {
    logChannelId:       config.logChannelId       || null,
    modLogChannelId:    config.modLogChannelId     || null,
    raidAlertChannelId: config.raidAlertChannelId  || null,
    trustedRoles:       config.trustedRoles        || [],
    trustedUsers:       config.trustedUsers        || [],
    staffRoles:         config.staffRoles          || [],
    ownerIds:           config.ownerIds            || [],
  });
  console.log("[AntiRaid V2] ✓ Tích hợp vào Casino Bot thành công");

  // ===== KHỞI ĐỘNG ANTI-LINK =====
  setLogChannel(config.logChannelId);
  setWhitelistChannels(config.antilinkWhitelistChannels || []);
  setWhitelistRoles(config.antilinkWhitelistRoles || []);
  console.log("[AntiLink] ✓ Hệ thống chặn link đã sẵn sàng");

  // ===== HONG BAO CLEANUP =====
  startHongBaoCleanup();

  // ===== SLOT MEMORY PROTECT =====
  setInterval(() => {
    spinLock.clear();
    spinCooldown.clear();
    rewardPaid.clear();
    const now = Date.now();
    let changed = false;
    for (const [uid, data] of Object.entries(pendingReferral)) {
      if (data.ts && now - data.ts > 5 * 60 * 1000) {
        delete pendingReferral[uid];
        changed = true;
      }
    }
    if (changed) save("pendingReferral.json", pendingReferral);
  }, 5 * 60 * 1000);
});

// ===== ANTI-LINK MESSAGE HANDLER =====
client.on("messageCreate", async (message) => {
  await handleAntiLink(message, client);
});

// ===== MAIN =====
client.on("interactionCreate", async (i) => {
  try {

    // ===== BUTTON HANDLER =====
    if (i.isButton()) {

      const hbHandled = await handleHongBaoButton(i, { getBalance, setBalance, sendLog: null }).catch(() => false);
      if (hbHandled) return;

      if (
        i.customId !== "PLAYER" &&
        i.customId !== "BANKER" &&
        i.customId !== "RANDOM"
      ) {
        return;
      }

      if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return i.reply({ content: "❌ Chỉ admin mới được chọn kết quả!", ephemeral: true });
      }

      let result = i.customId;
      if (result === "RANDOM") {
        result = Math.random() < 0.5 ? "PLAYER" : "BANKER";
      }

      let win  = [];
      let lose = [];

      for (const uid in bets) {
        if (!Array.isArray(bets[uid])) continue;
        for (const b of bets[uid]) {
          if (!b) continue;
          if (b.type === result) {
            const reward = Math.floor(b.amount * 1.95);
            setBalance(uid, getBalance(uid) + reward);
            win.push(`👑 VIP ${getVip(uid)} | ${vipName(getVip(uid))} | <@${uid}> +${formatMoney(reward)}$`);
          } else {
            lose.push(`👑 VIP ${getVip(uid)} | ${vipName(getVip(uid))} | <@${uid}> -${formatMoney(b.amount)}$`);
          }
        }
      }

      bets = {};
      save("bets.json", bets);

      return i.update({
        embeds: [
          ui(
            "🏆 KẾT QUẢ BACCARAT",
            result === "PLAYER" ? 0x3498db : 0xe74c3c,
`🎯 Kết Quả: ${result}

💰 Người Thắng:
${win.join("\n") || "Không có"}

❌ Người Thua:
${lose.join("\n") || "Không có"}`
          )
        ],
        components: []
      });
    }

    if (!i.isChatInputCommand()) return;

    // ===== ANTI-LINK COMMANDS =====
    if (i.commandName === 'antilink') {
      await handleAntiLinkCommand(i).catch(e => console.error('[AntiLink]', e.message));
      return;
    }

    // ===== ANTI-RAID V2 COMMANDS =====
    const _AR_CMDS = ['antiraid','lockdown','unlockdown','panic','panic-off','whitelist','logs'];
    if (_AR_CMDS.includes(i.commandName)) {
      await antiRaidV2.handleCommand(i).catch(e => console.error('[AntiRaid V2]', e.message));
      return;
    }

    await i.deferReply();

    const cmd = i.commandName;

    // ===== NẠP =====
    if (cmd === "nap") {
      if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return i.editReply("❌ Admin only!");
      }
      const user      = i.options.getUser("user");
      const amountRaw = i.options.getString("amount");
      const amount    = parseMoney(amountRaw);
      if (!user) return i.editReply("❌ Không tìm thấy người dùng");
      if (!amount) return i.editReply("❌ Số tiền không hợp lệ!\nVD: `250m`, `1b`, `500k`, `1000000`");
      setBalance(user.id, getBalance(user.id) + amount);
      logTransaction(user.id, user.username, "nap", amount, `Admin: ${i.user.username}`);
      return i.editReply({
        embeds: [ui("💰 NẠP TIỀN", 0x2ecc71, `${vipTag(user.id, user.username)}\n\n💵 +${formatMoney(amount)}$`)]
      });
    }

    // ===== RÚT =====
    if (cmd === "rut") {
      if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return i.editReply("❌ Admin only!");
      }
      const user      = i.options.getUser("user");
      const amountRaw = i.options.getString("amount");
      const amount    = parseMoney(amountRaw);
      if (!user) return i.editReply("❌ Không tìm thấy người dùng");
      if (!amount) return i.editReply("❌ Số tiền không hợp lệ!\nVD: `250m`, `1b`, `500k`");
      setBalance(user.id, Math.max(0, getBalance(user.id) - amount));
      logTransaction(user.id, user.username, "rut", amount, `Admin: ${i.user.username}`);
      return i.editReply({
        embeds: [ui("💸 RÚT TIỀN", 0xe74c3c, `${vipTag(user.id, user.username)}\n\n💵 -${formatMoney(amount)}$`)]
      });
    }

    // ===== ĐẶT =====
    if (cmd === "dat") {
      if (!session.open) return i.editReply("❌ Đã đóng cược!");
      const type      = i.options.getString("type");
      const amountRaw = i.options.getString("amount");
      const amount    = parseMoney(amountRaw);
      if (!["PLAYER", "BANKER"].includes(type)) return i.editReply("❌ Sai lựa chọn");
      if (!amount) return i.editReply("❌ Số tiền không hợp lệ!\nVD: `50m`, `500k`, `1b`");
      if (getBalance(i.user.id) < amount) return i.editReply("❌ Không đủ tiền");
      setBalance(i.user.id, getBalance(i.user.id) - amount);
      addVip(i.user.id, amount);
      addReferralReward(i.user.id, amount);
      hoantra[i.user.id] = (hoantra[i.user.id] || 0) + amount;
      save("hoantra.json", hoantra);
      if (!bets[i.user.id]) bets[i.user.id] = [];
      bets[i.user.id].push({ type, amount });
      save("bets.json", bets);
      return i.editReply({
        embeds: [ui("🎲 ĐẶT CƯỢC", type === "PLAYER" ? 0x3498db : 0xe74c3c,
          `${vipTag(i.user.id, i.user.username)}\n\n💰 ${formatMoney(amount)}$\n🎯 ${type}`)]
      });
    }

    // ===== HOÀN TRẢ =====
    if (cmd === "hoantra") {
      const bet  = hoantra[i.user.id] || 0;
      const vip  = getVip(i.user.id);
      let percent = 2 + ((vip - 1) * (18 / 63));
      if (percent > 20) percent = 20;
      percent = Number(percent.toFixed(1));
      if (bet > 0) {
        const refund = Math.floor(bet * (percent / 100));
        hoantraluutru[i.user.id] = (hoantraluutru[i.user.id] || 0) + refund;
        hoantra[i.user.id] = 0;
        save("hoantra.json", hoantra);
        save("hoantraluutru.json", hoantraluutru);
      }
      const total = hoantraluutru[i.user.id] || 0;
      if (total <= 0) return i.editReply("❌ Không có hoàn trả");
      setBalance(i.user.id, getBalance(i.user.id) + total);
      hoantraluutru[i.user.id] = 0;
      save("hoantraluutru.json", hoantraluutru);
      return i.editReply({
        embeds: [ui(`💰 HOÀN TRẢ VIP ${percent}%`, 0x2ecc71,
          `${vipTag(i.user.id, i.user.username)}\n\n💸 +${formatMoney(total)}$`)]
      });
    }

    // ===== VIP =====
    if (cmd === "vip") {
      const user    = i.options.getUser("user") || i.user;
      const total   = vipData[user.id] || 0;
      const level   = getVip(user.id);
      const next    = level * 100000000;
      const need    = Math.max(0, next - total);
      const percent = Math.floor((total % 100000000) / 1000000);
      return i.editReply({
        embeds: [ui("👑 VIP PROFILE", 0xf1c40f,
          `${vipTag(user.id, user.username)}\n\n📈 Còn Thiếu: ${formatMoney(need)}$\n📊 Tiến Độ: ${percent}%`)]
      });
    }

    // ===== KẾT QUẢ =====
    if (cmd === "ketqua") {
      if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return i.editReply("❌ Chỉ admin!");
      }
      session.open = false;
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("PLAYER").setLabel("PLAYER").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("BANKER").setLabel("BANKER").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId("RANDOM").setLabel("RANDOM").setStyle(ButtonStyle.Secondary)
      );
      return i.editReply({
        embeds: [ui("🎰 ĐÓNG CƯỢC", 0xf1c40f, "⛔ Đã đóng cược\n👉 Admin chọn kết quả")],
        components: [row]
      });
    }

    // ===== BẮT ĐẦU =====
    if (cmd === "batdau") {
      session.open = true;
      bets = {};
      save("bets.json", bets);
      return i.editReply({
        embeds: [ui("▶️ BẮT ĐẦU CƯỢC", 0x2ecc71, "🎲 Đã mở cược Baccarat")]
      });
    }

    // ===== QUAY HŨ =====
    if (cmd === "quayhu") {
      const userId    = i.user.id;
      const amountRaw = i.options.getString("amount");
      const amount    = parseMoney(amountRaw);
      const spin      = Math.min(10, i.options.getInteger("spin") || 1);
      if (!amount) return i.editReply("❌ Tiền cược không hợp lệ!\nVD: `50m`, `500k`, `1b`");
      if (spinLock.has(userId)) {
        return i.editReply("⏳ Bạn đang quay, hãy đợi kết quả!");
      }
      const lastSpin = spinCooldown.get(userId) || 0;
      if (Date.now() - lastSpin < SPIN_COOLDOWN_MS) {
        const wait = Math.ceil((SPIN_COOLDOWN_MS - (Date.now() - lastSpin)) / 1000);
        return i.editReply(`⏳ Hãy đợi ${wait} giây trước khi quay tiếp!`);
      }
      if (getBalance(userId) < amount * spin) return i.editReply("❌ Không đủ tiền");
      spinLock.set(userId, true);
      const rewardId = `${userId}_${Date.now()}_${Math.random()}`;
      let rewardClaimed = false;
      try {
        setBalance(userId, getBalance(userId) - amount * spin);
        const stats = getUserStats(userId);
        if (!stats.avgBet) stats.avgBet = amount;
        stats.avgBet    = Math.floor((stats.avgBet * 0.8) + (amount * 0.2));
        stats.spins    += spin;
        stats.totalBet += amount * spin;
        stats.lastBet   = amount;
        addVip(userId, amount * spin);
        hoantra[userId] = (hoantra[userId] || 0) + (amount * spin);
        save("hoantra.json", hoantra);
        addReferralReward(userId, amount * spin);
        nohu.totalBet  += amount * spin;
        nohu.bankroll  += amount * spin;
        save("nohu.json", nohu);
        await i.editReply({
          embeds: [ui("🎰 QUAY HŨ MAY MẮN", 0xf1c40f,
            `${vipTag(userId, `<@${userId}>`)}\n\n💸 Cược:\n${formatMoney(amount)}$\n\n🎲 Đang quay...`)]
        });
        let lines       = [];
        let totalReward = 0;
        for (let s = 1; s <= spin; s++) {
          await new Promise(r => setTimeout(r, 700));
          if (!i.deferred && !i.replied) break;
          const slot = generateSpin(userId, amount);
          let text   = "❌ Không nổ";
          let reward = 0;
          if (slot[0] === slot[1] && slot[1] === slot[2]) {
            const sym = SLOT_SYMBOLS.find(x => x.icon === slot[0]);
            if (sym) reward = Math.floor(amount * sym.multi);
            totalReward += reward;
            text = `💥 JACKPOT +${formatMoney(reward)}$`;
            if (slot[0] === "👑") {
              text = `💥 JACKPOT MAX\n🎊 TRÚNG 👑 SIÊU HIẾM\n+${formatMoney(reward)}$`;
              nohu.lastJackpot = Date.now();
              logJackpot(userId, i.user.username, reward);
            }
          }
          lines.push(`${NUMBERS[s - 1]} | ${slot.join(" | ")} |\n${text}`);
          try {
            await i.editReply({
              embeds: [ui("🎰 QUAY HŨ MAY MẮN", totalReward > 0 ? 0x2ecc71 : 0xe74c3c,
                `${vipTag(userId, `<@${userId}>`)}\n\n💸 Cược:\n${formatMoney(amount)}$\n\n${lines.join("\n\n")}`)]
            });
          } catch (editErr) {
            console.error("[quayhu editReply spin]", editErr.message);
            break;
          }
        }
        if (totalReward > 0 && !rewardClaimed && !rewardPaid.has(rewardId)) {
          rewardClaimed = true;
          rewardPaid.add(rewardId);
          setBalance(userId, getBalance(userId) + totalReward);
          const stats2 = getUserStats(userId);
          stats2.winStreak  += 1;
          stats2.loseStreak  = 0;
          stats2.totalWin   += totalReward;
          nohu.totalPayout += totalReward;
          nohu.bankroll    -= totalReward;
          updateAdminProgress(amount * spin, totalReward);
          logTransaction(userId, i.user.username, "slot_win", totalReward);
        } else if (totalReward === 0) {
          const stats2 = getUserStats(userId);
          stats2.loseStreak += spin;
          stats2.winStreak   = 0;
        }
        save("nohu.json", nohu);
        try {
          return await i.editReply({
            embeds: [ui("🎰 QUAY HŨ MAY MẮN", totalReward > 0 ? 0x2ecc71 : 0xe74c3c,
              `${vipTag(userId, `<@${userId}>`)}\n\n💸 Tổng cược:\n${formatMoney(amount * spin)}$\n\n${lines.join("\n\n")}\n\n━━━━━━━━━━━━━━\n\n💰 Tổng thắng:\n+${formatMoney(totalReward)}$`)]
          });
        } catch (finalErr) {
          console.error("[quayhu editReply final]", finalErr.message);
        }
      } finally {
        spinLock.delete(userId);
        spinCooldown.set(userId, Date.now());
      }
      return;
    }

    // ===== KÉO BÚA BAO =====
    if (cmd === "keobuabao") {
      const enemy     = i.options.getUser("user");
      const amountRaw = i.options.getString("tien");
      const amount    = parseMoney(amountRaw);
      if (!enemy)                         return i.editReply("❌ Không tìm thấy người chơi");
      if (enemy.bot)                      return i.editReply("❌ Không thể đấu với bot");
      if (enemy.id === i.user.id)         return i.editReply("❌ Không thể tự đấu");
      if (!amount)                        return i.editReply("❌ Tiền cược không hợp lệ!\nVD: `50m`, `500k`");
      if (getBalance(i.user.id) < amount) return i.editReply("❌ Bạn không đủ tiền");
      const acceptRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("kbb_accept").setLabel("ACCEPT").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("kbb_decline").setLabel("TỪ CHỐI").setStyle(ButtonStyle.Danger)
      );
      const msg = await i.editReply({
        embeds: [ui("🎮 KÉO • BÚA • BAO", 0xf1c40f,
          `👤 ${i.user} mời ${enemy}\n\n💰 Tiền cược:\n${formatMoney(amount)}$\n\n⏳ Chờ đối thủ accept...`)],
        components: [acceptRow],
        fetchReply: true
      });
      const collector = msg.createMessageComponentCollector({
        filter: x => x.user.id === enemy.id &&
          (x.customId === "kbb_accept" || x.customId === "kbb_decline"),
        time: 30000,
        max: 1
      });
      collector.on("collect", async btn => {
        if (btn.customId === "kbb_decline") {
          return btn.update({
            embeds: [ui("❌ KÈO ĐẤU ĐÃ HỦY", 0xe74c3c, `${enemy} đã từ chối kèo đấu.`)],
            components: []
          });
        }
        if (getBalance(enemy.id) < amount) {
          return btn.update({
            embeds: [ui("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c, `${enemy} không đủ tiền cược.`)],
            components: []
          });
        }
        await btn.update({
          embeds: [ui("🎮 KÉO • BÚA • BAO", 0xf1c40f, `👤 ${i.user} vs ${enemy}\n\n✅ Đã accept! Bắt đầu thi đấu...`)],
          components: []
        });
        setBalance(i.user.id, getBalance(i.user.id) - amount);
        setBalance(enemy.id,  getBalance(enemy.id)  - amount);
        let p1Win = 0, p2Win = 0;
        const rounds = [];
        const hands  = { bua: "✊", bao: "✋", keo: "✌️" };
        function decide(a, b) {
          if (a === b) return 0;
          if ((a === "bua" && b === "keo") || (a === "keo" && b === "bao") || (a === "bao" && b === "bua")) return 1;
          return 2;
        }
        for (let round = 1; round <= 3; round++) {
          let p1Choice = null, p2Choice = null;
          const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("bua").setLabel("✊ BÚA").setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId("bao").setLabel("✋ BAO").setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId("keo").setLabel("✌️ KÉO").setStyle(ButtonStyle.Secondary)
          );
          await msg.edit({
            embeds: [ui(`🥊 ROUND ${round}`, 0x3498db, `👤 ${i.user} vs ${enemy}\n\n⏳ Hãy chọn...`)],
            components: [row]
          });
          const selected = new Set();
          const done = await new Promise(resolve => {
            let finished = false;
            const roundCollector = msg.createMessageComponentCollector({
              filter: b => (b.user.id === i.user.id || b.user.id === enemy.id) &&
                ["bua", "bao", "keo"].includes(b.customId),
              time: 30000
            });
            roundCollector.on("collect", async b => {
              if (selected.has(b.user.id)) {
                return b.reply({ content: "❌ Bạn đã chọn rồi", ephemeral: true });
              }
              selected.add(b.user.id);
              if (b.user.id === i.user.id) p1Choice = b.customId;
              if (b.user.id === enemy.id)  p2Choice = b.customId;
              await b.reply({ content: "✅ Đã khóa lựa chọn", ephemeral: true });
              if (p1Choice && p2Choice && !finished) {
                finished = true;
                roundCollector.stop();
                resolve(true);
              }
            });
            roundCollector.on("end", () => { if (!finished) resolve(false); });
          });
          if (!done) {
            setBalance(i.user.id, getBalance(i.user.id) + amount);
            setBalance(enemy.id,  getBalance(enemy.id)  + amount);
            return msg.edit({
              embeds: [ui("⌛ TIMEOUT", 0xe74c3c, "Hoàn tiền do quá thời gian.")],
              components: []
            });
          }
          const result = decide(p1Choice, p2Choice);
          let text = "🤝 Hòa";
          if (result === 1) { p1Win++; text = `🏆 ${i.user} thắng`; }
          if (result === 2) { p2Win++; text = `🏆 ${enemy} thắng`; }
          rounds.push(`🥊 LẦN ${round}\n👤 ${i.user}: ${hands[p1Choice]}\n👤 ${enemy}: ${hands[p2Choice]}\n${text}`);
          await new Promise(r => setTimeout(r, 1500));
        }
        let finalText = "";
        const reward  = Math.floor(amount * 1.95);
        if (p1Win > p2Win) {
          setBalance(i.user.id, getBalance(i.user.id) + reward);
          finalText = `🏆 Người thắng chung cuộc:\n👑 ${i.user}\n\n💰 Nhận:\n${formatMoney(reward)}$`;
        } else if (p2Win > p1Win) {
          setBalance(enemy.id, getBalance(enemy.id) + reward);
          finalText = `🏆 Người thắng chung cuộc:\n👑 ${enemy}\n\n💰 Nhận:\n${formatMoney(reward)}$`;
        } else {
          setBalance(i.user.id, getBalance(i.user.id) + amount);
          setBalance(enemy.id,  getBalance(enemy.id)  + amount);
          finalText = `🤝 HÒA CHUNG CUỘC\n\n💸 Hoàn tiền 2 bên`;
        }
        return msg.edit({
          embeds: [ui("🎮 KẾT QUẢ KÉO • BÚA • BAO", 0xf1c40f,
            `👤 ${i.user} vs ${enemy}\n\n━━━━━━━━━━\n\n${rounds.join("\n\n")}\n\n━━━━━━━━━━\n\n📊 TỔNG KẾT\n\n${finalText}`)],
          components: []
        });
      });
      collector.on("end", collected => {
        if (collected.size === 0) {
          msg.edit({
            embeds: [ui("⌛ TIMEOUT", 0xe74c3c, "Không có phản hồi. Kèo đấu đã hủy.")],
            components: []
          }).catch(() => {});
        }
      });
      return;
    }

    // ===== SỐ DƯ =====
    if (cmd === "sodu") {
      const list = Object
        .entries(wallet)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10)
        .map((x, idx) =>
          `${idx + 1}. 👑 VIP ${getVip(x[0])} | ${vipName(getVip(x[0]))} | <@${x[0]}> 💰 ${formatMoney(x[1])}$`
        )
        .join("\n\n");
      return i.editReply({
        embeds: [ui("📊 TOP ĐẠI GIA", 0xf1c40f, list || "Chưa có dữ liệu")]
      });
    }

    // ===== GIỚI THIỆU =====
    if (cmd === "gioithieu") {
      const target = i.options.getUser("user");
      if (!target)                  return i.editReply("❌ Không tìm thấy người dùng");
      if (target.bot)               return i.editReply("❌ Không thể giới thiệu bot");
      if (target.id === i.user.id)  return i.editReply("❌ Không thể tự giới thiệu bản thân");
      if (referral[i.user.id]) {
        return i.editReply(`❌ Bạn đã có inviter: <@${referral[i.user.id].inviter}>`);
      }
      if (referral[target.id]) {
        return i.editReply("❌ Người này đã có inviter, không thể làm inviter của bạn");
      }
      if (referralStats[target.id]?.invitees?.includes(i.user.id)) {
        return i.editReply("❌ Không thể referral vòng lặp");
      }
      if (pendingReferral[i.user.id]) {
        return i.editReply("❌ Bạn đang có yêu cầu referral chờ xử lý");
      }
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("ref_accept").setLabel("✅ ACCEPT").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("ref_decline").setLabel("❌ DECLINE").setStyle(ButtonStyle.Danger)
      );
      const msg = await i.editReply({
        embeds: [ui("🤝 YÊU CẦU REFERRAL", 0xf1c40f,
          `👤 <@${i.user.id}> muốn nhập referral của bạn.\n\nNếu bạn ACCEPT:\n• <@${i.user.id}> sẽ trở thành invitee của bạn\n• Bạn nhận 1% hoa hồng từ cược của họ\n• Liên kết vĩnh viễn, không thể thay đổi`)],
        components: [row],
        fetchReply: true
      });
      pendingReferral[i.user.id] = { inviter: target.id, ts: Date.now() };
      save("pendingReferral.json", pendingReferral);
      const collector = msg.createMessageComponentCollector({
        filter: x => x.user.id === target.id &&
          (x.customId === "ref_accept" || x.customId === "ref_decline"),
        time: 60000,
        max: 1
      });
      collector.on("collect", async btn => {
        delete pendingReferral[i.user.id];
        save("pendingReferral.json", pendingReferral);
        if (btn.customId === "ref_decline") {
          return btn.update({
            embeds: [ui("❌ TỪ CHỐI REFERRAL", 0xe74c3c, `<@${target.id}> đã từ chối yêu cầu referral.`)],
            components: []
          });
        }
        if (referral[i.user.id]) {
          return btn.update({
            embeds: [ui("❌ LỖI", 0xe74c3c, "Người này đã có inviter rồi.")],
            components: []
          });
        }
        referral[i.user.id] = { inviter: target.id };
        save("referral.json", referral);
        if (!referralStats[target.id]) referralStats[target.id] = { totalEarned: 0, invitees: [] };
        if (!referralStats[target.id].invitees.includes(i.user.id)) {
          referralStats[target.id].invitees.push(i.user.id);
        }
        save("referralStats.json", referralStats);
        return btn.update({
          embeds: [ui("✅ REFERRAL THÀNH CÔNG", 0x2ecc71,
            `🎉 Liên kết referral đã được tạo!\n\n👤 Invitee: <@${i.user.id}>\n👑 Inviter: <@${target.id}>\n\n💰 <@${target.id}> sẽ nhận 1% hoa hồng từ mọi cược của <@${i.user.id}>`)],
          components: []
        });
      });
      collector.on("end", collected => {
        if (collected.size === 0) {
          delete pendingReferral[i.user.id];
          save("pendingReferral.json", pendingReferral);
          msg.edit({
            embeds: [ui("⌛ TIMEOUT", 0xe74c3c, "Yêu cầu referral đã hết hạn.")],
            components: []
          }).catch(() => {});
        }
      });
      return;
    }

    // ===== NHẬN THƯỞNG REFERRAL =====
    if (cmd === "gioithieunhan") {
      const pending = referralReward[i.user.id] || 0;
      if (pending <= 0) return i.editReply("❌ Không có hoa hồng referral để nhận");
      setBalance(i.user.id, getBalance(i.user.id) + pending);
      referralReward[i.user.id] = 0;
      save("referralReward.json", referralReward);
      return i.editReply({
        embeds: [ui("💰 NHẬN HOA HỒNG REFERRAL", 0x2ecc71,
          `${vipTag(i.user.id, i.user.username)}\n\n💸 +${formatMoney(pending)}$`)]
      });
    }

    // ===== THỐNG KÊ REFERRAL =====
    if (cmd === "gioithieuinfo") {
      const user          = i.options.getUser("user") || i.user;
      const myInviter     = referral[user.id]?.inviter || null;
      const stats         = referralStats[user.id] || { totalEarned: 0, invitees: [] };
      const inviteeCount  = stats.invitees?.length || 0;
      const totalEarned   = stats.totalEarned || 0;
      const pendingReward = referralReward[user.id] || 0;
      const inviterLine   = myInviter ? `👑 Inviter của bạn: <@${myInviter}>` : `👑 Inviter: Chưa có`;
      const inviteeLine   = inviteeCount > 0 ? stats.invitees.map(id => `• <@${id}>`).join("\n") : "• Chưa có ai";
      return i.editReply({
        embeds: [ui("📊 THỐNG KÊ REFERRAL", 0x9b59b6,
          `${vipTag(user.id, user.username)}\n\n${inviterLine}\n\n👥 Số người đã mời: ${inviteeCount}\n${inviteeLine}\n\n━━━━━━━━━━━━━━\n\n💰 Tổng hoa hồng đã kiếm: ${formatMoney(totalEarned)}$\n🎁 Hoa hồng chưa nhận: ${formatMoney(pendingReward)}$`)]
      });
    }

    // ===== HỒNG BAO =====
    if (cmd === "hongbao") {
      return handleHongBao(i, { getBalance, setBalance });
    }


    // ===== CLEAR =====
    if (cmd === "clear") {
      if (!i.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return i.editReply({ content: "❌ Chỉ admin mới dùng được lệnh này!", ephemeral: true });
      }

      const soLuong  = i.options.getInteger("soluong");
      const usersRaw = i.options.getString("users") || "";

      // Parse danh sách user ID (bỏ khoảng trắng, bỏ <@> nếu có)
      const filterIds = usersRaw
        .split(",")
        .map(s => s.trim().replace(/[<@!>]/g, ""))
        .filter(s => /^\d+$/.test(s));

      const channel = i.channel;

      // Thông báo đang xóa
      await i.editReply({
        embeds: [ui("🗑️ ĐANG XÓA TIN NHẮN", 0xf1c40f,
          `⏳ Đang xóa **${soLuong}** tin nhắn...\n${filterIds.length > 0 ? "👤 Lọc theo: " + filterIds.map(id => `<@${id}>`).join(", ") : "📋 Xóa tất cả"}`)]
      });

      let totalDeleted = 0;
      let remaining    = soLuong;
      const MAX_PER_FETCH = 100;
      const TWO_WEEKS     = 14 * 24 * 60 * 60 * 1000;
      const now           = Date.now();
      let lastId          = null;
      let oldCount        = 0;

      // Vòng lặp fetch + xóa từng batch
      while (remaining > 0) {
        const fetchLimit = Math.min(remaining, MAX_PER_FETCH);

        // Fetch messages
        const fetchOptions = { limit: MAX_PER_FETCH };
        if (lastId) fetchOptions.before = lastId;

        let fetched;
        try {
          fetched = await channel.messages.fetch(fetchOptions);
        } catch {
          break;
        }

        if (fetched.size === 0) break;

        // Cập nhật lastId để fetch tiếp lần sau
        lastId = fetched.last()?.id;

        // Lọc theo user nếu có
        let toDelete = filterIds.length > 0
          ? fetched.filter(m => filterIds.includes(m.author.id))
          : fetched;

        // Giới hạn đúng số lượng cần xóa
        toDelete = [...toDelete.values()].slice(0, remaining);

        if (toDelete.length === 0) {
          if (fetched.size < MAX_PER_FETCH) break;
          continue;
        }

        // Tách tin < 14 ngày (bulk delete) và tin cũ hơn (single delete)
        const fresh = toDelete.filter(m => now - m.createdTimestamp < TWO_WEEKS);
        const old   = toDelete.filter(m => now - m.createdTimestamp >= TWO_WEEKS);

        // Bulk delete tin mới
        if (fresh.length > 0) {
          try {
            if (fresh.length === 1) {
              await fresh[0].delete();
              totalDeleted++;
            } else {
              const result = await channel.bulkDelete(fresh, true);
              totalDeleted += result.size;
            }
          } catch (e) {
            console.error("[clear] bulkDelete error:", e.message);
          }
          remaining -= fresh.length;
        }

        // Single delete tin cũ (rate-limit safe)
        for (const msg of old) {
          if (remaining <= 0) break;
          try {
            await msg.delete();
            totalDeleted++;
            remaining--;
            oldCount++;
          } catch {
            // skip nếu đã xóa hoặc không có quyền
          }
          // Delay nhẹ để tránh rate limit
          if (oldCount % 5 === 0) await new Promise(r => setTimeout(r, 500));
        }

        if (fetched.size < MAX_PER_FETCH) break;

        // Nhỏ delay giữa các batch
        await new Promise(r => setTimeout(r, 800));
      }

      // Kết quả
      const targetText = filterIds.length > 0
        ? "👤 User: " + filterIds.map(id => `<@${id}>`).join(", ")
        : "📋 Tất cả user";

      try {
        return await i.editReply({
          embeds: [ui(
            "✅ XÓA TIN NHẮN HOÀN TẤT",
            0x2ecc71,
            `🗑️ Đã xóa: **${totalDeleted}** tin nhắn\n${targetText}\n📍 Kênh: ${channel}`
          )]
        });
      } catch {}
      return;
    }

    // ===== PANEL ADMIN =====
    if (cmd === "paneladmin") {
      return handlePanelAdmin(i, { wallet, nohu, vipData, getBalance, setBalance });
    }

    // ===== ĐÁ GÀ =====
    if (cmd === "ga") {
      return handleDaGa(i, { getBalance, setBalance, formatMoney, client });
    }

    return i.editReply("❌ Lệnh chưa xử lý!");

  } catch (err) {
    console.error("[interactionCreate error]", err);
    try {
      if (i.deferred || i.replied) {
        return i.editReply("❌ Bot gặp lỗi!");
      } else {
        return i.reply({ content: "❌ Bot gặp lỗi!", ephemeral: true });
      }
    } catch {}
  }
});

client.login(config.token);
