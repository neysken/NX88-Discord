// ===================================================================
// MODULE PANEL ADMIN — paneladmin.js
// discord.js v14 | Node.js
// Command: /paneladmin — chỉ ADMIN_ID mới dùng được
// ===================================================================

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField
} = require("discord.js");

const fs   = require("fs");
const path = require("path");

// ===================================================================
// SECTION: CONFIG
// ===================================================================
let config = {};
try { config = require("./config.json"); } catch {}

// ADMIN_IDs: đọc từ config.json hoặc fallback mảng rỗng
// Thêm vào config.json: "adminIds": ["123456789", "987654321"]
const ADMIN_IDS = config.adminIds || [];

// ===================================================================
// SECTION: FILE UTILITY (standalone, không dùng save/load của index)
// ===================================================================
function saveJson(f, d) {
  const tmp = f + ".tmp";
  try {
    fs.writeFileSync(tmp, JSON.stringify(d, null, 2));
    fs.renameSync(tmp, f);
  } catch (err) {
    console.error(`[paneladmin save error] ${f}:`, err);
    try { fs.unlinkSync(tmp); } catch {}
  }
}

function loadJson(f, def = {}) {
  try {
    if (!fs.existsSync(f)) return def;
    return JSON.parse(fs.readFileSync(f, "utf8"));
  } catch {
    return def;
  }
}

// ===================================================================
// SECTION: ADMIN STATE — chế độ nhả/hút
// ===================================================================
let adminState = loadJson("adminState.json", {
  mode:           "normal",  // "normal" | "nha" | "hut"
  target:         0,         // mục tiêu (số tiền nhả hoặc hút)
  progress:       0,         // đã nhả/hút bao nhiêu rồi
  targetUserId:   null,      // null = toàn server | userId = chỉ 1 user
  targetUsername: null,      // tên hiển thị
  setAt:          null,      // timestamp lúc set
  setBy:          null       // userId admin set
});

function saveAdminState() { saveJson("adminState.json", adminState); }

// ===================================================================
// SECTION: PARSE MONEY SHORT — 1k/1m/1b/1t
// ===================================================================
function parseMoneyShort(str) {
  if (!str) return null;
  str = str.toString().trim().toLowerCase().replace(/,/g, "").replace(/\./g, "");
  const units = { k: 1_000, m: 1_000_000, b: 1_000_000_000, t: 1_000_000_000_000 };
  const match = str.match(/^(\d+(?:\.\d+)?)\s*([kmbt]?)$/);
  if (!match) return null;
  const num  = parseFloat(match[1]);
  const unit = units[match[2]] || 1;
  const result = Math.floor(num * unit);
  return isNaN(result) || result <= 0 ? null : result;
}

// ===================================================================
// SECTION: LOG DATA
// ===================================================================
let logData = loadJson("logData.json", {
  transactions: [],   // { ts, type, userId, username, amount, note }
  jackpots: [],
  errors: []
});

const MAX_LOG = 500; // giới hạn mỗi mảng log

function addLog(type, entry) {
  entry.ts   = Date.now();
  entry.type = type;
  if (!logData[type + "s"]) logData[type + "s"] = [];
  logData[type + "s"].unshift(entry);
  if (logData[type + "s"].length > MAX_LOG) logData[type + "s"].length = MAX_LOG;
  saveJson("logData.json", logData);
}

// ===================================================================
// SECTION: STATS — tổng hợp từ wallet + các file khác
// ===================================================================
function getSystemStats(wallet, nohu) {
  const totalBalance = Object.values(wallet).reduce((s, v) => s + Number(v || 0), 0);
  const playerCount  = Object.keys(wallet).length;
  const rtp = nohu.totalBet > 0
    ? ((nohu.totalPayout / nohu.totalBet) * 100).toFixed(2)
    : "0.00";

  return {
    totalBalance,
    playerCount,
    totalBet:     nohu.totalBet     || 0,
    totalPayout:  nohu.totalPayout  || 0,
    bankroll:     nohu.bankroll     || 0,
    rtp,
    mode:         adminState.mode,
    modeTarget:   adminState.target,
    modeProgress: adminState.progress
  };
}

function getTopPlayers(wallet, limit = 10) {
  return Object.entries(wallet)
    .map(([id, bal]) => ({ id, bal: Number(bal || 0) }))
    .sort((a, b) => b.bal - a.bal)
    .slice(0, limit);
}

function formatMoney(x) { return Number(x || 0).toLocaleString("vi-VN"); }

// ===================================================================
// SECTION: EMBED BUILDERS
// ===================================================================
function adminEmbed(title, color, desc) {
  return new EmbedBuilder()
    .setTitle(title)
    .setColor(color)
    .setDescription(desc)
    .setFooter({ text: "🛡️ Admin Panel • Royal Baccarat" })
    .setTimestamp();
}

function buildMainMenuEmbed(wallet, nohu) {
  const st = getSystemStats(wallet, nohu);
  const modeLabel = {
    normal: "⚪ Bình thường",
    nha:    `🟢 NHẢ — Mục tiêu: ${formatMoney(st.modeTarget)}$ | Đã nhả: ${formatMoney(st.modeProgress)}$`,
    hut:    `🔴 HÚT — Mục tiêu: ${formatMoney(st.modeTarget)}$ | Đã hút: ${formatMoney(st.modeProgress)}$`
  }[st.mode] || "⚪ Bình thường";

  return adminEmbed("🛡️ ADMIN PANEL", 0xe74c3c,
`**HỆ THỐNG**
━━━━━━━━━━━━━━
💰 Tổng số dư người chơi: **${formatMoney(st.totalBalance)}$**
👥 Tổng người chơi: **${st.playerCount}**
🏦 Bankroll: **${formatMoney(st.bankroll)}$**
📊 Tổng cược: **${formatMoney(st.totalBet)}$**
💸 Tổng nhả: **${formatMoney(st.totalPayout)}$**
📈 RTP thực tế: **${st.rtp}%**

**CHẾ ĐỘ HIỆN TẠI**
━━━━━━━━━━━━━━
${modeLabel}

━━━━━━━━━━━━━━
🔽 Chọn chức năng bên dưới:`
  );
}

function buildMainMenuRows() {
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("pa_mode").setLabel("⚙️ Chế độ Nhả/Hút").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("pa_stats").setLabel("📊 Thống kê người chơi").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("pa_log").setLabel("📋 Log hệ thống").setStyle(ButtonStyle.Secondary)
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("pa_top").setLabel("🏆 Bảng xếp hạng").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("pa_search").setLabel("🔍 Tìm kiếm user").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("pa_export").setLabel("💾 Export JSON").setStyle(ButtonStyle.Secondary)
  );
  return [row1, row2];
}

// ===================================================================
// SECTION: SUB-PANEL BUILDERS
// ===================================================================

// A. CHẾ ĐỘ NHẢ/HÚT
function buildModeEmbed() {
  const targetUser = adminState.targetUserId
    ? `👤 Target: <@${adminState.targetUserId}> (${adminState.targetUsername || adminState.targetUserId})`
    : `🌐 Target: **Toàn server**`;

  const modeText = {
    normal: "⚪ **Bình thường** — Bot hoạt động theo AI tự nhiên",
    nha:    `🟢 **NHẢ** — Mục tiêu: ${formatMoney(adminState.target)}$\n${targetUser}\n📈 Đã nhả: ${formatMoney(adminState.progress)}$ / ${formatMoney(adminState.target)}$`,
    hut:    `🔴 **HÚT** — Mục tiêu: ${formatMoney(adminState.target)}$\n${targetUser}\n📉 Đã hút: ${formatMoney(adminState.progress)}$ / ${formatMoney(adminState.target)}$`
  }[adminState.mode];

  const pct = adminState.target > 0
    ? Math.min(100, Math.round(adminState.progress / adminState.target * 100))
    : 0;

  const bar = "█".repeat(Math.round(pct / 10)) + "░".repeat(10 - Math.round(pct / 10));

  return adminEmbed("⚙️ QUẢN LÝ CHẾ ĐỘ NHẢ/HÚT", 0xf39c12,
`**CHẾ ĐỘ HIỆN TẠI**
━━━━━━━━━━━━━━
${modeText}

${adminState.mode !== "normal" ? `**TIẾN ĐỘ**\n[${bar}] ${pct}%\n` : ""}
━━━━━━━━━━━━━━
💡 Sau khi đạt mục tiêu, bot tự động về chế độ **Bình thường**.

⚙️ Chọn chế độ muốn áp dụng:`
  );
}

function buildModeRows() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("pa_mode_normal").setLabel("⚪ Bình thường").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("pa_mode_nha").setLabel("🟢 Chế độ NHẢ").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("pa_mode_hut").setLabel("🔴 Chế độ HÚT").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("pa_back").setLabel("◀ Quay lại").setStyle(ButtonStyle.Secondary)
  )];
}

// B. THỐNG KÊ
function buildStatsEmbed(wallet, nohu, vipData) {
  const st  = getSystemStats(wallet, nohu);
  const top = getTopPlayers(wallet, 5);
  const topLines = top.map((p, idx) =>
    `**${idx+1}.** <@${p.id}> — **${formatMoney(p.bal)}$**`
  ).join("\n");

  return adminEmbed("📊 THỐNG KÊ NGƯỜI CHƠI", 0x3498db,
`**TỔNG QUAN HỆ THỐNG**
━━━━━━━━━━━━━━
👥 Tổng người chơi: **${st.playerCount}**
💰 Tổng số dư: **${formatMoney(st.totalBalance)}$**
🏦 Bankroll bot: **${formatMoney(st.bankroll)}$**
📊 Tổng tiền cược: **${formatMoney(st.totalBet)}$**
💸 Tổng đã trả thưởng: **${formatMoney(st.totalPayout)}$**
📈 RTP thực tế: **${st.rtp}%**
💹 Lãi/lỗ bot: **${formatMoney(st.totalBet - st.totalPayout)}$**

**TOP 5 ĐẠI GIA**
━━━━━━━━━━━━━━
${topLines || "Chưa có dữ liệu"}

━━━━━━━━━━━━━━
Dùng 🔍 Tìm kiếm user để xem chi tiết từng người chơi.`
  );
}

function buildStatsRows() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("pa_top_bal").setLabel("🏆 Top số dư").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("pa_search").setLabel("🔍 Tìm user").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("pa_export").setLabel("💾 Export").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("pa_back").setLabel("◀ Quay lại").setStyle(ButtonStyle.Secondary)
  )];
}

// C. LOG
function buildLogEmbed() {
  const txLog = (logData.transactions || []).slice(0, 8)
    .map(l => {
      const d = new Date(l.ts).toLocaleString("vi-VN");
      return `\`${d}\` **${l.type}** | <@${l.userId}> | ${formatMoney(l.amount)}$${l.note ? ` | ${l.note}` : ""}`;
    }).join("\n") || "*(Chưa có log)*";

  const jackpotLog = (logData.jackpots || []).slice(0, 5)
    .map(l => {
      const d = new Date(l.ts).toLocaleString("vi-VN");
      return `\`${d}\` <@${l.userId}> jackpot **${formatMoney(l.amount)}$**`;
    }).join("\n") || "*(Chưa có jackpot)*";

  return adminEmbed("📋 LOG HỆ THỐNG", 0x9b59b6,
`**GIAO DỊCH GẦN NHẤT (8 lần cuối)**
━━━━━━━━━━━━━━
${txLog}

**JACKPOT GẦN NHẤT**
━━━━━━━━━━━━━━
${jackpotLog}`
  );
}

function buildLogRows() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("pa_log_tx").setLabel("💳 Log giao dịch").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("pa_log_jackpot").setLabel("🎰 Log jackpot").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("pa_back").setLabel("◀ Quay lại").setStyle(ButtonStyle.Secondary)
  )];
}

// ===================================================================
// SECTION: MAIN HANDLER — /paneladmin
// ===================================================================
async function handlePanelAdmin(i, { wallet, nohu, vipData, getBalance, setBalance }) {
  // Kiểm tra quyền: PermissionsBitField.Admin hoặc ADMIN_IDS
  const isAdmin = i.member?.permissions?.has(PermissionsBitField.Flags.Administrator)
    || ADMIN_IDS.includes(i.user.id);

  if (!isAdmin) {
    return i.editReply({ content: "❌ Bạn không có quyền dùng lệnh này!", ephemeral: true });
  }

  const msg = await i.editReply({
    embeds:     [buildMainMenuEmbed(wallet, nohu)],
    components: buildMainMenuRows(),
    fetchReply: true
  });

  // ===== COLLECTOR =====
  const col = msg.createMessageComponentCollector({
    filter: x => {
      if (x.user.id !== i.user.id) {
        x.reply({ content: "❌ Đây là panel của admin khác!", ephemeral: true }).catch(() => {});
        return false;
      }
      return true;
    },
    time: 5 * 60 * 1000 // 5 phút
  });

  col.on("collect", async btn => {
    // ── BACK ──
    if (btn.customId === "pa_back") {
      await btn.deferUpdate();
      await msg.edit({ embeds: [buildMainMenuEmbed(wallet, nohu)], components: buildMainMenuRows() });
      return;
    }

    // ── MENU: CHẾ ĐỘ ──
    if (btn.customId === "pa_mode") {
      await btn.deferUpdate();
      await msg.edit({ embeds: [buildModeEmbed()], components: buildModeRows() });
      return;
    }

    // ── SET NORMAL ──
    if (btn.customId === "pa_mode_normal") {
      await btn.deferUpdate();
      adminState.mode           = "normal";
      adminState.target         = 0;
      adminState.progress       = 0;
      adminState.targetUserId   = null;
      adminState.targetUsername = null;
      adminState.setBy          = i.user.id;
      adminState.setAt          = Date.now();
      saveAdminState();
      await msg.edit({ embeds: [buildModeEmbed()], components: buildModeRows() });
      return;
    }

    // ── SET NHẢ / HÚT — Modal 2 bước: tiền + user (optional) ──
    if (btn.customId === "pa_mode_nha" || btn.customId === "pa_mode_hut") {
      const type = btn.customId === "pa_mode_nha" ? "nha" : "hut";
      const modal = new ModalBuilder()
        .setCustomId(`pa_modal_mode_${type}`)
        .setTitle(type === "nha" ? "🟢 Đặt mục tiêu NHẢ" : "🔴 Đặt mục tiêu HÚT");
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("pa_target_input")
            .setLabel(type === "nha" ? "Nhả bao nhiêu? (VD: 50m, 1b)" : "Hút bao nhiêu? (VD: 30m, 500k)")
            .setPlaceholder("Hỗ trợ: 1k=1,000 | 1m=1,000,000 | 1b=1,000,000,000")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(15)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("pa_target_user")
            .setLabel("User ID cụ thể (để trống = toàn server)")
            .setPlaceholder("VD: 123456789012345678 — để trống nếu muốn áp dụng tất cả")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMinLength(0)
            .setMaxLength(25)
        )
      );
      await btn.showModal(modal);

      const ms = await i.awaitModalSubmit({
        filter: m => m.customId === `pa_modal_mode_${type}` && m.user.id === i.user.id,
        time: 60000
      }).catch(() => null);

      if (!ms) return;

      // Parse số tiền (hỗ trợ k/m/b)
      const rawAmount = ms.fields.getTextInputValue("pa_target_input").trim();
      const val = parseMoneyShort(rawAmount);
      if (!val || val < 1) return ms.reply({ content: "❌ Số tiền không hợp lệ!\nVD: 50m, 1b, 500k", ephemeral: true });

      // Parse userId (optional)
      const rawUser = ms.fields.getTextInputValue("pa_target_user").trim().replace(/[^0-9]/g, "");
      let targetUserId   = null;
      let targetUsername = null;
      if (rawUser) {
        try {
          const fetchedUser = await i.client.users.fetch(rawUser);
          targetUserId   = fetchedUser.id;
          targetUsername = fetchedUser.username;
        } catch {
          return ms.reply({ content: `❌ Không tìm thấy user ID: \`${rawUser}\``, ephemeral: true });
        }
      }

      await ms.deferUpdate();
      adminState.mode           = type;
      adminState.target         = val;
      adminState.progress       = 0;
      adminState.targetUserId   = targetUserId;
      adminState.targetUsername = targetUsername;
      adminState.setBy          = i.user.id;
      adminState.setAt          = Date.now();
      saveAdminState();
      await msg.edit({ embeds: [buildModeEmbed()], components: buildModeRows() });
      return;
    }

    // ── MENU: THỐNG KÊ ──
    if (btn.customId === "pa_stats") {
      await btn.deferUpdate();
      await msg.edit({ embeds: [buildStatsEmbed(wallet, nohu, vipData)], components: buildStatsRows() });
      return;
    }

    // ── TOP SỐ DƯ ──
    if (btn.customId === "pa_top_bal" || btn.customId === "pa_top") {
      await btn.deferUpdate();
      const top = getTopPlayers(wallet, 10);
      const lines = top.map((p, idx) =>
        `**${idx+1}.** <@${p.id}> — **${formatMoney(p.bal)}$**`
      ).join("\n");
      await msg.edit({
        embeds: [adminEmbed("🏆 TOP 10 SỐ DƯ CAO NHẤT", 0xf1c40f, lines || "Chưa có dữ liệu")],
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("pa_back").setLabel("◀ Quay lại").setStyle(ButtonStyle.Secondary)
        )]
      });
      return;
    }

    // ── TÌM KIẾM USER ──
    if (btn.customId === "pa_search") {
      const modal = new ModalBuilder()
        .setCustomId("pa_modal_search")
        .setTitle("🔍 Tìm kiếm người chơi");
      modal.addComponents(new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId("pa_search_id")
          .setLabel("Nhập User ID hoặc @mention")
          .setPlaceholder("VD: 123456789012345678")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMinLength(5)
          .setMaxLength(25)
      ));
      await btn.showModal(modal);

      const ms = await i.awaitModalSubmit({
        filter: m => m.customId === "pa_modal_search" && m.user.id === i.user.id,
        time: 60000
      }).catch(() => null);

      if (!ms) return;
      const rawId = ms.fields.getTextInputValue("pa_search_id").replace(/[^0-9]/g, "");
      if (!rawId) return ms.reply({ content: "❌ ID không hợp lệ!", ephemeral: true });

      await ms.deferUpdate();

      const bal   = getBalance(rawId);
      const vip   = vipData[rawId] ? Math.floor(vipData[rawId] / 100000000) + 1 : 1;
      const stats = nohu.userStats?.[rawId] || {};

      await msg.edit({
        embeds: [adminEmbed(`🔍 THÔNG TIN USER: ${rawId}`, 0x3498db,
`<@${rawId}>

💳 Số dư: **${formatMoney(bal)}$**
👑 VIP Level: **${Math.min(vip, 64)}**
📊 Tổng cược (slot): **${formatMoney(stats.totalBet || 0)}$**
🏆 Tổng thắng (slot): **${formatMoney(stats.totalWin || 0)}$**
🎰 Số lần quay: **${stats.spins || 0}**
🔥 Chuỗi thắng: **${stats.winStreak || 0}**
💀 Chuỗi thua: **${stats.loseStreak || 0}**`)],
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("pa_back").setLabel("◀ Quay lại").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId(`pa_export_user_${rawId}`).setLabel("💾 Export user").setStyle(ButtonStyle.Secondary)
        )]
      });
      return;
    }

    // ── EXPORT USER ──
    if (btn.customId.startsWith("pa_export_user_")) {
      await btn.deferUpdate();
      const uid  = btn.customId.replace("pa_export_user_", "");
      const data = {
        userId:   uid,
        balance:  getBalance(uid),
        vip:      vipData[uid] || 0,
        slotStats: nohu.userStats?.[uid] || {},
        exportAt: new Date().toISOString()
      };
      const json = JSON.stringify(data, null, 2);
      const buf  = Buffer.from(json, "utf8");
      await i.followUp({
        content: `📦 Export data user \`${uid}\``,
        files: [{ attachment: buf, name: `user_${uid}.json` }],
        ephemeral: true
      });
      return;
    }

    // ── LOG ──
    if (btn.customId === "pa_log") {
      await btn.deferUpdate();
      await msg.edit({ embeds: [buildLogEmbed()], components: buildLogRows() });
      return;
    }

    if (btn.customId === "pa_log_tx") {
      await btn.deferUpdate();
      const lines = (logData.transactions || []).slice(0, 15).map(l => {
        const d = new Date(l.ts).toLocaleString("vi-VN");
        return `\`${d}\` **${l.type}** | <@${l.userId}> | ${formatMoney(l.amount)}$`;
      }).join("\n") || "*(Chưa có log)*";
      await msg.edit({
        embeds: [adminEmbed("💳 LOG GIAO DỊCH (15 gần nhất)", 0x3498db, lines)],
        components: buildLogRows()
      });
      return;
    }

    if (btn.customId === "pa_log_jackpot") {
      await btn.deferUpdate();
      const lines = (logData.jackpots || []).slice(0, 15).map(l => {
        const d = new Date(l.ts).toLocaleString("vi-VN");
        return `\`${d}\` <@${l.userId}> jackpot **${formatMoney(l.amount)}$**`;
      }).join("\n") || "*(Chưa có jackpot)*";
      await msg.edit({
        embeds: [adminEmbed("🎰 LOG JACKPOT (15 gần nhất)", 0xf1c40f, lines)],
        components: buildLogRows()
      });
      return;
    }

    // ── EXPORT TOÀN BỘ ──
    if (btn.customId === "pa_export") {
      await btn.deferUpdate();
      const exportData = {
        wallet:    loadJson("wallet.json"),
        vipData:   loadJson("vipData.json"),
        nohuStats: loadJson("nohu.json"),
        adminState,
        exportAt:  new Date().toISOString()
      };
      const buf = Buffer.from(JSON.stringify(exportData, null, 2), "utf8");
      await i.followUp({
        content: "📦 Export toàn bộ dữ liệu hệ thống:",
        files: [{ attachment: buf, name: `export_${Date.now()}.json` }],
        ephemeral: true
      });
      return;
    }
  });

  col.on("end", () => msg.edit({ components: [] }).catch(() => {}));
}

// ===================================================================
// SECTION: ADMIN STATE API — dùng từ index.js để tích hợp AI slot
// ===================================================================

/**
 * Gọi sau mỗi lần spin — cập nhật progress nhả/hút.
 * totalReward > 0 → bot vừa nhả ra | totalReward === 0 → bot vừa hút vào
 * betAmount: tổng tiền cược vòng đó
 */
function updateAdminProgress(betAmount, totalReward) {
  if (adminState.mode === "normal") return;

  const delta = adminState.mode === "nha" ? totalReward : (betAmount - totalReward);
  if (delta > 0) {
    adminState.progress += delta;
    if (adminState.progress >= adminState.target) {
      adminState.mode     = "normal";
      adminState.progress = 0;
      adminState.target   = 0;
      console.log("[paneladmin] Đạt mục tiêu — trở về chế độ bình thường");
    }
    saveAdminState();
  }
}

/**
 * Trả về override mode cho AI slot engine.
 * @param {string} userId — userId của người đang spin
 * @returns "LOOSE" | "TIGHT" | null
 */
function getAdminModeOverride(userId) {
  if (adminState.mode === "normal") return null;
  // Nếu có targetUserId → chỉ áp dụng cho user đó
  if (adminState.targetUserId && userId !== adminState.targetUserId) return null;
  if (adminState.mode === "nha") return "LOOSE";
  if (adminState.mode === "hut") return "TIGHT";
  return null;
}

// ===================================================================
// SECTION: LOG API — gọi từ index.js
// ===================================================================
function logTransaction(userId, username, type, amount, note = "") {
  addLog("transaction", { userId, username, amount, note, subType: type });
}

function logJackpot(userId, username, amount) {
  addLog("jackpot", { userId, username, amount });
}

function logError(context, message) {
  addLog("error", { userId: "system", username: "system", amount: 0, note: `[${context}] ${message}` });
}

module.exports = {
  handlePanelAdmin,
  updateAdminProgress,
  getAdminModeOverride,
  logTransaction,
  logJackpot,
  logError,
  adminState
};
