// ===================================================================
// ===== MODULE ĐÁ GÀ CASINO — daga.js (VERSION 2.1) =====
// Production-ready | discord.js v14 | Node.js
//
// v2.1 CHANGES:
//  - Toàn bộ lệnh chọn gà qua Select Menu (không dùng ID)
//  - Pagination đầy đủ (◀ / ▶) cho kho >25 gà
//  - Label mobile-friendly: icon rarity + stats gọn
//  - buildChickenSelectMenu nâng cấp: page, filter, sort
//  - Tất cả sub: /ga daga, nangcap, nangdo, hochoi, choan,
//    muadoan, doan, muaskill, epskill, sell, choban đều dùng menu
// ===================================================================

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require("discord.js");

const fs = require("fs");

// ===================================================================
// SECTION: FILE UTILITY
// ===================================================================
function save(f, d) {
  const tmp = f + ".tmp";
  try {
    fs.writeFileSync(tmp, JSON.stringify(d, null, 2));
    fs.renameSync(tmp, f);
  } catch (err) {
    console.error(`[daga save error] ${f}:`, err);
    try { fs.unlinkSync(tmp); } catch {}
  }
}

function load(f) {
  try {
    if (!fs.existsSync(f)) return {};
    return JSON.parse(fs.readFileSync(f, "utf8"));
  } catch (err) {
    console.error(`[daga load error] ${f}:`, err);
    return {};
  }
}

// ===================================================================
// SECTION: DATABASE FILES
// ===================================================================
let chickenInventory = load("chickenInventory.json");
let chickenStats     = load("chickenStats.json");
let battleCooldown   = load("battleCooldown.json");
let eggStats         = load("eggStats.json");
let skillInventory   = load("skillInventory.json");
let foodInventory    = load("foodInventory.json");
let deadChicken      = load("deadChicken.json");
let marketplaceData  = load("marketplace.json");
let seasonData       = load("seasonData.json");
let prestigeData     = load("prestigeData.json");

// ===================================================================
// SECTION: ANTI-EXPLOIT MAPS
// ===================================================================
const battleLock      = new Map();
const marketplaceLock = new Set();
const commandCooldown = new Map();

// ===================================================================
// SECTION: CONSTANTS — RARITY
// ===================================================================
const RARITY = {
  COMMON:    { label: "⚪ Common",    color: 0x95a5a6, weight: 45,  statMult: 1.00, aura: "✨",  namePool: "common", icon: "⚪" },
  UNCOMMON:  { label: "🟢 Uncommon",  color: 0x2ecc71, weight: 25,  statMult: 1.15, aura: "🌿",  namePool: "common", icon: "🟢" },
  RARE:      { label: "🔵 Rare",      color: 0x3498db, weight: 15,  statMult: 1.35, aura: "💠",  namePool: "rare",   icon: "🔵" },
  EPIC:      { label: "🟣 Epic",      color: 0x9b59b6, weight: 9,   statMult: 1.60, aura: "💜",  namePool: "rare",   icon: "🟣" },
  LEGENDARY: { label: "🟡 Legendary", color: 0xf1c40f, weight: 4,   statMult: 2.00, aura: "👑",  namePool: "boss",   icon: "🟡" },
  MYTHIC:    { label: "🔴 Mythic",    color: 0xe74c3c, weight: 1.5, statMult: 2.60, aura: "🔴",  namePool: "boss",   icon: "🔴" },
  IMMORTAL:  { label: "🌈 Immortal",  color: 0xff6b9d, weight: 0.5, statMult: 3.50, aura: "🌈",  namePool: "boss",   icon: "🌈" }
};

// ===================================================================
// SECTION: CONSTANTS — TÊN GÀ
// ===================================================================
const CHICKEN_NAMES = {
  common: [
    "Tiểu Hắc","A Kê","Thiết Kê","Hỏa Vũ","Bạch Phong","Cuồng Trảo",
    "Thiên Kích","Xích Vũ","Kim Mao","Ma Kê","Lôi Phong","Hắc Mao",
    "Bạch Tinh","Xanh Lục","Hoàng Kim","Bạc Mao","Đỏ Trảo","Thiết Cánh",
    "Gió Bắc","Đêm Đen","Bình Minh","Hoàng Hôn","Sa Mạc","Băng Tuyết",
    "Lửa Đỏ","Sét Xanh","Mây Trắng","Đất Nâu","Sóng Biển","Núi Lửa",
    "Cát Vàng","Đêm Trắng","Mưa Đông","Gió Tây","Đông Phong","Nam Phong",
    "Ngọc Kê","Ngân Trảo","Thổ Kê","Thủy Kê","Mộc Kê","Kim Kê"
  ],
  rare: [
    "Huyết Ma Kê","Lôi Đình Kê","Hỏa Long Kê","Tử Điện Kê","Băng Phượng Kê",
    "Thần Kê","Chiến Thần Kê","Địa Ngục Kê","Hắc Long Kê","Thiên Đạo Kê",
    "Huyền Vũ Kê","Chu Tước Kê","Bạch Hổ Kê","Thanh Long Kê","Ngũ Sắc Kê",
    "Vạn Hỏa Kê","Bão Tố Kê","Lôi Thần Kê","Địa Chấn Kê","Thiên Lôi Kê",
    "Hắc Diệm Kê","Bạch Diệm Kê","Hồng Diệm Kê","Xanh Diệm Kê","Tím Diệm Kê",
    "Phong Lôi Kê","Thủy Hỏa Kê","Kim Mộc Kê","Thổ Thủy Kê","Vạn Năng Kê",
    "Long Diệm Kê","Phượng Hỏa Kê","Huyết Chiến Kê","Tử Thần Kê","Diêm La Kê"
  ],
  boss: [
    "Kê Vương","Kê Đế","Kê Thần","Hủy Diệt Kê","Thái Cổ Ma Kê",
    "Cửu Thiên Kê Đế","Vạn Giới Chiến Thần","Bất Diệt Kê Tổ","Hỗn Độn Ma Kê",
    "Thiên Địa Bất Nhân Kê","Vô Cực Thiên Đế","Tuyệt Thế Kê Vương",
    "Hoàng Thiên Bá Chủ","Long Hoàng Kê Đế","Thần Ma Nhất Thể"
  ]
};

// ===================================================================
// SECTION: CONSTANTS — HỆ (ELEMENT)
// ===================================================================
const ELEMENTS = {
  HOA:   { label: "🔥 Hỏa",   bonus: "crit",  bonusVal: 0.05, color: 0xe74c3c },
  THUY:  { label: "🌊 Thủy",  bonus: "hp",    bonusVal: 50,   color: 0x3498db },
  MOC:   { label: "🌿 Mộc",   bonus: "dodge", bonusVal: 0.05, color: 0x2ecc71 },
  KIM:   { label: "⚡ Kim",   bonus: "dmg",   bonusVal: 10,   color: 0xf1c40f },
  THO:   { label: "🌑 Thổ",   bonus: "armor", bonusVal: 15,   color: 0x8b4513 },
  PHONG: { label: "🌪️ Phong", bonus: "speed", bonusVal: 0.08, color: 0x87ceeb },
  DIEN:  { label: "⚡ Điện",  bonus: "crit",  bonusVal: 0.08, color: 0xffff00 },
  BANG:  { label: "❄️ Băng",  bonus: "armor", bonusVal: 20,   color: 0x00ffff }
};

// ===================================================================
// SECTION: CONSTANTS — SKILLS (50+ skill)
// ===================================================================
const SKILLS_POOL = {
  quick_jab:      { name: "⚔️ Quick Jab",       desc: "Tăng tốc độ, +1 lượt đánh",        rarity: "COMMON",    effect: "speed",      value: 0.10, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  basic_peck:     { name: "🐔 Basic Peck",        desc: "Đòn mổ cơ bản +10% damage",        rarity: "COMMON",    effect: "dmgBoost",   value: 0.10, cooldown: 0,  procRate: 1.0,  dmgMult: 1.1,  type: "passive"   },
  tough_feather:  { name: "🪶 Tough Feather",     desc: "Giảm damage nhận -8%",              rarity: "COMMON",    effect: "armor",      value: 0.08, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  keen_eye:       { name: "👁️ Keen Eye",          desc: "Tăng crit +5%",                     rarity: "COMMON",    effect: "crit",       value: 0.05, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  swift_foot:     { name: "🦶 Swift Foot",        desc: "Tăng né +5%",                       rarity: "COMMON",    effect: "dodge",      value: 0.05, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  crit_claw:      { name: "⚡ Crit Claw",         desc: "Tăng crit +12%",                    rarity: "UNCOMMON",  effect: "crit",       value: 0.12, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  iron_spur:      { name: "🔩 Iron Spur",         desc: "Giảm damage nhận -10%",             rarity: "UNCOMMON",  effect: "armor",      value: 0.10, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  poison_peck:    { name: "☠️ Poison Peck",       desc: "30% gây độc -5HP/lượt",            rarity: "UNCOMMON",  effect: "poison",     value: 5,    cooldown: 0,  procRate: 0.30, dmgMult: 1.0,  type: "active"    },
  counter_strike: { name: "🛡️ Counter Strike",   desc: "20% phản đòn 50% damage",           rarity: "UNCOMMON",  effect: "counter",    value: 0.50, cooldown: 0,  procRate: 0.20, dmgMult: 1.0,  type: "active"    },
  recovery:       { name: "✨ Recovery",           desc: "Hồi 8% HP mỗi lượt",               rarity: "UNCOMMON",  effect: "regen",      value: 0.08, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  iron_skin:      { name: "🛡️ Iron Skin",         desc: "Giảm damage nhận -14%",             rarity: "RARE",      effect: "armor",      value: 0.14, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  shadow_dodge:   { name: "👁️ Shadow Dodge",      desc: "Tăng né +14%",                      rarity: "RARE",      effect: "dodge",      value: 0.14, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  blood_feast:    { name: "🩸 Blood Feast",        desc: "Hút máu 10% damage",                rarity: "RARE",      effect: "lifesteal",  value: 0.10, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  piercing_spur:  { name: "☠️ Piercing Spur",     desc: "Xuyên giáp 12%",                   rarity: "RARE",      effect: "pierce",     value: 0.12, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  wind_rush:      { name: "🌪️ Wind Rush",         desc: "Tăng tốc 15%, đánh trước",          rarity: "RARE",      effect: "speed",      value: 0.15, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  fire_breath:    { name: "🔥 Fire Breath",        desc: "35% đốt đối thủ -8HP/lượt",        rarity: "RARE",      effect: "burn",       value: 8,    cooldown: 0,  procRate: 0.35, dmgMult: 1.2,  type: "active"    },
  ice_cage:       { name: "❄️ Ice Cage",           desc: "25% đóng băng bỏ 1 lượt đánh",    rarity: "RARE",      effect: "freeze",     value: 1,    cooldown: 2,  procRate: 0.25, dmgMult: 1.0,  type: "active"    },
  lightning_bolt: { name: "⚡ Lightning Bolt",    desc: "40% đánh thêm 60% damage",         rarity: "RARE",      effect: "lightning",  value: 0.60, cooldown: 0,  procRate: 0.40, dmgMult: 1.6,  type: "active"    },
  rage_burst:     { name: "🔥 Rage Burst",         desc: "HP<40% tăng damage +25%",           rarity: "EPIC",      effect: "rage",       value: 0.25, cooldown: 0,  procRate: 1.0,  dmgMult: 1.25, type: "passive"   },
  combo_kick:     { name: "💥 Combo Kick",         desc: "35% đánh 2 hit liên tiếp",          rarity: "EPIC",      effect: "combo",      value: 0.35, cooldown: 0,  procRate: 0.35, dmgMult: 1.0,  type: "active"    },
  void_strike:    { name: "🌑 Void Strike",        desc: "25% bỏ qua 50% giáp đối thủ",      rarity: "EPIC",      effect: "voidPierce", value: 0.50, cooldown: 0,  procRate: 0.25, dmgMult: 1.3,  type: "active"    },
  thunder_clap:   { name: "⚡ Thunder Clap",       desc: "Đánh tất cả — AOE damage",          rarity: "EPIC",      effect: "aoe",        value: 0.80, cooldown: 3,  procRate: 1.0,  dmgMult: 0.80, type: "active"    },
  berserker:      { name: "💢 Berserker",          desc: "HP<20% tăng damage +50%",           rarity: "EPIC",      effect: "berserk",    value: 0.50, cooldown: 0,  procRate: 1.0,  dmgMult: 1.50, type: "passive"   },
  vampiric_claw:  { name: "🩸 Vampiric Claw",      desc: "Hút máu 20% damage",                rarity: "EPIC",      effect: "lifesteal",  value: 0.20, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  time_warp:      { name: "⏳ Time Warp",          desc: "30% đánh 3 lượt liên tiếp",        rarity: "EPIC",      effect: "tripleHit",  value: 0.30, cooldown: 4,  procRate: 0.30, dmgMult: 0.70, type: "active"    },
  death_mark:     { name: "💀 Death Mark",         desc: "Đánh dấu: tăng 20% damage vào",    rarity: "EPIC",      effect: "mark",       value: 0.20, cooldown: 3,  procRate: 0.40, dmgMult: 1.2,  type: "active"    },
  soul_drain:     { name: "👻 Soul Drain",         desc: "15% drain 15% max HP đối thủ",     rarity: "EPIC",      effect: "drain",      value: 0.15, cooldown: 3,  procRate: 0.15, dmgMult: 1.0,  type: "active"    },
  golden_spur:    { name: "✨ Golden Spur",        desc: "Damage +20% toàn trận",             rarity: "LEGENDARY", effect: "dmgBoost",   value: 0.20, cooldown: 0,  procRate: 1.0,  dmgMult: 1.20, type: "passive"   },
  phoenix_rise:   { name: "🔥 Phoenix Rise",       desc: "1 lần/trận: hồi 50% HP khi chết",  rarity: "LEGENDARY", effect: "revive",     value: 0.50, cooldown: 99, procRate: 1.0,  dmgMult: 1.0,  type: "ultimate"  },
  absolute_dodge: { name: "💨 Absolute Dodge",     desc: "Né tránh +25% + phản đòn 30%",      rarity: "LEGENDARY", effect: "absodge",    value: 0.25, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  dragon_breath:  { name: "🐉 Dragon Breath",      desc: "50% damage + đốt 3 lượt",           rarity: "LEGENDARY", effect: "dragonFire", value: 0.50, cooldown: 4,  procRate: 1.0,  dmgMult: 1.50, type: "active"    },
  heaven_slash:   { name: "⚔️ Heaven Slash",       desc: "Đòn trời: damage × 2.5 lần",       rarity: "LEGENDARY", effect: "megaSlash",  value: 2.50, cooldown: 5,  procRate: 1.0,  dmgMult: 2.50, type: "active"    },
  invincible:     { name: "🛡️ Invincible",         desc: "2 lần/trận: miễn sát thương",      rarity: "LEGENDARY", effect: "shield",     value: 2,    cooldown: 3,  procRate: 1.0,  dmgMult: 1.0,  type: "ultimate"  },
  infinite_rage:  { name: "💢 Infinite Rage",      desc: "Mỗi lần bị đánh tăng 5% damage",   rarity: "LEGENDARY", effect: "stackRage",  value: 0.05, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "passive"   },
  apocalypse:     { name: "☠️ Apocalypse",         desc: "Đòn diệt thế: damage × 4",          rarity: "MYTHIC",    effect: "apocalypse", value: 4.0,  cooldown: 6,  procRate: 1.0,  dmgMult: 4.0,  type: "boss"      },
  time_stop:      { name: "⏰ Time Stop",           desc: "Dừng thời gian: đối thủ bỏ lượt",  rarity: "MYTHIC",    effect: "timeStop",   value: 2,    cooldown: 5,  procRate: 1.0,  dmgMult: 1.0,  type: "boss"      },
  god_mode:       { name: "✨ God Mode",            desc: "3 lượt bất tử + tăng 30% crit",    rarity: "MYTHIC",    effect: "godMode",    value: 3,    cooldown: 6,  procRate: 1.0,  dmgMult: 1.0,  type: "boss"      },
  soul_reaper:    { name: "💀 Soul Reaper",         desc: "20% một chiêu gây 45% max HP",     rarity: "MYTHIC",    effect: "reap",       value: 0.45, cooldown: 5,  procRate: 0.20, dmgMult: 1.0,  type: "boss"      },
  true_immortal:  { name: "🌈 True Immortal",      desc: "Hồi 15% HP mỗi lượt, miễn chết",   rarity: "IMMORTAL",  effect: "immortal",   value: 0.15, cooldown: 0,  procRate: 1.0,  dmgMult: 1.0,  type: "evolution" },
  universe_end:   { name: "🌌 Universe End",        desc: "Đòn cuối: damage × 10",             rarity: "IMMORTAL",  effect: "universeEnd",value: 10.0, cooldown: 10, procRate: 1.0,  dmgMult: 10.0, type: "evolution" },
  void_king:      { name: "👑 Void King",           desc: "Tất cả stat +30%, bất khả chiến",  rarity: "IMMORTAL",  effect: "voidKing",   value: 0.30, cooldown: 0,  procRate: 1.0,  dmgMult: 1.30, type: "evolution" }
};

// ===================================================================
// SECTION: CONSTANTS — FOOD SHOP
// ===================================================================
const FOOD_SHOP = {
  thoc:     { name: "🌽 Thóc Thường",        price: 50000,   hungerReduce: 20, dropLevel: true,  dropChance: 0.08, hpBonus: 0,  critBonus: 0    },
  thit:     { name: "🥩 Thịt VIP",           price: 200000,  hungerReduce: 35, dropLevel: false, dropChance: 0,    hpBonus: 5,  critBonus: 0    },
  vitamin:  { name: "💊 Vitamin Chiến Kê",   price: 300000,  hungerReduce: 30, dropLevel: false, dropChance: 0,    hpBonus: 0,  critBonus: 0.03 },
  moicuong: { name: "🔥 Mồi Cuồng Nộ",      price: 400000,  hungerReduce: 25, dropLevel: false, dropChance: 0,    hpBonus: 0,  critBonus: 0,   rageBonus: 0.05 },
  daitiec:  { name: "👑 Đại Tiệc Hoàng Kim", price: 1500000, hungerReduce: 100,dropLevel: false, dropChance: 0,    hpBonus: 15, critBonus: 0.05 }
};

// ===================================================================
// SECTION: CONSTANTS — SKILL BOOKS
// ===================================================================
const SKILL_BOOKS = {
  sach_thuong: { name: "📘 Sách Thường",  price: 500000,   rarities: ["COMMON","COMMON","UNCOMMON","RARE"]      },
  sach_hiem:   { name: "📗 Sách Hiếm",   price: 1500000,  rarities: ["UNCOMMON","RARE","RARE","EPIC"]          },
  sach_bian:   { name: "📕 Sách Bí Ẩn",  price: 4000000,  rarities: ["RARE","EPIC","EPIC","LEGENDARY"]         },
  sach_than:   { name: "📙 Sách Thần",   price: 12000000, rarities: ["LEGENDARY","LEGENDARY","MYTHIC"]         },
  sach_bat_tu: { name: "📔 Sách Bất Tử", price: 50000000, rarities: ["MYTHIC","IMMORTAL"]                      }
};

// ===================================================================
// SECTION: CONSTANTS — LEVEL RANK
// ===================================================================
const LEVEL_RANKS = [
  { min: 1,   max: 9,   rank: "🥉 Tân Thủ",     color: 0x95a5a6 },
  { min: 10,  max: 29,  rank: "🥈 Cao Thủ",     color: 0x2ecc71 },
  { min: 30,  max: 59,  rank: "🥇 Đại Sư",      color: 0x3498db },
  { min: 60,  max: 99,  rank: "💀 Huyền Thoại", color: 0x9b59b6 },
  { min: 100, max: 149, rank: "👑 Bá Chủ",      color: 0xf1c40f },
  { min: 150, max: 199, rank: "🔥 Chiến Thần",  color: 0xe74c3c },
  { min: 200, max: 999, rank: "🌌 Bất Tử",      color: 0xff6b9d }
];

// ===================================================================
// SECTION: CONSTANTS — NÂNG ĐỘ
// ===================================================================
const UPGRADE_TIERS = [
  { min: 1,   max: 5,   successRate: 0.90, failDrop: 0,    failDropAmt: 0,  breakRate: 0.00 },
  { min: 6,   max: 10,  successRate: 0.70, failDrop: 0.30, failDropAmt: 1,  breakRate: 0.00 },
  { min: 11,  max: 15,  successRate: 0.50, failDrop: 0.50, failDropAmt: 2,  breakRate: 0.02 },
  { min: 16,  max: 20,  successRate: 0.30, failDrop: 0.70, failDropAmt: 3,  breakRate: 0.05 },
  { min: 21,  max: 25,  successRate: 0.18, failDrop: 0.80, failDropAmt: 5,  breakRate: 0.08 },
  { min: 26,  max: 30,  successRate: 0.10, failDrop: 0.90, failDropAmt: 7,  breakRate: 0.12 },
  { min: 31,  max: 999, successRate: 0.05, failDrop: 1.00, failDropAmt: 10, breakRate: 0.20 }
];

// ===================================================================
// SECTION: PARSE MONEY SHORT
// ===================================================================
function parseMoney(str) {
  if (str === null || str === undefined) return null;
  str = str.toString().trim().toLowerCase().replace(/,/g, "");
  const match = str.match(/^(\d+(?:\.\d+)?)\s*([kmbt]?)$/);
  if (!match) { const n = parseInt(str.replace(/[^0-9]/g, "")); return isNaN(n)||n<=0?null:n; }
  const units = { k:1_000, m:1_000_000, b:1_000_000_000, t:1_000_000_000_000 };
  const result = Math.floor(parseFloat(match[1]) * (units[match[2]] || 1));
  return isNaN(result)||result<=0?null:result;
}

// ===================================================================
// SECTION: SAVE HELPERS
// ===================================================================
function saveInventory() { save("chickenInventory.json", chickenInventory); }
function saveStats()     { save("chickenStats.json",     chickenStats);     }
function saveCooldown()  { save("battleCooldown.json",   battleCooldown);   }
function saveFood()      { save("foodInventory.json",    foodInventory);    }
function saveSkill()     { save("skillInventory.json",   skillInventory);   }
function saveDead()      { save("deadChicken.json",      deadChicken);      }
function saveMarket()    { save("marketplace.json",      marketplaceData);  }
function saveSeason()    { save("seasonData.json",       seasonData);       }
function savePrestige()  { save("prestigeData.json",     prestigeData);     }

// ===================================================================
// SECTION: UTILITY HELPERS
// ===================================================================
function getUpgradeTier(level) {
  return UPGRADE_TIERS.find(t => level >= t.min && level <= t.max) || UPGRADE_TIERS[UPGRADE_TIERS.length - 1];
}

function getLevelRank(level) {
  return LEVEL_RANKS.find(r => level >= r.min && level <= r.max) || LEVEL_RANKS[LEVEL_RANKS.length - 1];
}

function expRequired(level) {
  return Math.floor(100 * Math.pow(1.12, level));
}

function randomChickenName(rarity) {
  const r    = RARITY[rarity];
  const pool = CHICKEN_NAMES[r.namePool] || CHICKEN_NAMES.common;
  return pool[Math.floor(Math.random() * pool.length)];
}

function randomElement() {
  const keys = Object.keys(ELEMENTS);
  return keys[Math.floor(Math.random() * keys.length)];
}

function calcPower(c) {
  const r = RARITY[c.rarity];
  let power = 0;
  power += (c.maxHp    || 0) * 1.0;
  power += (c.damage   || 0) * 8.0;
  power += (c.armor    || 0) * 4.0;
  power += (c.crit     || 0) * 500;
  power += (c.dodge    || 0) * 400;
  power += (c.pierce   || 0) * 300;
  power += (c.lifesteal|| 0) * 300;
  power += (c.level    || 1) * 50;
  power += (c.nangCap  || 0) * 200;
  power *= r.statMult;
  for (const sk of (c.skills || [])) {
    const s = SKILLS_POOL[sk];
    if (!s) continue;
    const rm = { COMMON:1, UNCOMMON:1.2, RARE:1.5, EPIC:2, LEGENDARY:3, MYTHIC:5, IMMORTAL:10 }[s.rarity] || 1;
    power += rm * 100;
  }
  const p = (prestigeData[c.ownerId] || {}).prestige || 0;
  power *= (1 + p * 0.1);
  return Math.round(power);
}

function createChicken(tier = 0, userId = null, overrideRarity = null) {
  let rarity;
  if (overrideRarity) {
    rarity = overrideRarity;
  } else {
    const weightTable = {
    COMMON:    Math.max(2,  45 - tier * 8),
    UNCOMMON:  Math.min(40, 25 + tier * 3),
    RARE:      Math.min(35, 15 + tier * 4),
    EPIC:      Math.min(25, 9  + tier * 3),
    LEGENDARY: Math.min(18, 4  + tier * 2),
    MYTHIC:    Math.min(12, 1.5+ tier * 1.5),
    IMMORTAL:  Math.min(8,  0.5+ tier * 0.8)
  };

  const total = Object.values(weightTable).reduce((a, b) => a + b, 0);
  let roll   = Math.random() * total;
  rarity = "COMMON";
  for (const [r, w] of Object.entries(weightTable)) {
    roll -= w;
    if (roll <= 0) { rarity = r; break; }
    }
  }

  const r    = RARITY[rarity];
  const elem = randomElement();
  const e    = ELEMENTS[elem];

  const base = {
    COMMON:    { hp: 80,  dmg: 15, armor: 5,  crit: 0.08, dodge: 0.06, pierce: 0.02, lifesteal: 0    },
    UNCOMMON:  { hp: 100, dmg: 20, armor: 8,  crit: 0.11, dodge: 0.09, pierce: 0.04, lifesteal: 0    },
    RARE:      { hp: 130, dmg: 28, armor: 12, crit: 0.15, dodge: 0.12, pierce: 0.07, lifesteal: 0.03 },
    EPIC:      { hp: 170, dmg: 38, armor: 18, crit: 0.20, dodge: 0.16, pierce: 0.10, lifesteal: 0.06 },
    LEGENDARY: { hp: 220, dmg: 52, armor: 26, crit: 0.28, dodge: 0.21, pierce: 0.14, lifesteal: 0.10 },
    MYTHIC:    { hp: 300, dmg: 72, armor: 38, crit: 0.36, dodge: 0.27, pierce: 0.20, lifesteal: 0.15 },
    IMMORTAL:  { hp: 420, dmg:100, armor: 55, crit: 0.45, dodge: 0.35, pierce: 0.28, lifesteal: 0.22 }
  }[rarity];

  const jitter = () => 1 + (Math.random() * 0.16 - 0.08);

  let hp     = Math.round(base.hp    * r.statMult * jitter());
  let dmg    = Math.round(base.dmg   * r.statMult * jitter());
  let armor  = Math.round(base.armor * r.statMult * jitter());
  let crit   = parseFloat((base.crit   * jitter()).toFixed(3));
  let dodge  = parseFloat((base.dodge  * jitter()).toFixed(3));
  let pierce = parseFloat((base.pierce * jitter()).toFixed(3));
  let ls     = parseFloat((base.lifesteal).toFixed(3));

  if (e.bonus === "hp")        hp    += e.bonusVal;
  else if (e.bonus === "dmg")  dmg   += e.bonusVal;
  else if (e.bonus === "crit") crit   = parseFloat((crit + e.bonusVal).toFixed(3));
  else if (e.bonus === "dodge")dodge  = parseFloat((dodge + e.bonusVal).toFixed(3));
  else if (e.bonus === "armor")armor += e.bonusVal;

  const id = `ga_${Date.now()}_${Math.floor(Math.random() * 99999)}`;

  return {
    id,
    ownerId:       userId,
    name:          randomChickenName(rarity),
    rarity,
    element:       elem,
    level:         1,
    exp:           0,
    nangCap:       0,
    hunger:        0,
    hp,
    maxHp:         hp,
    damage:        dmg,
    armor,
    crit,
    dodge,
    pierce,
    lifesteal:     ls,
    skills:        [],
    skillSlots:    6,
    aura:          r.aura,
    battleCount:   0,
    winCount:      0,
    loseCount:     0,
    isDead:        false,
    injured:       false,
    injuredUntil:  0,
    phoenixUsed:   false,
    shieldLeft:    0,
    revived:       false,
    stackRageCount:0
  };
}

function getAliveChickens(userId) {
  return (chickenInventory[userId] || []).filter(c => !c.isDead);
}

function findChicken(userId, chickenId) {
  return (chickenInventory[userId] || []).find(c => c.id === chickenId);
}

function canBattle(c) {
  if (c.isDead) return "💀 Gà đã chết";
  if (c.hunger >= 90) return "😵 Gà đói quá (≥90%)";
  if (c.injured && Date.now() < c.injuredUntil) {
    const mins = Math.ceil((c.injuredUntil - Date.now()) / 60000);
    return `🩸 Gà bị thương, cần ${mins} phút`;
  }
  const cd = battleCooldown[c.id] || 0;
  if (Date.now() - cd < 60000) {
    const secs = Math.ceil((60000 - (Date.now() - cd)) / 1000);
    return `⏳ Cần nghỉ ${secs}s`;
  }
  return null;
}

function gaEmbed(title, color, desc) {
  return new EmbedBuilder()
    .setTitle(title)
    .setColor(color)
    .setDescription(desc)
    .setFooter({ text: "🐔 Royal Cockfight Arena" })
    .setTimestamp();
}

// ── HELPER: Build quantity buttons + custom input ──
function buildQtyButtons(customIdPrefix, price, bal, style = {}) {
  const s = {
    x1:  style.x1  ?? ButtonStyle.Secondary,
    x3:  style.x3  ?? ButtonStyle.Primary,
    x5:  style.x5  ?? ButtonStyle.Success,
    x10: style.x10 ?? ButtonStyle.Danger,
  };
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`${customIdPrefix}_1`).setLabel(`x1 — ${formatMoney(price)}$`).setStyle(s.x1).setEmoji("🛒").setDisabled(bal < price),
      new ButtonBuilder().setCustomId(`${customIdPrefix}_3`).setLabel(`x3 — ${formatMoney(price*3)}$`).setStyle(s.x3).setEmoji("🛒").setDisabled(bal < price*3),
      new ButtonBuilder().setCustomId(`${customIdPrefix}_5`).setLabel(`x5 — ${formatMoney(price*5)}$`).setStyle(s.x5).setEmoji("🛒").setDisabled(bal < price*5),
      new ButtonBuilder().setCustomId(`${customIdPrefix}_10`).setLabel(`x10 — ${formatMoney(price*10)}$`).setStyle(s.x10).setEmoji("🛒").setDisabled(bal < price*10)
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`${customIdPrefix}_custom`).setLabel("✏️ Nhập số lượng").setStyle(ButtonStyle.Secondary).setDisabled(bal < price)
    )
  ];
}

function checkCooldown(userId, cmd, ms = 3000) {
  const key = `${userId}_${cmd}`;
  const now = Date.now();
  if (commandCooldown.has(key) && now - commandCooldown.get(key) < ms) {
    return Math.ceil((ms - (now - commandCooldown.get(key))) / 1000);
  }
  commandCooldown.set(key, now);
  return 0;
}

async function broadcast(client, guildId, channelId, message) {
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return;
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return;
    await channel.send(message);
  } catch {}
}

// ===================================================================
// SECTION: SELECT MENU BUILDER — CẢI TIẾN ĐẦY ĐỦ
// ===================================================================

/**
 * Tạo 1 option gà cho select menu — mobile-friendly, không dùng ID.
 * Label format: [icon_rarity] Tên Gà +N | LvXX [cảnh báo]
 * Desc  format: ❤️HP ⚔️DMG 🏆Power | Hệ | trạng thái
 */
function buildChickenOption(c) {
  const r     = RARITY[c.rarity];
  const elem  = ELEMENTS[c.element] || { label: "❓" };
  const power = calcPower({ ...c, ownerId: c.ownerId });
  const nc    = c.nangCap > 0 ? ` +${c.nangCap}` : "";

  // Cảnh báo trạng thái
  const warns = [];
  if (c.hunger >= 70)                                    warns.push("⚠️Đói");
  if (c.injured && Date.now() < c.injuredUntil)          warns.push("🩸Thương");
  if (battleCooldown[c.id] && Date.now() - battleCooldown[c.id] < 60000) warns.push("⏳CD");
  const warnStr = warns.length ? " " + warns.join(" ") : "";

  // Label: icon_rarity + tên + nâng độ + level + cảnh báo (max 100 ký tự)
  const label = `${r.icon} ${c.name}${nc} | Lv${c.level}${warnStr}`.slice(0, 100);

  // Desc: stats chính + hệ + power (max 100 ký tự)
  const elemShort = elem.label.split(" ")[0]; // lấy icon hệ thôi
  const desc  = `❤️${c.hp}/${c.maxHp} ⚔️${c.damage} 🛡️${c.armor} 🏆${power.toLocaleString()} ${elemShort}`.slice(0, 100);

  return new StringSelectMenuOptionBuilder()
    .setLabel(label)
    .setDescription(desc)
    .setValue(c.id);
}

/**
 * Tạo select menu + nút phân trang cho danh sách gà.
 * Trả về { selectRow, navRow, totalPages, currentPage }
 *
 * @param {string}   customId   - customId của select menu
 * @param {Array}    chickens   - mảng gà (đã filter, đã sort)
 * @param {string}   placeholder
 * @param {number}   page       - trang hiện tại (0-indexed)
 * @param {string}   pagePrefix - prefix cho button customId phân trang
 */
function buildChickenSelectPage(customId, chickens, placeholder, page = 0, pagePrefix = "ga_page") {
  const PAGE_SIZE   = 25; // Discord limit
  const totalPages  = Math.max(1, Math.ceil(chickens.length / PAGE_SIZE));
  const safePage    = Math.max(0, Math.min(page, totalPages - 1));
  const pageChickens = chickens.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  if (pageChickens.length === 0) return { selectRow: null, navRow: null, totalPages, currentPage: safePage };

  const options = pageChickens.map(c => buildChickenOption(c));

  const selectRow = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder(placeholder || `🐔 Chọn gà... (trang ${safePage + 1}/${totalPages})`)
      .addOptions(options)
  );

  // Nút phân trang (chỉ hiện nếu có >1 trang)
  let navRow = null;
  if (totalPages > 1) {
    const buttons = [];
    if (safePage > 0) {
      buttons.push(
        new ButtonBuilder()
          .setCustomId(`${pagePrefix}_prev_${safePage}`)
          .setLabel(`◀ Trang ${safePage}`)
          .setStyle(ButtonStyle.Secondary)
      );
    }
    buttons.push(
      new ButtonBuilder()
        .setCustomId(`${pagePrefix}_info`)
        .setLabel(`📄 ${safePage + 1} / ${totalPages}`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );
    if (safePage < totalPages - 1) {
      buttons.push(
        new ButtonBuilder()
          .setCustomId(`${pagePrefix}_next_${safePage}`)
          .setLabel(`Trang ${safePage + 2} ▶`)
          .setStyle(ButtonStyle.Secondary)
      );
    }
    navRow = new ActionRowBuilder().addComponents(buttons);
  }

  return { selectRow, navRow, totalPages, currentPage: safePage };
}

/**
 * Helper: hiển thị embed chọn gà với phân trang.
 * Tự động xử lý nút ◀▶ và trả về chickenId đã chọn qua Promise.
 *
 * @param {Message} msg          - message đang edit
 * @param {string}  userId       - id người chơi
 * @param {Array}   chickens     - danh sách gà đã filter
 * @param {string}  embedTitle   - tiêu đề embed
 * @param {string}  embedDesc    - mô tả embed
 * @param {number}  embedColor   - màu embed
 * @param {string}  selectId     - customId select menu
 * @param {string}  placeholder  - placeholder select
 * @param {string}  pagePrefix   - prefix nút phân trang
 * @param {number}  timeout      - ms timeout (default 45000)
 * @returns {Promise<string|null>} chickenId hoặc null nếu timeout
 */
async function awaitChickenSelect(msg, userId, chickens, embedTitle, embedDesc, embedColor, selectId, placeholder, pagePrefix, timeout = 45000) {
  let currentPage = 0;

  const renderPage = async () => {
    const { selectRow, navRow, totalPages, currentPage: cp } = buildChickenSelectPage(
      selectId, chickens, placeholder, currentPage, pagePrefix
    );
    currentPage = cp;

    const components = [];
    if (selectRow) components.push(selectRow);
    if (navRow)    components.push(navRow);

    const pageInfo = totalPages > 1 ? `\n📄 Trang **${cp + 1}/${totalPages}** | Tổng **${chickens.length}** gà` : "";

    await msg.edit({
      embeds: [gaEmbed(embedTitle, embedColor, embedDesc + pageInfo)],
      components
    });
  };

  await renderPage();

  return new Promise(resolve => {
    const col = msg.createMessageComponentCollector({
      filter: x => x.user.id === userId && (x.customId === selectId || x.customId.startsWith(pagePrefix)),
      time: timeout
    });

    col.on("collect", async btn => {
      await btn.deferUpdate();

      // Nút phân trang
      if (btn.customId.startsWith(pagePrefix + "_prev_")) {
        const p = parseInt(btn.customId.split("_").pop());
        currentPage = Math.max(0, p - 1);
        await renderPage();
        return;
      }
      if (btn.customId.startsWith(pagePrefix + "_next_")) {
        const p = parseInt(btn.customId.split("_").pop());
        currentPage = p + 1;
        await renderPage();
        return;
      }

      // Chọn gà
      if (btn.customId === selectId) {
        col.stop("selected");
        resolve(btn.values[0]);
      }
    });

    col.on("end", (_, reason) => {
      if (reason !== "selected") {
        msg.edit({ components: [] }).catch(() => {});
        resolve(null);
      }
    });
  });
}

// ===================================================================
// SECTION: BATTLE ENGINE
// ===================================================================
function simulateAttack(attacker, defender, turnNum) {
  const lines = [];

  if (defender.poisonStacks > 0) {
    const poisonDmg = defender.poisonStacks * 5;
    defender.hp -= poisonDmg;
    lines.push(`☠️ Độc gây **${poisonDmg} HP** (${defender.poisonStacks} stack)`);
    defender.poisonStacks = Math.max(0, defender.poisonStacks - 1);
  }
  if (defender.burnStacks > 0) {
    const burnDmg = defender.burnStacks * 8;
    defender.hp -= burnDmg;
    lines.push(`🔥 Đốt gây **${burnDmg} HP** (${defender.burnStacks} stack)`);
    defender.burnStacks = Math.max(0, defender.burnStacks - 1);
  }

  if (attacker.timeStopTurns > 0) {
    attacker.timeStopTurns--;
    lines.push(`⏰ **Time Stop** — ${defender.name} bỏ lượt!`);
    defender.hp = Math.max(0, defender.hp);
    attacker.hp = Math.max(0, attacker.hp);
    lines.push(`❤️ **${defender.name}** còn **${defender.hp}** HP`);
    return { lines, dmgDealt: 0 };
  }

  if (attacker.godModeTurns > 0) {
    attacker.godModeTurns--;
    if (turnNum % 2 === 0) {
      lines.push(`✨ **God Mode** bảo vệ ${attacker.name}!`);
      defender.hp = Math.max(0, defender.hp);
      attacker.hp = Math.max(0, attacker.hp);
      lines.push(`❤️ **${defender.name}** còn **${defender.hp}** HP`);
      return { lines, dmgDealt: 0 };
    }
  }

  const hungerPenalty = Math.max(0.5, 1 - (attacker.hunger / 200));
  let dmg = Math.round(attacker.damage * hungerPenalty);

  if (attacker.skills.includes("golden_spur"))  dmg = Math.round(dmg * 1.20);
  if (attacker.skills.includes("basic_peck"))   dmg = Math.round(dmg * 1.10);
  if (attacker.skills.includes("void_king"))    dmg = Math.round(dmg * 1.30);
  if (attacker.skills.includes("infinite_rage") && attacker.stackRageCount > 0) {
    dmg = Math.round(dmg * (1 + attacker.stackRageCount * 0.05));
  }

  const hpRatio = attacker.hp / attacker.maxHp;
  if (attacker.skills.includes("rage_burst") && hpRatio < 0.4) {
    dmg = Math.round(dmg * 1.25);
    lines.push("🔥 **Rage Burst** kích hoạt!");
  }
  if (attacker.skills.includes("berserker") && hpRatio < 0.2) {
    dmg = Math.round(dmg * 1.50);
    lines.push("💢 **Berserker** kích hoạt — cuồng nộ!");
  }

  let critChance = attacker.crit;
  if (attacker.skills.includes("crit_claw")) critChance += 0.12;
  if (attacker.skills.includes("keen_eye"))  critChance += 0.05;
  if (attacker.godModeCrit)                  critChance += 0.30;
  const isCrit = Math.random() < critChance;
  if (isCrit) { dmg = Math.round(dmg * 1.9); lines.push(`⚡ **CRIT!** +90% damage!`); }

  let armorReduce = Math.round(defender.armor * (1 - (attacker.pierce || 0)));
  if (attacker.skills.includes("void_strike") && Math.random() < 0.25) {
    armorReduce = Math.round(armorReduce * 0.50);
    lines.push(`🌑 **Void Strike** xuyên giáp!`);
  }
  if (attacker.skills.includes("piercing_spur")) armorReduce = Math.round(armorReduce * 0.88);
  dmg = Math.max(1, dmg - armorReduce);

  if (attacker.skills.includes("combo_kick") && Math.random() < 0.35) {
    lines.push(`💥 **Combo Kick** kích hoạt!`);
    attacker._comboExtraDmg = Math.max(1, Math.round(dmg * 0.75));
  }

  if (attacker.skills.includes("heaven_slash") && !attacker._heavenUsed && Math.random() < 0.30) {
    dmg = Math.round(dmg * 2.5);
    lines.push(`⚔️ **Heaven Slash** — đòn trời!`);
    attacker._heavenUsed = true;
  }

  if (attacker.skills.includes("dragon_breath") && !attacker._dragonUsed && Math.random() < 0.40) {
    dmg = Math.round(dmg * 1.50);
    defender.burnStacks = (defender.burnStacks || 0) + 3;
    lines.push(`🐉 **Dragon Breath** — đốt 3 lượt!`);
    attacker._dragonUsed = true;
  }

  let dodgeChance = defender.dodge;
  if (defender.skills.includes("shadow_dodge"))   dodgeChance += 0.14;
  if (defender.skills.includes("swift_foot"))     dodgeChance += 0.05;
  if (defender.skills.includes("absolute_dodge")) dodgeChance += 0.25;
  const isDodged = Math.random() < dodgeChance;

  if (isDodged) {
    lines.push(`👁️ **${defender.name}** né hụt đòn!`);
    if (defender.skills.includes("absolute_dodge") && Math.random() < 0.30) {
      const cd = Math.max(1, Math.round(attacker.damage * 0.30));
      attacker.hp -= cd;
      lines.push(`🛡️ **Absolute Dodge** phản đòn **${cd} HP!**`);
    }
    if (defender.skills.includes("counter_strike") && Math.random() < 0.20) {
      const cd = Math.max(1, Math.round(attacker.damage * 0.50));
      attacker.hp -= cd;
      lines.push(`🛡️ **Counter Strike** phản đòn **${cd} HP!**`);
    }
  } else {
    if (defender.shieldLeft > 0) {
      defender.shieldLeft--;
      lines.push(`🛡️ **Invincible** chặn đòn! (còn ${defender.shieldLeft} lần)`);
    } else {
      defender.hp -= dmg;
      lines.push(`💥 **${attacker.name}** gây **${dmg} HP**`);

      if (attacker._comboExtraDmg) {
        const cd2 = attacker._comboExtraDmg;
        delete attacker._comboExtraDmg;
        defender.hp -= cd2;
        lines.push(`💥 **Combo Hit 2:** **${cd2} HP**`);
      }

      if (attacker.skills.includes("time_warp") && Math.random() < 0.30) {
        const d3 = Math.max(1, Math.round(dmg * 0.70));
        defender.hp -= d3 * 2;
        lines.push(`⏳ **Time Warp** — 3 hit liên tiếp! **${d3 * 2} HP** extra`);
      }

      if (attacker.skills.includes("apocalypse") && Math.random() < 0.15) {
        const ad = Math.round(attacker.damage * 4);
        defender.hp -= ad;
        lines.push(`☠️ **APOCALYPSE!** Đòn diệt thế **${ad} HP!!!**`);
      }

      if (attacker.skills.includes("universe_end") && !attacker._universeUsed) {
        const ud = Math.round(attacker.damage * 10);
        defender.hp -= ud;
        lines.push(`🌌 **UNIVERSE END!!!** Đòn cuối **${ud} HP!!!**`);
        attacker._universeUsed = true;
      }

      if (attacker.skills.includes("soul_reaper") && Math.random() < 0.20) {
        const rd = Math.round(defender.maxHp * 0.45);
        defender.hp -= rd;
        lines.push(`💀 **Soul Reaper** cắt **45% max HP = ${rd}!**`);
      }

      let ls = attacker.lifesteal || 0;
      if (attacker.skills.includes("blood_feast"))   ls += 0.10;
      if (attacker.skills.includes("vampiric_claw")) ls += 0.20;
      if (attacker.skills.includes("true_immortal")) ls += 0.15;
      if (ls > 0) {
        const heal = Math.round(dmg * ls);
        attacker.hp = Math.min(attacker.maxHp, attacker.hp + heal);
        lines.push(`🩸 **Hút máu** +**${heal} HP**`);
      }

      if (attacker.skills.includes("true_immortal")) {
        const tr = Math.round(attacker.maxHp * 0.15);
        attacker.hp = Math.min(attacker.maxHp, attacker.hp + tr);
        lines.push(`🌈 **True Immortal** hồi **${tr} HP**`);
      }

      if (attacker.skills.includes("poison_peck") && Math.random() < 0.30) {
        defender.poisonStacks = (defender.poisonStacks || 0) + 1;
        lines.push(`☠️ **Poison Peck** gây độc! (${defender.poisonStacks} stack)`);
      }

      if (attacker.skills.includes("fire_breath") && Math.random() < 0.35) {
        defender.burnStacks = (defender.burnStacks || 0) + 1;
        lines.push(`🔥 **Fire Breath** đốt! (${defender.burnStacks} stack)`);
      }

      if (attacker.skills.includes("death_mark") && Math.random() < 0.40) {
        attacker._deathMarkDmgBonus = (attacker._deathMarkDmgBonus || 0) + 0.20;
        lines.push(`💀 **Death Mark** — tăng 20% damage tích lũy`);
      }

      if (defender.skills.includes("infinite_rage")) {
        defender.stackRageCount = (defender.stackRageCount || 0) + 1;
      }
    }
  }

  if (defender.hp <= 0 && defender.skills.includes("phoenix_rise") && !defender.phoenixUsed) {
    defender.hp          = Math.round(defender.maxHp * 0.50);
    defender.phoenixUsed = true;
    lines.push(`🔥 **PHOENIX RISE!** ${defender.name} hồi sinh với **${defender.hp} HP!!!**`);
  }

  if (attacker.skills.includes("soul_drain") && Math.random() < 0.15) {
    const sd = Math.round(defender.maxHp * 0.15);
    defender.hp -= sd;
    attacker.hp = Math.min(attacker.maxHp, attacker.hp + sd);
    lines.push(`👻 **Soul Drain** hút **${sd} HP** từ ${defender.name}!`);
  }

  defender.hp = Math.max(0, defender.hp);
  attacker.hp = Math.max(0, attacker.hp);

  const audienceLines = [
    "*😱 \"Kèo này căng quá!\"*", "*🔥 \"CRIT hay vậy trời!\"*",
    "*💀 \"1 HP còn sống!\"*",    "*🐔 \"Gà nhà tao vô địch!\"*",
    "*⚡ \"Lật kèo bây giờ!\"*",  "*🎰 \"Ăn tiền rồi!\"*",
    "*😤 \"Thua là cúp nóc!\"*",  "*🤑 \"Bet tất thắng!\"*"
  ];
  if (Math.random() < 0.25) lines.push(audienceLines[Math.floor(Math.random() * audienceLines.length)]);

  lines.push(`❤️ **${defender.name}** còn **${defender.hp}** HP`);
  return { lines, dmgDealt: dmg };
}

async function runBattle(msg, p1User, p2User, c1orig, c2orig) {
  let p1Wins = 0, p2Wins = 0;

  for (let round = 1; round <= 3; round++) {
    const ga1 = {
      ...c1orig, hp: c1orig.hp, skills: [...(c1orig.skills || [])],
      poisonStacks:0, burnStacks:0, timeStopTurns:0, godModeTurns:0,
      godModeCrit:false, shieldLeft:0, phoenixUsed:false, stackRageCount:0,
      _heavenUsed:false, _dragonUsed:false, _universeUsed:false, _deathMarkDmgBonus:0
    };
    const ga2 = {
      ...c2orig, hp: c2orig.hp, skills: [...(c2orig.skills || [])],
      poisonStacks:0, burnStacks:0, timeStopTurns:0, godModeTurns:0,
      godModeCrit:false, shieldLeft:0, phoenixUsed:false, stackRageCount:0,
      _heavenUsed:false, _dragonUsed:false, _universeUsed:false, _deathMarkDmgBonus:0
    };

    if (ga1.skills.includes("god_mode")) { ga1.godModeTurns = 3; ga1.godModeCrit = true; }
    if (ga2.skills.includes("god_mode")) { ga2.godModeTurns = 3; ga2.godModeCrit = true; }
    if (ga1.skills.includes("invincible")) ga1.shieldLeft = 2;
    if (ga2.skills.includes("invincible")) ga2.shieldLeft = 2;

    await new Promise(r => setTimeout(r, 1200));
    const roundLog = [];
    let roundWinner = null;

    for (let turn = 1; turn <= 15 && ga1.hp > 0 && ga2.hp > 0; turn++) {
      const isP1Turn = turn % 2 === 1;
      const attacker = isP1Turn ? ga1 : ga2;
      const defender = isP1Turn ? ga2 : ga1;

      roundLog.push(`\n🐔 **${attacker.name}** tấn công!`);
      const res = simulateAttack(attacker, defender, turn);
      roundLog.push(...res.lines);

      await new Promise(r => setTimeout(r, 1300));
      try {
        const recentLines = roundLog.slice(-10).join("\n");
        await msg.edit({
          embeds: [gaEmbed(
            `⚔️ ROUND ${round} | LƯỢT ${turn}`,
            0xe74c3c,
            `🐔 **${ga1.name}** (${p1User}) ❤️ ${Math.max(0, ga1.hp)}/${c1orig.hp}\n` +
            `🐓 **${ga2.name}** (${p2User}) ❤️ ${Math.max(0, ga2.hp)}/${c2orig.hp}\n\n` +
            recentLines
          )]
        });
      } catch {}

      if (defender.hp <= 0) { roundWinner = isP1Turn ? "p1" : "p2"; break; }
    }

    if (!roundWinner) roundWinner = ga1.hp >= ga2.hp ? "p1" : "p2";
    if (roundWinner === "p1") { p1Wins++; roundLog.push(`\n🏁 **${ga1.name}** thắng Round ${round}!`); }
    else                      { p2Wins++; roundLog.push(`\n🏁 **${ga2.name}** thắng Round ${round}!`); }
    if (p1Wins === 2 || p2Wins === 2) break;

    await new Promise(r => setTimeout(r, 1500));
  }

  return { p1Wins, p2Wins };
}

// ===================================================================
// SECTION: MARKETPLACE HELPERS
// ===================================================================
function newListingId() {
  return `list_${Date.now()}_${Math.floor(Math.random() * 9999)}`;
}

// ===================================================================
// SECTION: HANDLE CHÍNH — handleDaGa
// ===================================================================
async function handleDaGa(i, helpers) {
  const { getBalance, setBalance, formatMoney, client } = helpers;
  const sub = i.options.getSubcommand(false);

  // ===================================================================
  // /ga trung — Mua trứng gà
  // ===================================================================
  if (sub === "trung" || sub === "muatrung") {
    const cd = checkCooldown(i.user.id, "trung", 3000);
    if (cd > 0) return i.editReply(`⏳ Chờ ${cd}s trước khi mua trứng tiếp.`);

    // 3 loại trứng — tỉ lệ rarity tích hợp trong rarityPool
    const EGG_OPTIONS = [
      {
        key: "egg_0", label: "🥚 Trứng Thường", price: 2000000, tier: 0,
        desc: "⚪ Common ~ 🔵 Rare",
        color: 0x95a5a6,
        rarityPool: [
          ...Array(50).fill("COMMON"),
          ...Array(30).fill("UNCOMMON"),
          ...Array(18).fill("RARE"),
          ...Array(2).fill("EPIC"),
        ]
      },
      {
        key: "egg_1", label: "🥚 Trứng Cao Cấp", price: 10000000, tier: 1,
        desc: "🔵 Rare ~ 🟡 Legendary",
        color: 0x3498db,
        rarityPool: [
          ...Array(40).fill("RARE"),
          ...Array(35).fill("EPIC"),
          ...Array(20).fill("LEGENDARY"),
          ...Array(5).fill("MYTHIC"),
        ]
      },
      {
        key: "egg_2", label: "🥚 Trứng Huyền Thoại", price: 50000000,  tier: 2,
        desc: "🟡 Legendary ~ 🌈 Immortal",
        color: 0xff6b9d,
        rarityPool: [
          ...Array(40).fill("LEGENDARY"),
          ...Array(35).fill("MYTHIC"),
          ...Array(25).fill("IMMORTAL"),
        ]
      }
    ];

    const HYPE = {
      IMMORTAL:  "🌈 **KHÔNG THỂ TIN!!! IMMORTAL!!!** 🎆🎇🎆",
      MYTHIC:    "🔴 **OMG!!! MYTHIC!!!** 🔥🔥🔥",
      LEGENDARY: "🟡 **TUYỆT VỜI! LEGENDARY!!!** 👑",
      EPIC:      "🟣 **EPIC! Xịn đấy!** ✨",
      RARE:      "🔵 **Khá ổn! Rare!**",
      UNCOMMON:  "🟢 Uncommon, tiếp tục thôi!",
      COMMON:    "⚪ Common, chúc may mắn lần sau!"
    };

    const ANIM_FRAMES = [
      "🥚  🥚  🥚  🥚  🥚",
      "🌀  🥚  🥚  🥚  🌀",
      "✨  🌀  🥚  🌀  ✨",
      "💫  ✨  🌟  ✨  💫",
      "🌟  💫  🎇  💫  🌟",
      "🎆  🌟  🎇  🌟  🎆"
    ];

    const buildEggShopEmbed = () => {
      const bal = getBalance(i.user.id);
      const shopDesc = EGG_OPTIONS.map(e =>
        `🥚 **${e.label.replace("🥚 ","")}** — **${formatMoney(e.price)}$**/quả\n→ ${e.desc}`
      ).join("\n\n");
      return gaEmbed("🥚 MUA & MỞ TRỨNG GÀ", 0xf1c40f,
        shopDesc + `\n\n━━━━━━━━━━━━━━\n💳 Số dư: **${formatMoney(bal)}$**\n⚠️ Stats ngẫu nhiên | 🌈 Immortal cực hiếm!`);
    };

    const buildEggSelectRow = () => new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("egg_type_select")
        .setPlaceholder("🥚 Chọn loại trứng muốn mở...")
        .addOptions(EGG_OPTIONS.map(e =>
          new StringSelectMenuOptionBuilder()
            .setLabel(e.label)
            .setDescription(`${formatMoney(e.price)}$/quả | ${e.desc}`)
            .setValue(e.key)
            .setEmoji("🥚")
        ))
    );

    const openEggs = async (tier, qty) => {
      const egg   = EGG_OPTIONS[tier];
      const total = egg.price * qty;

      if (getBalance(i.user.id) < total) return { error: `Cần **${formatMoney(total)}$** để mở **${qty} ${egg.label}**\n💳 Số dư: **${formatMoney(getBalance(i.user.id))}$**` };

      setBalance(i.user.id, getBalance(i.user.id) - total);
      if (!chickenInventory[i.user.id]) chickenInventory[i.user.id] = [];
      if (!eggStats[i.user.id]) eggStats[i.user.id] = { opened: 0 };

      const rarityCount = {};
      let bestChicken = null, bestPower = -1;

      for (let n = 0; n < qty; n++) {
        // Lấy rarity từ pool của loại trứng
        const rarity = egg.rarityPool[Math.floor(Math.random() * egg.rarityPool.length)];
        const c = createChicken(tier, i.user.id, rarity);
        const pw = calcPower({ ...c, ownerId: i.user.id });
        chickenInventory[i.user.id].push(c);
        eggStats[i.user.id].opened++;
        rarityCount[c.rarity] = (rarityCount[c.rarity] || 0) + 1;
        if (pw > bestPower) { bestPower = pw; bestChicken = c; }

        if ((c.rarity === "IMMORTAL" || c.rarity === "MYTHIC") && client && i.guild) {
          const rc = RARITY[c.rarity];
          await broadcast(client, i.guild.id, i.channel.id,
            `🌈 **${i.user.username}** vừa mở trứng ra **${rc.label} — ${c.name}**! 🎉`);
        }
      }
      saveInventory();
      save("eggStats.json", eggStats);

      const topRarity = Object.keys(rarityCount).sort((a,b) =>
        Object.keys(RARITY).indexOf(b) - Object.keys(RARITY).indexOf(a))[0];
      const br  = RARITY[bestChicken.rarity];
      const be  = ELEMENTS[bestChicken.element] || { label: "" };
      const bpw = calcPower({ ...bestChicken, ownerId: i.user.id });

      const rarityLines = Object.entries(rarityCount)
        .sort((a,b) => Object.keys(RARITY).indexOf(b[0]) - Object.keys(RARITY).indexOf(a[0]))
        .map(([rar,cnt]) => `${RARITY[rar].icon} **${RARITY[rar].label.split(" ")[1]}**: ${cnt} con`)
        .join("\n");

      const hype = HYPE[topRarity] || "";
      const bal  = getBalance(i.user.id);

      const desc = qty === 1
        ? `${hype}\n\n${br.icon} **${bestChicken.name}**\n${br.label} | ${be.label}\n\n❤️ HP: **${bestChicken.maxHp}**\n⚔️ Damage: **${bestChicken.damage}**\n🛡️ Giáp: **${bestChicken.armor}**\n💥 Crit: **${Math.round(bestChicken.crit*100)}%**\n🌀 Né: **${Math.round(bestChicken.dodge*100)}%**\n🏆 Lực chiến: **${bpw.toLocaleString("vi-VN")}**`
        : `${hype}\n\n━━━━━━━━━━━━━━\n📦 **${qty} TRỨNG ĐÃ MỞ:**\n${rarityLines}\n\n━━━━━━━━━━━━━━\n🏆 **CON XỊN NHẤT:**\n${br.icon} **${bestChicken.name}**\n${br.label} | ${be.label}\n🏆 Lực chiến: **${bpw.toLocaleString("vi-VN")}**\n\n━━━━━━━━━━━━━━\n💸 Đã chi: **${formatMoney(total)}$**\n💳 Còn lại: **${formatMoney(bal)}$**`;

      return { desc, color: br.color || egg.color, topRarity, bal, tier, qty };
    };

    const buildQtyRow = (egg, bal) => [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`egg_buy_${egg.tier}_1`).setLabel(`x1 — ${formatMoney(egg.price)}$`).setStyle(ButtonStyle.Secondary).setEmoji("🥚").setDisabled(bal < egg.price),
        new ButtonBuilder().setCustomId(`egg_buy_${egg.tier}_3`).setLabel(`x3 — ${formatMoney(egg.price*3)}$`).setStyle(ButtonStyle.Primary).setEmoji("🥚").setDisabled(bal < egg.price*3),
        new ButtonBuilder().setCustomId(`egg_buy_${egg.tier}_5`).setLabel(`x5 — ${formatMoney(egg.price*5)}$`).setStyle(ButtonStyle.Success).setEmoji("🥚").setDisabled(bal < egg.price*5),
        new ButtonBuilder().setCustomId(`egg_buy_${egg.tier}_10`).setLabel(`x10 — ${formatMoney(egg.price*10)}$`).setStyle(ButtonStyle.Danger).setEmoji("🥚").setDisabled(bal < egg.price*10)
      ),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`egg_buy_${egg.tier}_custom`).setLabel("✏️ Nhập số lượng").setStyle(ButtonStyle.Secondary).setEmoji("🥚").setDisabled(bal < egg.price)
      )
    ];

    const buildBackRow = () => new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("egg_back").setLabel("◀ Chọn lại trứng").setStyle(ButtonStyle.Secondary)
    );

    const buildMoreRow = (tier, bal) => {
      const egg = EGG_OPTIONS[tier];
      return [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`egg_buy_${tier}_1`).setLabel("x1 lần nữa").setStyle(ButtonStyle.Secondary).setEmoji("🥚").setDisabled(bal < egg.price),
          new ButtonBuilder().setCustomId(`egg_buy_${tier}_10`).setLabel("x10 lần nữa").setStyle(ButtonStyle.Danger).setEmoji("🥚").setDisabled(bal < egg.price*10),
          new ButtonBuilder().setCustomId(`egg_buy_${tier}_custom`).setLabel("✏️ Nhập số").setStyle(ButtonStyle.Secondary).setEmoji("🥚").setDisabled(bal < egg.price),
          new ButtonBuilder().setCustomId("egg_back").setLabel("◀ Đổi trứng").setStyle(ButtonStyle.Secondary)
        )
      ];
    };

    const msg = await i.editReply({
      embeds: [buildEggShopEmbed()],
      components: [buildEggSelectRow()],
      fetchReply: true
    });

    const col = msg.createMessageComponentCollector({
      filter: x => {
        if (x.user.id !== i.user.id) {
          x.reply({ content: "❌ Đây không phải menu của bạn!", ephemeral: true }).catch(() => {});
          return false;
        }
        return x.customId === "egg_type_select" || x.customId === "egg_back" || x.customId.startsWith("egg_buy_") || x.customId === "egg_custom_submit";
      },
      time: 120000
    });

    col.on("collect", async sel => {
      if (sel.customId === "egg_back") {
        await sel.deferUpdate();
        await msg.edit({ embeds: [buildEggShopEmbed()], components: [buildEggSelectRow()] });
        return;
      }

      if (sel.customId === "egg_type_select") {
        await sel.deferUpdate();
        const eggKey = sel.values[0];
        const egg    = EGG_OPTIONS.find(e => e.key === eggKey);
        const bal    = getBalance(i.user.id);
        const maxQ   = Math.floor(bal / egg.price);

        await msg.edit({
          embeds: [gaEmbed(`${egg.label} — CHỌN SỐ LƯỢNG`, egg.color,
`✅ Đã chọn: **${egg.label}**
${egg.desc}

💰 Giá: **${formatMoney(egg.price)}$**/quả
💳 Số dư: **${formatMoney(bal)}$**
📦 Có thể mở tối đa: **${maxQ}** quả

━━━━━━━━━━━━━━
🐣 Chọn số lượng muốn mở:`)],
          components: [...buildQtyRow(egg, bal), buildBackRow()]
        });
        return;
      }

      if (sel.customId.startsWith("egg_buy_")) {
        const parts = sel.customId.split("_");
        const tier  = parseInt(parts[2]);
        const qtyRaw = parts[3];
        const egg   = EGG_OPTIONS[tier];

        // Nhập số lượng tùy ý qua Modal
        if (qtyRaw === "custom") {
          const modal = new ModalBuilder()
            .setCustomId(`egg_modal_${tier}`)
            .setTitle(`🥚 Nhập số lượng — ${egg.label}`);
          modal.addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId("egg_qty_input")
                .setLabel(`Giá: ${formatMoney(egg.price)}$/quả | Số dư: ${formatMoney(getBalance(i.user.id))}$`)
                .setPlaceholder("Nhập số lượng (1 - 9999)...")
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
                .setMinLength(1)
                .setMaxLength(4)
            )
          );
          await sel.showModal(modal);

          // Await modal submit
          const modalSubmit = await i.awaitModalSubmit({ filter: m => m.customId === `egg_modal_${tier}` && m.user.id === i.user.id, time: 60000 }).catch(() => null);
          if (!modalSubmit) return;

          const qtyInput = parseInt(modalSubmit.fields.getTextInputValue("egg_qty_input"));
          if (isNaN(qtyInput) || qtyInput < 1) {
            return modalSubmit.reply({ content: "❌ Số lượng không hợp lệ!", ephemeral: true });
          }
          await modalSubmit.deferUpdate();

          // Chạy animation + mở
          await msg.edit({
            embeds: [gaEmbed("🥚 ĐANG MỞ TRỨNG...", egg.color,
              `Mở **${qtyInput}x ${egg.label}**...

${ANIM_FRAMES[0]}

*Đang triệu hồi chiến kê...*`)],
            components: []
          });
          for (let f = 1; f < ANIM_FRAMES.length; f++) {
            await new Promise(r => setTimeout(r, 380));
            await msg.edit({ embeds: [gaEmbed("🥚 ĐANG MỞ TRỨNG...", egg.color,
              `Mở **${qtyInput}x ${egg.label}**...

${ANIM_FRAMES[f]}

*Đang triệu hồi chiến kê...*`)] }).catch(() => {});
          }
          await new Promise(r => setTimeout(r, 450));
          const result2 = await openEggs(tier, qtyInput);
          if (result2.error) { await msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c, result2.error)], components: [] }); col.stop(); return; }
          await msg.edit({ embeds: [gaEmbed(`🎉 MỞ ${qtyInput} TRỨNG THÀNH CÔNG!`, result2.color, result2.desc)], components: buildMoreRow(result2.tier, result2.bal) });
          return;
        }

        const qty   = parseInt(qtyRaw);
        await sel.deferUpdate();

        await msg.edit({
          embeds: [gaEmbed("🥚 ĐANG MỞ TRỨNG...", egg.color,
            `Mở **${qty}x ${egg.label}**...\n\n${ANIM_FRAMES[0]}\n\n*Đang triệu hồi chiến kê...*`)],
          components: []
        });
        for (let f = 1; f < ANIM_FRAMES.length; f++) {
          await new Promise(r => setTimeout(r, 380));
          await msg.edit({ embeds: [gaEmbed("🥚 ĐANG MỞ TRỨNG...", egg.color,
            `Mở **${qty}x ${egg.label}**...\n\n${ANIM_FRAMES[f]}\n\n*Đang triệu hồi chiến kê...*`)] }).catch(() => {});
        }
        await new Promise(r => setTimeout(r, 450));

        const result = await openEggs(tier, qty);

        if (result.error) {
          await msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c, result.error)], components: [] });
          col.stop(); return;
        }

        await msg.edit({
          embeds: [gaEmbed(`🎉 MỞ ${qty} TRỨNG THÀNH CÔNG!`, result.color, result.desc)],
          components: buildMoreRow(result.tier, result.bal)
        });
      }
    });

    col.on("end", () => msg.edit({ components: [] }).catch(() => {}));
    return;
  }

  // ===================================================================
  // /ga kho — Xem kho gà (có phân trang)
  // ===================================================================
  if (sub === "kho") {
    const chickens = getAliveChickens(i.user.id);
    if (chickens.length === 0) {
      return i.editReply({ embeds: [gaEmbed("🐔 KHO GÀ", 0x95a5a6, `${i.user} chưa có gà!\n\nMua trứng: **/ga trung**`)] });
    }

    // Sort theo lực chiến
    chickens.sort((a, b) => calcPower({ ...b, ownerId: i.user.id }) - calcPower({ ...a, ownerId: i.user.id }));

    const PAGE_SIZE = 10;
    let page = 0;
    const totalPages = Math.max(1, Math.ceil(chickens.length / PAGE_SIZE));

    const renderKho = async (msg) => {
      const slice = chickens.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
      const lines = slice.map((c, idx) => {
        const r    = RARITY[c.rarity];
        const e    = ELEMENTS[c.element] || { label: "" };
        const rank = getLevelRank(c.level);
        const pw   = calcPower({ ...c, ownerId: i.user.id });
        const nc   = c.nangCap > 0 ? ` +${c.nangCap}` : "";
        const inj  = (c.injured && Date.now() < c.injuredUntil) ? " 🩸" : "";
        const hun  = c.hunger >= 70 ? " ⚠️Đói" : "";
        const num  = page * PAGE_SIZE + idx + 1;
        return `**${num}.** ${r.icon} **${c.name}${nc}**${inj}${hun}\n` +
               `${r.label} ${e.label} | ${rank.rank} Lv${c.level}\n` +
               `❤️${c.hp}/${c.maxHp} | ⚔️${c.damage} | 🏆${pw.toLocaleString()}`;
      }).join("\n\n");

      const pageInfo = totalPages > 1 ? `\n\n📄 Trang **${page+1}/${totalPages}** | Tổng **${chickens.length}** gà` : `\n\n🐔 Tổng **${chickens.length}** gà`;

      const components = [];
      if (totalPages > 1) {
        const btns = [];
        if (page > 0) btns.push(new ButtonBuilder().setCustomId("kho_prev").setLabel("◀ Trước").setStyle(ButtonStyle.Secondary));
        btns.push(new ButtonBuilder().setCustomId("kho_page_info").setLabel(`${page+1}/${totalPages}`).setStyle(ButtonStyle.Secondary).setDisabled(true));
        if (page < totalPages - 1) btns.push(new ButtonBuilder().setCustomId("kho_next").setLabel("Sau ▶").setStyle(ButtonStyle.Secondary));
        components.push(new ActionRowBuilder().addComponents(btns));
      }

      const embed = gaEmbed(`🐔 KHO GÀ — ${i.user.username}`, 0x3498db, lines + pageInfo);
      if (msg) return msg.edit({ embeds: [embed], components });
      return i.editReply({ embeds: [embed], components, fetchReply: true });
    };

    const msg = await renderKho(null);

    if (totalPages > 1) {
      const col = msg.createMessageComponentCollector({
        filter: x => x.user.id === i.user.id && (x.customId === "kho_prev" || x.customId === "kho_next"),
        time: 60000
      });
      col.on("collect", async btn => {
        await btn.deferUpdate();
        if (btn.customId === "kho_prev" && page > 0) page--;
        if (btn.customId === "kho_next" && page < totalPages - 1) page++;
        await renderKho(msg);
      });
      col.on("end", () => msg.edit({ components: [] }).catch(() => {}));
    }
    return;
  }

  // ===================================================================
  // /ga info — Xem chi tiết gà
  // ===================================================================
  if (sub === "info") {
    const chickens = getAliveChickens(i.user.id);
    if (chickens.length === 0) return i.editReply("❌ Bạn chưa có gà.");
    chickens.sort((a, b) => calcPower({ ...b, ownerId: i.user.id }) - calcPower({ ...a, ownerId: i.user.id }));

    const msg = await i.editReply({ embeds: [gaEmbed("🐔 XEM INFO GÀ", 0x3498db, "⏳ Đang tải...")], components: [], fetchReply: true });

    const chickenId = await awaitChickenSelect(
      msg, i.user.id, chickens,
      "🐔 XEM INFO GÀ", "Chọn gà muốn xem thông tin chi tiết:",
      0x3498db, "info_select_ga", "🐔 Chọn gà muốn xem...", "info_page"
    );

    if (!chickenId) return;

    const c      = findChicken(i.user.id, chickenId);
    if (!c) return msg.edit({ content: "❌ Không tìm thấy gà", components: [] });

    const r      = RARITY[c.rarity];
    const e      = ELEMENTS[c.element] || { label: "" };
    const rank   = getLevelRank(c.level);
    const pw     = calcPower({ ...c, ownerId: i.user.id });
    const nc     = c.nangCap > 0 ? ` (+${c.nangCap})` : "";
    const skills = (c.skills || []).map(s => SKILLS_POOL[s]?.name || s).join("\n") || "Chưa có skill";
    const injStr = (c.injured && Date.now() < c.injuredUntil)
      ? `\n🩸 Bị thương đến: <t:${Math.floor(c.injuredUntil / 1000)}:R>` : "";
    const prest  = (prestigeData[i.user.id] || {}).prestige || 0;
    const expReq = expRequired(c.level);

    return msg.edit({ embeds: [gaEmbed(`${r.icon} ${c.name}${nc} — INFO`, r.color,
`${r.label} | ${e.label} | ${rank.rank}
🏆 **Lực Chiến: ${pw.toLocaleString()}**

━━━━━━━━━━━━━━
📈 **THÔNG TIN CƠ BẢN**

⭐ Level: **${c.level}** (EXP: ${c.exp}/${expReq})
⚒️ Nâng độ: **+${c.nangCap}**
🎖️ Rank: ${rank.rank}
🔮 Prestige: **${prest}**
📚 Skill: **${(c.skills||[]).length}/${c.skillSlots || 6}**
🍗 Đói: **${c.hunger}%**${injStr}

━━━━━━━━━━━━━━
📊 **CHỈ SỐ**

❤️ HP: **${c.hp}/${c.maxHp}**
⚔️ Damage: **${c.damage}**
🛡️ Giáp: **${c.armor}**
💥 Crit: **${Math.round(c.crit * 100)}%**
🌀 Né: **${Math.round(c.dodge * 100)}%**
☠️ Xuyên giáp: **${Math.round((c.pierce||0) * 100)}%**
🩸 Hút máu: **${Math.round((c.lifesteal||0) * 100)}%**

━━━━━━━━━━━━━━
⚔️ **SKILL TRANG BỊ**

${skills}

━━━━━━━━━━━━━━
📜 **LỊCH SỬ**

🏆 Thắng: **${c.winCount}** | Thua: **${c.loseCount}**
⚔️ Tổng trận: **${c.battleCount}**`)], components: [] });
  }

  // ===================================================================
  // /ga nangcap — Nâng cấp level gà
  // ===================================================================
  if (sub === "nangcap") {
    const chickens = getAliveChickens(i.user.id);
    if (chickens.length === 0) return i.editReply("❌ Bạn chưa có gà.");
    chickens.sort((a, b) => calcPower({ ...b, ownerId: i.user.id }) - calcPower({ ...a, ownerId: i.user.id }));

    const msg = await i.editReply({ embeds: [gaEmbed("⬆️ NÂNG CẤP GÀ", 0x3498db, "⏳ Đang tải...")], components: [], fetchReply: true });

    const chickenId = await awaitChickenSelect(
      msg, i.user.id, chickens,
      "⬆️ NÂNG CẤP GÀ", "Chọn gà muốn nâng cấp level:",
      0x3498db, "nc_select_ga", "⬆️ Chọn gà muốn nâng cấp...", "nc_page"
    );

    if (!chickenId) return;

    const c = findChicken(i.user.id, chickenId);
    if (!c || c.isDead) return msg.edit({ content: "❌ Gà không hợp lệ", components: [] });

    const cost = Math.floor(500000 * Math.pow(1.12, c.level));
    let failRate = 0;
    if      (c.level >= 150) failRate = 0.65;
    else if (c.level >= 100) failRate = 0.50;
    else if (c.level >= 60)  failRate = 0.35;
    else if (c.level >= 30)  failRate = 0.20;
    else if (c.level >= 10)  failRate = 0.08;

    if (getBalance(i.user.id) < cost) {
      return msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c,
        `Cần **${formatMoney(cost)}$** để nâng LV${c.level} → LV${c.level + 1}\n\n🐔 Gà: **${c.name}**`)], components: [] });
    }

    setBalance(i.user.id, getBalance(i.user.id) - cost);
    c.hunger = Math.min(100, c.hunger + 15);

    await msg.edit({ embeds: [gaEmbed("⬆️ ĐANG NÂNG CẤP...", 0xf1c40f,
      `🎰 **${c.name}** LV${c.level} → LV${c.level + 1}\n\n💫 . . . 🌟 . . . ✨`)], components: [] });
    await new Promise(r => setTimeout(r, 1800));

    if (Math.random() < failRate) {
      if (c.level > 1) c.level--;
      saveInventory();
      return msg.edit({ embeds: [gaEmbed("❌ NÂNG CẤP THẤT BẠI!", 0xe74c3c,
`💸 Mất **${formatMoney(cost)}$**
🐔 **${c.name}** thất bại!
⬇️ Tuột về LV**${c.level}**
🍗 Đói: **${c.hunger}%**`)], components: [] });
    }

    c.level++;
    const hpGain  = Math.max(1, Math.round(50 / Math.log2(c.level + 1)));
    const dmgGain = Math.max(1, Math.round(15 / Math.log2(c.level + 1)));
    const armGain = Math.max(1, Math.round(5  / Math.log2(c.level + 1)));
    c.maxHp  += hpGain;
    c.hp      = Math.min(c.hp + hpGain, c.maxHp);
    c.damage += dmgGain;
    c.armor  += armGain;

    const rank = getLevelRank(c.level);
    saveInventory();

    if (c.level % 50 === 0 && client && i.guild) {
      await broadcast(client, i.guild.id, i.channel.id,
        `🌟 **${i.user.username}** vừa nâng **${c.name}** lên **LV${c.level}!** ${rank.rank}`);
    }

    return msg.edit({ embeds: [gaEmbed(`⬆️ NÂNG CẤP THÀNH CÔNG!`, RARITY[c.rarity].color,
`${RARITY[c.rarity].icon} **${c.name}** → **${rank.rank} LV${c.level}**

❤️ HP: +${hpGain} → **${c.maxHp}**
⚔️ Damage: +${dmgGain} → **${c.damage}**
🛡️ Giáp: +${armGain} → **${c.armor}**
💸 Chi phí: **${formatMoney(cost)}$**`)], components: [] });
  }

  // ===================================================================
  // /ga nangdo — Nâng độ +N
  // ===================================================================
  if (sub === "nangdo") {
    const chickens = getAliveChickens(i.user.id);
    if (chickens.length === 0) return i.editReply("❌ Bạn chưa có gà.");
    chickens.sort((a, b) => calcPower({ ...b, ownerId: i.user.id }) - calcPower({ ...a, ownerId: i.user.id }));

    const msg = await i.editReply({ embeds: [gaEmbed("⚒️ NÂNG ĐỘ GÀ (+N)", 0x9b59b6,
`⏳ Đang tải...

⚒️ **Hệ thống nâng độ +1 → vô hạn**

+1→+5: Tỉ lệ cao 90%
+6→+10: Có thể tụt 1 cấp
+11→+15: Tụt 2 cấp
+16→+20: Tỉ lệ thấp, tụt 3 cấp
+21+: Siêu khó, có thể vỡ!`)], components: [], fetchReply: true });

    const chickenId = await awaitChickenSelect(
      msg, i.user.id, chickens,
      "⚒️ NÂNG ĐỘ GÀ (+N)", "Chọn gà muốn nâng độ:",
      0x9b59b6, "nd_select_ga", "⚒️ Chọn gà muốn nâng độ...", "nd_page"
    );

    if (!chickenId) return;

    const c = findChicken(i.user.id, chickenId);
    if (!c || c.isDead) return msg.edit({ content: "❌ Gà không hợp lệ", components: [] });

    const curNang = c.nangCap || 0;
    const tier    = getUpgradeTier(curNang + 1);
    const cost    = Math.floor(1000000 * Math.pow(1.25, curNang));

    if (getBalance(i.user.id) < cost) {
      return msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c,
        `Cần **${formatMoney(cost)}$** để nâng **+${curNang} → +${curNang+1}**\n\n🐔 Gà: **${c.name}**`)], components: [] });
    }

    setBalance(i.user.id, getBalance(i.user.id) - cost);
    c.hunger = Math.min(100, c.hunger + 10);

    const animFrames = ["⚙️ . . .", "⚙️ ⚙️ . .", "⚙️ ⚙️ ⚙️ .", "🔥 ⚙️ ⚙️ ⚙️", "✨ ⚙️ ⚙️ 🔥", "💥 💫 ✨ 🔥"];
    for (const frame of animFrames) {
      await msg.edit({ embeds: [gaEmbed(`⚒️ ĐANG NÂNG ĐỘ +${curNang} → +${curNang+1}`, 0xf1c40f,
        `🐔 **${c.name}**\n\n${frame}`)], components: [] });
      await new Promise(r => setTimeout(r, 400));
    }

    const roll = Math.random();

    if (roll < tier.breakRate) {
      const prevNang = curNang;
      c.nangCap = Math.max(0, curNang - Math.floor(curNang * 0.4));
      saveInventory();
      return msg.edit({ embeds: [gaEmbed("💥 VỠ NÂNG ĐỘ!", 0xe74c3c,
`💔 **${c.name}** vỡ nâng độ!
+${prevNang} → **+${c.nangCap}**

⚠️ Nâng độ quá cao rất nguy hiểm!
💸 Mất **${formatMoney(cost)}$**`)], components: [] });
    }

    if (roll < tier.failDrop) {
      const dropAmt = tier.failDropAmt;
      c.nangCap = Math.max(0, curNang - dropAmt);
      saveInventory();
      return msg.edit({ embeds: [gaEmbed("❌ NÂNG ĐỘ THẤT BẠI!", 0xe74c3c,
`💸 Mất **${formatMoney(cost)}$**
🐔 **${c.name}** thất bại!
⬇️ Tụt từ **+${curNang} → +${c.nangCap}**`)], components: [] });
    }

    const isGreat = roll > tier.successRate + (1 - tier.successRate) * 0.7;
    c.nangCap++;
    const ncNow = c.nangCap;
    const hpG   = Math.max(1, Math.round(50 / Math.sqrt(ncNow)));
    const dmgG  = Math.max(1, Math.round(15 / Math.sqrt(ncNow)));
    const armG  = Math.max(1, Math.round(8  / Math.sqrt(ncNow)));
    c.maxHp  += hpG;
    c.hp      = Math.min(c.hp + hpG, c.maxHp);
    c.damage += dmgG;
    c.armor  += armG;
    saveInventory();

    if (ncNow >= 20 && ncNow % 5 === 0 && client && i.guild) {
      await broadcast(client, i.guild.id, i.channel.id,
        `🔥 **${i.user.username}** vừa nâng **${c.name}** lên **+${ncNow}** thành công!`);
    }

    return msg.edit({ embeds: [gaEmbed(isGreat ? "⭐ GREAT SUCCESS!" : "✅ NÂNG ĐỘ THÀNH CÔNG!", RARITY[c.rarity].color,
`${RARITY[c.rarity].icon} **${c.name}** → **+${ncNow}**
${isGreat ? "⭐ **GREAT SUCCESS** — bonus x1.5!" : ""}

❤️ HP: +${hpG} → **${c.maxHp}**
⚔️ Damage: +${dmgG} → **${c.damage}**
🛡️ Giáp: +${armG} → **${c.armor}**
💸 Chi phí: **${formatMoney(cost)}$**`)], components: [] });
  }

  // ===================================================================
  // /ga choan — Cho gà ăn cơ bản
  // ===================================================================
  if (sub === "choan") {
    const chickens = getAliveChickens(i.user.id).filter(c => c.hunger > 0);
    if (chickens.length === 0) {
      return i.editReply({ embeds: [gaEmbed("🍗 CHO GÀ ĂN", 0x2ecc71, "Tất cả gà đang no rồi! 🐔")] });
    }
    chickens.sort((a, b) => b.hunger - a.hunger); // gà đói nhất lên trước

    const msg = await i.editReply({ embeds: [gaEmbed("🍗 CHO GÀ ĂN", 0x2ecc71, "⏳ Đang tải...")], components: [], fetchReply: true });

    const chickenId = await awaitChickenSelect(
      msg, i.user.id, chickens,
      "🍗 CHO GÀ ĂN", "Gà đói nhất hiển thị đầu. Chọn gà muốn cho ăn miễn phí:",
      0x2ecc71, "choan_select_ga", "🍗 Chọn gà muốn cho ăn...", "choan_page"
    );

    if (!chickenId) return;

    const c = findChicken(i.user.id, chickenId);
    if (!c || c.isDead) return msg.edit({ content: "❌ Gà không hợp lệ", components: [] });

    const before = c.hunger;
    c.hunger = Math.max(0, c.hunger - 20);
    saveInventory();

    return msg.edit({ embeds: [gaEmbed("🍗 CHO GÀ ĂN", 0x2ecc71,
`${RARITY[c.rarity].icon} **${c.name}** đã được cho ăn!
🍗 Đói: **${before}%** → **${c.hunger}%**

💡 Dùng đồ ăn tốt hơn: **/ga doan**`)], components: [] });
  }

  // ===================================================================
  // /ga muadoan — Mua đồ ăn
  // ===================================================================
  if (sub === "muadoan") {
    const FOOD_EMOJI = { thoc:"🌽", thit:"🥩", vitamin:"💊", moicuong:"🔥", daitiec:"👑" };

    const buildShopEmbed = () => {
      const bal = getBalance(i.user.id);
      const inv = foodInventory[i.user.id] || {};
      const shopDesc = Object.entries(FOOD_SHOP).map(([key, f]) => {
        const em = FOOD_EMOJI[key] || "🍗";
        const owned = inv[key] || 0;
        return `${em} **${f.name}** — **${formatMoney(f.price)}$**/cái\n` +
          `→ -${f.hungerReduce}% đói${f.hpBonus ? ` | +${f.hpBonus} HP` : ""}${f.critBonus ? ` | +${Math.round(f.critBonus*100)}% crit` : ""}${f.dropLevel ? " | ⚠️ rớt cấp" : ""}\n` +
          `📦 Kho: **${owned}** cái`;
      }).join("\n\n");
      return gaEmbed("🍗 SHOP ĐỒ ĂN", 0xf39c12,
        shopDesc + `\n\n━━━━━━━━━━━━━━\n💳 Số dư: **${formatMoney(bal)}$**`);
    };

    const buildFoodSelectRow = () => new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("food_type_select")
        .setPlaceholder("🍗 Chọn món ăn muốn mua...")
        .addOptions(Object.entries(FOOD_SHOP).map(([key, f]) =>
          new StringSelectMenuOptionBuilder()
            .setLabel(f.name)
            .setDescription(`${formatMoney(f.price)}$/cái | -${f.hungerReduce}% đói${f.hpBonus ? ` | +${f.hpBonus} HP` : ""}${f.dropLevel ? " | ⚠️ rớt cấp" : ""}`)
            .setValue(key)
            .setEmoji(FOOD_EMOJI[key] || "🍗")
        ))
    );

    const msg = await i.editReply({ embeds: [buildShopEmbed()], components: [buildFoodSelectRow()], fetchReply: true });

    const shopCol = msg.createMessageComponentCollector({
      filter: x => {
        if (x.user.id !== i.user.id) { x.reply({ content: "❌ Đây không phải menu của bạn!", ephemeral: true }).catch(() => {}); return false; }
        return ["food_type_select","food_back"].includes(x.customId) || x.customId.startsWith("food_buy_");
      },
      time: 60000
    });

    shopCol.on("collect", async sel => {
      if (sel.customId === "food_back") {
        await sel.deferUpdate();
        await msg.edit({ embeds: [buildShopEmbed()], components: [buildFoodSelectRow()] });
        return;
      }

      if (sel.customId === "food_type_select") {
        await sel.deferUpdate();
        const key  = sel.values[0];
        const food = FOOD_SHOP[key];
        const em   = FOOD_EMOJI[key] || "🍗";
        const bal  = getBalance(i.user.id);
        const maxQ = Math.floor(bal / food.price);
        const owned = (foodInventory[i.user.id] || {})[key] || 0;

        const qtyRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`food_buy_${key}_1`).setLabel(`x1 — ${formatMoney(food.price)}$`).setStyle(ButtonStyle.Secondary).setEmoji(em).setDisabled(maxQ < 1),
          new ButtonBuilder().setCustomId(`food_buy_${key}_3`).setLabel(`x3 — ${formatMoney(food.price*3)}$`).setStyle(ButtonStyle.Primary).setEmoji(em).setDisabled(maxQ < 3),
          new ButtonBuilder().setCustomId(`food_buy_${key}_5`).setLabel(`x5 — ${formatMoney(food.price*5)}$`).setStyle(ButtonStyle.Success).setEmoji(em).setDisabled(maxQ < 5),
          new ButtonBuilder().setCustomId(`food_buy_${key}_10`).setLabel(`x10 — ${formatMoney(food.price*10)}$`).setStyle(ButtonStyle.Danger).setEmoji(em).setDisabled(maxQ < 10)
        );
        const customRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`food_buy_${key}_custom`).setLabel("✏️ Nhập số lượng").setStyle(ButtonStyle.Secondary).setDisabled(maxQ < 1),
          new ButtonBuilder().setCustomId("food_back").setLabel("◀ Chọn lại").setStyle(ButtonStyle.Secondary)
        );

        await msg.edit({
          embeds: [gaEmbed(`${em} ${food.name} — CHỌN SỐ LƯỢNG`, 0xf39c12,
`✅ Đã chọn: **${food.name}**
💰 Giá: **${formatMoney(food.price)}$**/cái
📦 Kho hiện có: **${owned}** cái
💳 Số dư: **${formatMoney(bal)}$**
📦 Mua tối đa: **${maxQ}** cái

━━━━━━━━━━━━━━
🛒 Chọn số lượng muốn mua:`)],
          components: [qtyRow, customRow]
        });
        return;
      }

      if (sel.customId.startsWith("food_buy_")) {
        const parts  = sel.customId.split("_");
        const qtyRaw = parts[parts.length - 1];
        const key    = parts.slice(2, parts.length - 1).join("_");
        const food   = FOOD_SHOP[key];
        const em     = FOOD_EMOJI[key] || "🍗";

        // Nhập số lượng tùy ý
        if (qtyRaw === "custom") {
          const modal = new ModalBuilder()
            .setCustomId(`food_modal_${key}`)
            .setTitle(`${em} Nhập số lượng — ${food.name}`);
          modal.addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("food_qty_input")
              .setLabel(`Giá: ${formatMoney(food.price)}$/cái | Số dư: ${formatMoney(getBalance(i.user.id))}$`)
              .setPlaceholder("Nhập số lượng (1 - 9999)...")
              .setStyle(TextInputStyle.Short).setRequired(true).setMinLength(1).setMaxLength(4)
          ));
          await sel.showModal(modal);
          const ms = await i.awaitModalSubmit({ filter: m => m.customId === `food_modal_${key}` && m.user.id === i.user.id, time: 60000 }).catch(() => null);
          if (!ms) return;
          const qtyIn = parseInt(ms.fields.getTextInputValue("food_qty_input"));
          if (isNaN(qtyIn) || qtyIn < 1) return ms.reply({ content: "❌ Số lượng không hợp lệ!", ephemeral: true });
          await ms.deferUpdate();
          const tot = food.price * qtyIn;
          if (getBalance(i.user.id) < tot) {
            await msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c, `Cần **${formatMoney(tot)}$**\n💳 Còn: **${formatMoney(getBalance(i.user.id))}$**`)], components: [] });
            shopCol.stop(); return;
          }
          setBalance(i.user.id, getBalance(i.user.id) - tot);
          if (!foodInventory[i.user.id]) foodInventory[i.user.id] = {};
          foodInventory[i.user.id][key] = (foodInventory[i.user.id][key] || 0) + qtyIn;
          saveFood();
          const bal2 = getBalance(i.user.id);
          const owned2 = foodInventory[i.user.id][key];
          await msg.edit({ embeds: [gaEmbed("✅ MUA THÀNH CÔNG!", 0x2ecc71,
            `${em} Mua **${qtyIn}x ${food.name}**!\n\n📦 Kho: **${owned2}** cái\n💸 Đã chi: **${formatMoney(tot)}$**\n💳 Còn: **${formatMoney(bal2)}$**\n\n💡 Dùng **/ga doan**`)],
            components: [new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId(`food_buy_${key}_custom`).setLabel("✏️ Mua thêm").setStyle(ButtonStyle.Secondary).setDisabled(bal2 < food.price),
              new ButtonBuilder().setCustomId("food_back").setLabel("Mua món khác").setStyle(ButtonStyle.Secondary)
            )] });
          return;
        }

        await sel.deferUpdate();
        const qty   = parseInt(qtyRaw);
        const total = food.price * qty;

        if (getBalance(i.user.id) < total) {
          await msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c,
            `Cần **${formatMoney(total)}$** để mua **${qty}x ${food.name}**\n💳 Còn: **${formatMoney(getBalance(i.user.id))}$**`)], components: [] });
          shopCol.stop(); return;
        }

        setBalance(i.user.id, getBalance(i.user.id) - total);
        if (!foodInventory[i.user.id]) foodInventory[i.user.id] = {};
        foodInventory[i.user.id][key] = (foodInventory[i.user.id][key] || 0) + qty;
        saveFood();

        const owned = foodInventory[i.user.id][key];
        const bal   = getBalance(i.user.id);

        const moreRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`food_buy_${key}_1`).setLabel("x1 lần nữa").setStyle(ButtonStyle.Secondary).setEmoji(em).setDisabled(bal < food.price),
          new ButtonBuilder().setCustomId(`food_buy_${key}_10`).setLabel("x10 lần nữa").setStyle(ButtonStyle.Danger).setEmoji(em).setDisabled(bal < food.price*10),
          new ButtonBuilder().setCustomId(`food_buy_${key}_custom`).setLabel("✏️ Nhập số").setStyle(ButtonStyle.Secondary).setDisabled(bal < food.price),
          new ButtonBuilder().setCustomId("food_back").setLabel("Mua món khác").setStyle(ButtonStyle.Secondary)
        );

        await msg.edit({ embeds: [gaEmbed("✅ MUA ĐỒ ĂN THÀNH CÔNG!", 0x2ecc71,
`${em} Đã mua **${qty}x ${food.name}**!

📦 Kho hiện có: **${owned}** cái
💸 Đã chi: **${formatMoney(total)}$**
💳 Còn lại: **${formatMoney(bal)}$**

━━━━━━━━━━━━━━
💡 Dùng **/ga doan** để cho gà ăn`)], components: [moreRow] });
      }
    });

    shopCol.on("end", () => msg.edit({ components: [] }).catch(() => {}));
    return;
  }

  // ===================================================================
  // /ga doan — Dùng đồ ăn cho gà
  // ===================================================================
  if (sub === "doan") {
    const userFood    = foodInventory[i.user.id] || {};
    const availItems  = Object.entries(userFood).filter(([, qty]) => qty > 0);
    if (availItems.length === 0) return i.editReply("❌ Không có đồ ăn. Mua: **/ga muadoan**");

    const chickens = getAliveChickens(i.user.id);
    if (chickens.length === 0) return i.editReply("❌ Bạn chưa có gà.");
    chickens.sort((a, b) => b.hunger - a.hunger);

    const foodOptions = availItems.map(([key, qty]) => {
      const f = FOOD_SHOP[key];
      if (!f) return null;
      return new StringSelectMenuOptionBuilder()
        .setLabel(`${f.name} (x${qty})`)
        .setDescription(`Giảm đói ${f.hungerReduce}% | ${formatMoney(f.price)}$`)
        .setValue(key);
    }).filter(Boolean);

    const foodSelectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("doan_select_food")
        .setPlaceholder("🍗 Chọn món ăn...")
        .addOptions(foodOptions)
    );

    // Bước 1: chọn đồ ăn trước
    const msg = await i.editReply({
      embeds: [gaEmbed("🍗 DÙNG ĐỒ ĂN — BƯỚC 1", 0x2ecc71, "Chọn món ăn muốn dùng:")],
      components: [foodSelectRow],
      fetchReply: true
    });

    const selectedFood = await new Promise(resolve => {
      const col = msg.createMessageComponentCollector({
        filter: x => x.user.id === i.user.id && x.customId === "doan_select_food",
        time: 30000, max: 1
      });
      col.on("collect", async btn => { await btn.deferUpdate(); resolve(btn.values[0]); });
      col.on("end", collected => { if (collected.size === 0) resolve(null); });
    });

    if (!selectedFood) return msg.edit({ embeds: [gaEmbed("⌛ TIMEOUT", 0xe74c3c, "Hết thời gian chọn đồ ăn.")], components: [] });

    // Bước 2: chọn gà
    const chickenId = await awaitChickenSelect(
      msg, i.user.id, chickens,
      "🍗 DÙNG ĐỒ ĂN — BƯỚC 2", `Đã chọn: **${FOOD_SHOP[selectedFood]?.name}**\nChọn gà muốn cho ăn:`,
      0x2ecc71, "doan_select_ga", "🐔 Chọn gà muốn cho ăn...", "doan_page"
    );

    if (!chickenId) return;

    const c    = findChicken(i.user.id, chickenId);
    const food = FOOD_SHOP[selectedFood];
    if (!c || !food) return msg.edit({ content: "❌ Lỗi", components: [] });

    const fInv = foodInventory[i.user.id] || {};
    if (!fInv[selectedFood] || fInv[selectedFood] <= 0) {
      return msg.edit({ embeds: [gaEmbed("❌ HẾT ĐỒ ĂN", 0xe74c3c, `Không còn ${food.name}!`)], components: [] });
    }

    fInv[selectedFood]--;
    foodInventory[i.user.id] = fInv;

    const before = c.hunger;
    c.hunger     = Math.max(0, c.hunger - food.hungerReduce);
    if (food.hpBonus)   { c.maxHp += food.hpBonus; c.hp = Math.min(c.hp + food.hpBonus, c.maxHp); }
    if (food.critBonus) { c.crit  = parseFloat((c.crit + food.critBonus).toFixed(3)); }

    let dropStr = "";
    if (food.dropLevel && Math.random() < food.dropChance && c.level > 1) {
      c.level--;
      dropStr = `\n⚠️ **Không may! ${c.name} rớt về LV${c.level}**`;
    }

    saveInventory();
    saveFood();

    return msg.edit({ embeds: [gaEmbed("🍗 CHO GÀ ĂN", 0x2ecc71,
`${RARITY[c.rarity].icon} **${c.name}** dùng **${food.name}**!
🍗 Đói: **${before}%** → **${c.hunger}%**
${food.hpBonus   ? `❤️ HP +${food.hpBonus}` : ""}
${food.critBonus ? `⚡ Crit +${Math.round(food.critBonus*100)}%` : ""}${dropStr}`)], components: [] });
  }

  // ===================================================================
  // /ga muaskill — Mua sách skill
  // ===================================================================
  if (sub === "muaskill") {
    const BOOK_EMOJI = { sach_thuong:"📘", sach_hiem:"📗", sach_bian:"📕", sach_than:"📙", sach_bat_tu:"📔" };

    const buildSkillShopEmbed = () => {
      const bal = getBalance(i.user.id);
      const inv = skillInventory[i.user.id] || [];
      const desc = Object.entries(SKILL_BOOKS).map(([key, b]) => {
        const em = BOOK_EMOJI[key] || "📚";
        return `${em} **${b.name}** — **${formatMoney(b.price)}$**/cuốn\n→ ${b.rarities.map(r => RARITY[r]?.label || r).join(", ")}`;
      }).join("\n\n");
      return gaEmbed("📚 SHOP SÁCH SKILL", 0x9b59b6,
        desc + `\n\n━━━━━━━━━━━━━━\n📦 Túi sách: **${inv.length}** cuốn\n💳 Số dư: **${formatMoney(bal)}$**`);
    };

    const buildBookSelectRow = () => new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("book_type_select")
        .setPlaceholder("📚 Chọn loại sách muốn mua...")
        .addOptions(Object.entries(SKILL_BOOKS).map(([key, b]) =>
          new StringSelectMenuOptionBuilder()
            .setLabel(b.name)
            .setDescription(`${formatMoney(b.price)}$/cuốn | ${b.rarities.map(r => RARITY[r]?.label?.split(" ")[1] || r).join(", ")}`)
            .setValue(key)
            .setEmoji(BOOK_EMOJI[key] || "📚")
        ))
    );

    const msg = await i.editReply({ embeds: [buildSkillShopEmbed()], components: [buildBookSelectRow()], fetchReply: true });

    const bookCol = msg.createMessageComponentCollector({
      filter: x => {
        if (x.user.id !== i.user.id) { x.reply({ content: "❌ Đây không phải menu của bạn!", ephemeral: true }).catch(() => {}); return false; }
        return ["book_type_select","book_back"].includes(x.customId) || x.customId.startsWith("book_buy_");
      },
      time: 60000
    });

    bookCol.on("collect", async sel => {
      if (sel.customId === "book_back") {
        await sel.deferUpdate();
        await msg.edit({ embeds: [buildSkillShopEmbed()], components: [buildBookSelectRow()] });
        return;
      }

      if (sel.customId === "book_type_select") {
        await sel.deferUpdate();
        const key  = sel.values[0];
        const book = SKILL_BOOKS[key];
        const em   = BOOK_EMOJI[key] || "📚";
        const bal  = getBalance(i.user.id);
        const maxQ = Math.floor(bal / book.price);

        const qtyRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`book_buy_${key}_1`).setLabel(`x1 — ${formatMoney(book.price)}$`).setStyle(ButtonStyle.Secondary).setEmoji(em).setDisabled(maxQ < 1),
          new ButtonBuilder().setCustomId(`book_buy_${key}_3`).setLabel(`x3 — ${formatMoney(book.price*3)}$`).setStyle(ButtonStyle.Primary).setEmoji(em).setDisabled(maxQ < 3),
          new ButtonBuilder().setCustomId(`book_buy_${key}_5`).setLabel(`x5 — ${formatMoney(book.price*5)}$`).setStyle(ButtonStyle.Success).setEmoji(em).setDisabled(maxQ < 5),
          new ButtonBuilder().setCustomId(`book_buy_${key}_10`).setLabel(`x10 — ${formatMoney(book.price*10)}$`).setStyle(ButtonStyle.Danger).setEmoji(em).setDisabled(maxQ < 10)
        );
        const customRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`book_buy_${key}_custom`).setLabel("✏️ Nhập số lượng").setStyle(ButtonStyle.Secondary).setDisabled(maxQ < 1),
          new ButtonBuilder().setCustomId("book_back").setLabel("◀ Chọn lại").setStyle(ButtonStyle.Secondary)
        );

        await msg.edit({
          embeds: [gaEmbed(`${em} ${book.name} — CHỌN SỐ LƯỢNG`, 0x9b59b6,
`✅ Đã chọn: **${book.name}**
💰 Giá: **${formatMoney(book.price)}$**/cuốn
📦 Có thể mua tối đa: **${maxQ}** cuốn
💳 Số dư: **${formatMoney(bal)}$**

🎲 Skill có thể ra:
${book.rarities.map(r => RARITY[r]?.label || r).join("\n")}

━━━━━━━━━━━━━━
📚 Chọn số lượng muốn mua:`)],
          components: [qtyRow, customRow]
        });
        return;
      }

      if (sel.customId.startsWith("book_buy_")) {
        const parts  = sel.customId.split("_");
        const qtyRaw = parts[parts.length - 1];
        const key    = parts.slice(2, parts.length - 1).join("_");
        const book   = SKILL_BOOKS[key];
        const em     = BOOK_EMOJI[key] || "📚";

        const doOpenBooks = async (qty, interaction) => {
          const total = book.price * qty;
          if (getBalance(i.user.id) < total) {
            await msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c, `Cần **${formatMoney(total)}$**\n💳 Còn: **${formatMoney(getBalance(i.user.id))}$**`)], components: [] });
            bookCol.stop(); return;
          }

          // Animation
          const FRAMES = ["📚 . . . . .","📚 📖 . . . .","📚 📖 ✨ . . .","📚 📖 ✨ 💫 . .","📚 📖 ✨ 💫 🌟 .","📚 📖 ✨ 💫 🌟 🎇"];
          await msg.edit({ embeds: [gaEmbed("📚 ĐANG MỞ SÁCH...", 0x9b59b6, `Mở **${qty}x ${book.name}**...\n\n${FRAMES[0]}`)], components: [] });
          for (let f = 1; f < FRAMES.length; f++) {
            await new Promise(r => setTimeout(r, 300));
            await msg.edit({ embeds: [gaEmbed("📚 ĐANG MỞ SÁCH...", 0x9b59b6, `Mở **${qty}x ${book.name}**...\n\n${FRAMES[f]}`)] }).catch(() => {});
          }
          await new Promise(r => setTimeout(r, 400));

          setBalance(i.user.id, getBalance(i.user.id) - total);
          if (!skillInventory[i.user.id]) skillInventory[i.user.id] = [];

          const results = []; const rarityCount = {};
          for (let n = 0; n < qty; n++) {
            const rarityRoll = book.rarities[Math.floor(Math.random() * book.rarities.length)];
            const eligible   = Object.entries(SKILLS_POOL).filter(([, s]) => s.rarity === rarityRoll);
            if (eligible.length === 0) continue;
            const [skillKey, skill] = eligible[Math.floor(Math.random() * eligible.length)];
            skillInventory[i.user.id].push(skillKey);
            rarityCount[rarityRoll] = (rarityCount[rarityRoll] || 0) + 1;
            results.push({ skillKey, skill, rarityRoll });
            if ((rarityRoll === "IMMORTAL" || rarityRoll === "MYTHIC") && client && i.guild) {
              const rr = RARITY[rarityRoll];
              await broadcast(client, i.guild.id, i.channel.id, `🌈 **${i.user.username}** vừa mở sách ra **${skill.name}** — ${rr.label}! 📚`);
            }
          }
          saveSkill();

          const topRarity = Object.keys(rarityCount).sort((a,b) => Object.keys(RARITY).indexOf(b) - Object.keys(RARITY).indexOf(a))[0];
          const topSkill  = results.find(r => r.rarityRoll === topRarity);
          const topR      = RARITY[topRarity];
          const HYPE      = { IMMORTAL:"🌈 **IMMORTAL SKILL!!!** 🎆", MYTHIC:"🔴 **MYTHIC!!! CỰC HIẾM!!!** 🔥", LEGENDARY:"🟡 **LEGENDARY! Tuyệt vời!** 👑", EPIC:"🟣 **EPIC skill!** ✨", RARE:"🔵 **Rare!**", UNCOMMON:"🟢 Uncommon!", COMMON:"⚪ Common!" };
          const rarityLines = Object.entries(rarityCount).sort((a,b) => Object.keys(RARITY).indexOf(b[0]) - Object.keys(RARITY).indexOf(a[0])).map(([rar,cnt]) => `${RARITY[rar].icon} **${RARITY[rar].label.split(" ")[1]}**: ${cnt} cuốn`).join("\n");
          const bal2 = getBalance(i.user.id);
          const resultDesc = qty === 1 && topSkill
            ? `${HYPE[topRarity]}\n\n**${topSkill.skill.name}**\n${topR.label} | ${topSkill.skill.type?.toUpperCase() || "PASSIVE"}\n${topSkill.skill.desc}\n\n📖 Dạy gà: **/ga hochoi**`
            : `${HYPE[topRarity]}\n\n━━━━━━━━━━━━━━\n📚 **${qty} SÁCH ĐÃ MỞ:**\n${rarityLines}\n\n━━━━━━━━━━━━━━\n🏆 **XỊN NHẤT:**\n**${topSkill?.skill?.name}**\n${topR.label} | ${topSkill?.skill?.desc}\n\n💸 Đã chi: **${formatMoney(total)}$**\n💳 Còn lại: **${formatMoney(bal2)}$**`;

          const moreRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`book_buy_${key}_1`).setLabel("x1 lần nữa").setStyle(ButtonStyle.Secondary).setEmoji(em).setDisabled(bal2 < book.price),
            new ButtonBuilder().setCustomId(`book_buy_${key}_10`).setLabel("x10 lần nữa").setStyle(ButtonStyle.Danger).setEmoji(em).setDisabled(bal2 < book.price*10),
            new ButtonBuilder().setCustomId(`book_buy_${key}_custom`).setLabel("✏️ Nhập số").setStyle(ButtonStyle.Secondary).setDisabled(bal2 < book.price),
            new ButtonBuilder().setCustomId("book_back").setLabel("Đổi sách").setStyle(ButtonStyle.Secondary)
          );
          await msg.edit({ embeds: [gaEmbed(`🎉 MỞ ${qty} SÁCH THÀNH CÔNG!`, topR?.color || 0x9b59b6, resultDesc)], components: [moreRow] });
        };

        // Custom qty modal
        if (qtyRaw === "custom") {
          const modal = new ModalBuilder().setCustomId(`book_modal_${key}`).setTitle(`📚 Nhập số lượng — ${book.name}`);
          modal.addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("book_qty_input")
              .setLabel(`Giá: ${formatMoney(book.price)}$/cuốn | Số dư: ${formatMoney(getBalance(i.user.id))}$`)
              .setPlaceholder("Nhập số lượng (1 - 9999)...")
              .setStyle(TextInputStyle.Short).setRequired(true).setMinLength(1).setMaxLength(4)
          ));
          await sel.showModal(modal);
          const ms = await i.awaitModalSubmit({ filter: m => m.customId === `book_modal_${key}` && m.user.id === i.user.id, time: 60000 }).catch(() => null);
          if (!ms) return;
          const qtyIn = parseInt(ms.fields.getTextInputValue("book_qty_input"));
          if (isNaN(qtyIn) || qtyIn < 1) return ms.reply({ content: "❌ Số lượng không hợp lệ!", ephemeral: true });
          await ms.deferUpdate();
          await doOpenBooks(qtyIn, ms);
          return;
        }

        await sel.deferUpdate();
        await doOpenBooks(parseInt(qtyRaw), sel);
      }
    });

    bookCol.on("end", () => msg.edit({ components: [] }).catch(() => {}));
    return;
  }

  // ===================================================================
  // /ga hochoi — Dạy skill cho gà
  // ===================================================================
  if (sub === "hochoi") {
    const chickens  = getAliveChickens(i.user.id);
    if (chickens.length === 0) return i.editReply("❌ Bạn chưa có gà.");

    const userSkills = skillInventory[i.user.id] || [];
    if (userSkills.length === 0) return i.editReply("❌ Không có sách skill. Mua: **/ga muaskill**");
    chickens.sort((a, b) => calcPower({ ...b, ownerId: i.user.id }) - calcPower({ ...a, ownerId: i.user.id }));

    // Bước 1: Chọn gà
    const msg = await i.editReply({ embeds: [gaEmbed("📚 HỌC SKILL — BƯỚC 1", 0x9b59b6, "⏳ Đang tải...")], components: [], fetchReply: true });

    const chickenId = await awaitChickenSelect(
      msg, i.user.id, chickens,
      "📚 HỌC SKILL — BƯỚC 1", "Chọn gà muốn dạy skill:",
      0x9b59b6, "hoc_select_ga", "🐔 Chọn gà muốn dạy skill...", "hoc_page"
    );

    if (!chickenId) return;

    const c = findChicken(i.user.id, chickenId);
    if (!c) return msg.edit({ content: "❌ Không tìm thấy gà", components: [] });

    // Bước 2: Chọn skill từ túi đồ
    const uniqueSkills  = [...new Set(userSkills)];
    const skillOptions  = uniqueSkills.slice(0, 25).map(sk => {
      const s   = SKILLS_POOL[sk];
      const cnt = userSkills.filter(x => x === sk).length;
      const r   = RARITY[s?.rarity] || { label: "?" };
      const already = c.skills?.includes(sk) ? " ✅" : "";
      return new StringSelectMenuOptionBuilder()
        .setLabel(`${s?.name || sk} (x${cnt})${already}`.slice(0, 100))
        .setDescription(`${r.label} | ${s?.desc || ""}`.slice(0, 100))
        .setValue(sk);
    });

    const skillSelectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("hoc_select_skill")
        .setPlaceholder("📚 Chọn skill muốn học...")
        .addOptions(skillOptions)
    );

    await msg.edit({
      embeds: [gaEmbed("📚 HỌC SKILL — BƯỚC 2", 0x9b59b6,
`🐔 Gà đã chọn: ${RARITY[c.rarity].icon} **${c.name}**
📚 Skill hiện tại: **${(c.skills||[]).length}/${c.skillSlots||6}**

Chọn skill muốn dạy:
*(✅ = gà đã biết — sách vẫn mất)*`)],
      components: [skillSelectRow]
    });

    const selectedSkillKey = await new Promise(resolve => {
      const col = msg.createMessageComponentCollector({
        filter: x => x.user.id === i.user.id && x.customId === "hoc_select_skill",
        time: 30000, max: 1
      });
      col.on("collect", async btn => { await btn.deferUpdate(); resolve(btn.values[0]); });
      col.on("end", collected => { if (collected.size === 0) resolve(null); });
    });

    if (!selectedSkillKey) return msg.edit({ embeds: [gaEmbed("⌛ TIMEOUT", 0xe74c3c, "Hết thời gian chọn skill.")], components: [] });

    const skill  = SKILLS_POOL[selectedSkillKey];
    const uSk    = skillInventory[i.user.id] || [];
    const bookIdx = uSk.indexOf(selectedSkillKey);
    if (bookIdx === -1) return msg.edit({ embeds: [gaEmbed("❌ HẾT SÁCH", 0xe74c3c, "Không còn sách skill này!")], components: [] });

    // Xóa sách
    uSk.splice(bookIdx, 1);
    skillInventory[i.user.id] = uSk;
    saveSkill();

    // 20% fail
    if (Math.random() < 0.20) {
      c.hunger = Math.min(100, c.hunger + 10);
      saveInventory();
      return msg.edit({ embeds: [gaEmbed("❌ HỌC SKILL THẤT BẠI", 0xe74c3c,
        `🐔 **${c.name}** không học được **${skill.name}**!\n📘 Sách đã mất.`)], components: [] });
    }

    if (!c.skills) c.skills = [];
    if (c.skills.includes(selectedSkillKey)) {
      return msg.edit({ embeds: [gaEmbed("⚠️ SKILL TRÙNG", 0xf39c12,
        `🐔 **${c.name}** đã biết **${skill.name}**!\n📘 Sách đã mất.`)], components: [] });
    }
    if (c.skills.length >= (c.skillSlots || 6)) {
      return msg.edit({ embeds: [gaEmbed("⚠️ ĐẦY SLOT", 0xf39c12,
        `🐔 **${c.name}** đã đầy ${c.skillSlots || 6} skill!\n📘 Sách đã mất.`)], components: [] });
    }

    c.skills.push(selectedSkillKey);
    c.hunger = Math.min(100, c.hunger + 10);
    saveInventory();

    const r = RARITY[skill.rarity];
    return msg.edit({ embeds: [gaEmbed("📚 HỌC SKILL THÀNH CÔNG!", r.color,
`${RARITY[c.rarity].icon} **${c.name}** học được:

**${skill.name}**
${r.label} | ${skill.type?.toUpperCase() || "PASSIVE"}
${skill.desc}

Skills hiện tại: **${c.skills.length}/${c.skillSlots || 6}**
🍗 Đói: **${c.hunger}%**`)], components: [] });
  }

  // ===================================================================
  // /ga epskill — Ép skill
  // ===================================================================
  if (sub === "epskill") {
    const userSkills = skillInventory[i.user.id] || [];
    if (userSkills.length < 2) return i.editReply("❌ Cần ít nhất 2 sách skill để ép. Mua: **/ga muaskill**");

    const uniqueSkills2 = [...new Set(userSkills)];

    const sk1Options = uniqueSkills2.slice(0, 25).map(sk => {
      const s   = SKILLS_POOL[sk];
      const cnt = userSkills.filter(x => x === sk).length;
      const r   = RARITY[s?.rarity] || { label: "?" };
      return new StringSelectMenuOptionBuilder()
        .setLabel(`[1] ${s?.name || sk} (x${cnt})`.slice(0, 100))
        .setDescription(`${r.label}`.slice(0, 100))
        .setValue("sk1_" + sk);
    });

    const sk2Options = uniqueSkills2.slice(0, 25).map(sk => {
      const s   = SKILLS_POOL[sk];
      const cnt = userSkills.filter(x => x === sk).length;
      const r   = RARITY[s?.rarity] || { label: "?" };
      return new StringSelectMenuOptionBuilder()
        .setLabel(`[2] ${s?.name || sk} (x${cnt})`.slice(0, 100))
        .setDescription(`${r.label}`.slice(0, 100))
        .setValue("sk2_" + sk);
    });

    const row1 = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId("ep_sk1").setPlaceholder("📘 Chọn Sách 1...").addOptions(sk1Options)
    );
    const row2 = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId("ep_sk2").setPlaceholder("📘 Chọn Sách 2...").addOptions(sk2Options)
    );
    const rowConfirm = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("ep_confirm").setLabel("🔥 Ép Skill!").setStyle(ButtonStyle.Danger).setDisabled(true)
    );

    const msg = await i.editReply({
      embeds: [gaEmbed("⚗️ ÉP SKILL", 0x9b59b6,
`Chọn 2 sách skill để ép:

🎲 **Kết quả có thể:**
• Mất sách 1 thôi
• Mất cả 2 sách
• Nâng rarity ra skill mới

⚠️ Skill càng mạnh → tỉ lệ càng thấp`)],
      components: [row1, row2, rowConfirm],
      fetchReply: true
    });

    let epSk1 = null, epSk2 = null;

    const col = msg.createMessageComponentCollector({
      filter: x => x.user.id === i.user.id &&
        (x.customId === "ep_sk1" || x.customId === "ep_sk2" || x.customId === "ep_confirm"),
      time: 60000
    });

    col.on("collect", async btn => {
      if (btn.customId === "ep_sk1") {
        epSk1 = btn.values[0].replace("sk1_", "");
        await btn.deferUpdate();
      } else if (btn.customId === "ep_sk2") {
        epSk2 = btn.values[0].replace("sk2_", "");
        await btn.deferUpdate();
      } else if (btn.customId === "ep_confirm") {
        col.stop("done");
        await btn.deferUpdate();

        if (!epSk1 || !epSk2) return msg.edit({ content: "❌ Chọn đủ 2 sách!", components: [] });

        const sk1Data = SKILLS_POOL[epSk1];
        const sk2Data = SKILLS_POOL[epSk2];
        if (!sk1Data || !sk2Data) return msg.edit({ content: "❌ Skill không hợp lệ", components: [] });

        const rarityOrder = ["COMMON","UNCOMMON","RARE","EPIC","LEGENDARY","MYTHIC","IMMORTAL"];
        const r1idx = rarityOrder.indexOf(sk1Data.rarity);
        const r2idx = rarityOrder.indexOf(sk2Data.rarity);
        const maxR  = Math.max(r1idx, r2idx);

        const successRates = [0.80, 0.65, 0.50, 0.35, 0.20, 0.10, 0.05];
        const successRate  = successRates[maxR] || 0.05;

        const uSk = skillInventory[i.user.id] || [];
        const i1  = uSk.indexOf(epSk1);
        const hasBoth = epSk1 === epSk2 ? uSk.filter(x => x === epSk1).length >= 2 : uSk.indexOf(epSk2) !== -1;
        if (i1 === -1 || !hasBoth) {
          return msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ SÁCH", 0xe74c3c, "Không đủ 2 sách skill!")], components: [] });
        }

        await msg.edit({ embeds: [gaEmbed("⚗️ ĐANG ÉP SKILL...", 0x9b59b6,
          `🔥 **${sk1Data.name}** + **${sk2Data.name}**\n\n💫 . . . 🌟 . . . ✨`)], components: [] });
        await new Promise(r => setTimeout(r, 2000));

        const roll = Math.random();

        if (roll < successRate) {
          const newRarityIdx = Math.min(rarityOrder.length - 1, maxR + 1);
          const newRarity    = rarityOrder[newRarityIdx];
          const eligNew      = Object.entries(SKILLS_POOL).filter(([, s]) => s.rarity === newRarity);
          const [newKey, newSkill] = eligNew[Math.floor(Math.random() * eligNew.length)];

          uSk.splice(uSk.indexOf(epSk1), 1);
          uSk.splice(uSk.indexOf(epSk2), 1);
          uSk.push(newKey);
          skillInventory[i.user.id] = uSk;
          saveSkill();

          const rNew = RARITY[newRarity];
          if ((newRarity === "MYTHIC" || newRarity === "IMMORTAL") && client && i.guild) {
            await broadcast(client, i.guild.id, i.channel.id,
              `🌈 **${i.user.username}** vừa ép skill ra **${newSkill.name}** — ${rNew.label}! ⚗️`);
          }

          return msg.edit({ embeds: [gaEmbed("✨ ÉP SKILL THÀNH CÔNG!", rNew.color,
`🎉 Kết hợp thành công!

**${sk1Data.name}** + **${sk2Data.name}**
↓
✨ **${newSkill.name}**
${rNew.label} | ${newSkill.desc}`)], components: [] });

        } else if (roll < successRate + 0.30) {
          uSk.splice(uSk.indexOf(epSk1), 1);
          skillInventory[i.user.id] = uSk;
          saveSkill();
          return msg.edit({ embeds: [gaEmbed("❌ ÉP THẤT BẠI", 0xe74c3c,
            `💔 Thất bại — **${sk1Data.name}** đã mất!\n📘 Sách 2 còn lại.`)], components: [] });

        } else {
          uSk.splice(uSk.indexOf(epSk1), 1);
          const i2n = uSk.indexOf(epSk2);
          if (i2n !== -1) uSk.splice(i2n, 1);
          skillInventory[i.user.id] = uSk;
          saveSkill();
          return msg.edit({ embeds: [gaEmbed("💔 ÉP THẤT BẠI NẶNG", 0xe74c3c,
            `☠️ Thất bại hoàn toàn — **mất cả 2 sách!**`)], components: [] });
        }
      }

      // Enable confirm khi chọn đủ 2
      if (epSk1 && epSk2 && btn.customId !== "ep_confirm") {
        const sk1D = SKILLS_POOL[epSk1];
        const sk2D = SKILLS_POOL[epSk2];
        const updateRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("ep_confirm")
            .setLabel(`🔥 Ép: ${sk1D?.name || epSk1} + ${sk2D?.name || epSk2}`.slice(0, 80))
            .setStyle(ButtonStyle.Danger)
            .setDisabled(false)
        );
        await msg.edit({ components: [row1, row2, updateRow] });
      }
    });

    col.on("end", (_, reason) => {
      if (reason !== "done") msg.edit({ components: [] }).catch(() => {});
    });
    return;
  }

  // ===================================================================
  // /ga sell — Bán gà
  // ===================================================================
  if (sub === "sell") {
    const chickens = getAliveChickens(i.user.id);
    if (chickens.length === 0) return i.editReply({ embeds: [gaEmbed("💰 BÁN GÀ", 0xf39c12, "❌ Bạn chưa có gà!\n\nMua trứng: **/ga trung**")] });

    const BASE_PRICE = { COMMON:200000, UNCOMMON:400000, RARE:800000, EPIC:2000000, LEGENDARY:6000000, MYTHIC:20000000, IMMORTAL:80000000 };
    const calcSellPrice = c => Math.floor((BASE_PRICE[c.rarity] || 200000) * (1 + c.level * 0.05) * (1 + (c.nangCap || 0) * 0.1));

    const RARITY_ORDER = ["COMMON","UNCOMMON","RARE","EPIC","LEGENDARY","MYTHIC","IMMORTAL"];

    const getRarityStats = (list) => {
      const stats = {};
      for (const c of list) {
        if (!stats[c.rarity]) stats[c.rarity] = { count:0, total:0 };
        stats[c.rarity].count++;
        stats[c.rarity].total += calcSellPrice(c);
      }
      return stats;
    };

    const buildMainEmbed = (list) => {
      const stats = getRarityStats(list);
      const lines = RARITY_ORDER.filter(r => stats[r])
        .map(r => `${RARITY[r].icon} **${RARITY[r].label.split(" ")[1]}**: ${stats[r].count} con — ${formatMoney(stats[r].total)}$`)
        .join("\n");
      return gaEmbed("💰 BÁN GÀ", 0xf39c12,
        `Chọn cách bán gà:\n\n${lines}\n\n━━━━━━━━━━━━━━\n🐔 Tổng: **${list.length}** con | 💳 Số dư: **${formatMoney(getBalance(i.user.id))}$**`);
    };

    const buildModeSelect = (list) => {
      const stats = getRarityStats(list);
      const opts = [
        new StringSelectMenuOptionBuilder()
          .setLabel("🐔 Chọn từng con gà để bán")
          .setDescription("Chọn 1 con gà cụ thể")
          .setValue("mode_single")
          .setEmoji("🐔"),
        ...RARITY_ORDER.filter(r => stats[r]).map(r =>
          new StringSelectMenuOptionBuilder()
            .setLabel(`Bán tất cả ${RARITY[r].label.split(" ")[1]} (${stats[r].count} con)`)
            .setDescription(`Thu về: ${formatMoney(stats[r].total)}$`)
            .setValue(`mode_rarity_${r}`)
            .setEmoji(RARITY[r].icon)
        )
      ];
      return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("sell_mode_select")
          .setPlaceholder("💰 Chọn cách bán gà...")
          .addOptions(opts)
      );
    };

    const msg = await i.editReply({
      embeds: [buildMainEmbed(chickens)],
      components: [buildModeSelect(chickens)],
      fetchReply: true
    });

    const col = msg.createMessageComponentCollector({
      filter: x => {
        if (x.user.id !== i.user.id) { x.reply({ content: "❌ Đây không phải menu của bạn!", ephemeral: true }).catch(() => {}); return false; }
        return ["sell_mode_select","sell_confirm","sell_rarity_confirm","sell_back"].includes(x.customId);
      },
      time: 60000
    });

    col.on("collect", async sel => {

      // ── Quay lại menu chính ──
      if (sel.customId === "sell_back") {
        await sel.deferUpdate();
        const fresh = getAliveChickens(i.user.id);
        await msg.edit({ embeds: [buildMainEmbed(fresh)], components: [buildModeSelect(fresh)] });
        return;
      }

      // ── Chọn mode ──
      if (sel.customId === "sell_mode_select") {
        await sel.deferUpdate();
        const mode = sel.values[0];

        // Chọn từng con
        if (mode === "mode_single") {
          const list = getAliveChickens(i.user.id);
          list.sort((a,b) => calcPower({...b, ownerId:i.user.id}) - calcPower({...a, ownerId:i.user.id}));
          const chickenId = await awaitChickenSelect(
            msg, i.user.id, list,
            "💰 BÁN GÀ — CHỌN CON", "Chọn gà muốn bán (mạnh nhất đầu tiên):",
            0xf39c12, "sell_select_ga", "💰 Chọn gà muốn bán...", "sell_page"
          );
          if (!chickenId) return;

          const c  = findChicken(i.user.id, chickenId);
          if (!c || c.isDead) return msg.edit({ embeds: [gaEmbed("❌ LỖI", 0xe74c3c, "Gà không hợp lệ.")], components: [] });

          const sp = calcSellPrice(c);
          const r  = RARITY[c.rarity];
          const pw = calcPower({...c, ownerId:i.user.id});

          msg._sellSingle = { c, sp };
          await msg.edit({
            embeds: [gaEmbed("💰 XÁC NHẬN BÁN GÀ", 0xf39c12,
`${r.icon} **${c.name}**
${r.label} | Lv.**${c.level}** | +${c.nangCap||0}
🏆 Lực chiến: **${pw.toLocaleString("vi-VN")}**
🍗 Đói: **${c.hunger}%**

━━━━━━━━━━━━━━
💰 Giá bán: **${formatMoney(sp)}$**
⚠️ Không thể hoàn tác sau khi bán!`)],
            components: [new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId("sell_confirm").setLabel(`✅ Bán — ${formatMoney(sp)}$`).setStyle(ButtonStyle.Danger),
              new ButtonBuilder().setCustomId("sell_back").setLabel("◀ Quay lại").setStyle(ButtonStyle.Secondary)
            )]
          });
          return;
        }

        // Bán theo rarity
        if (mode.startsWith("mode_rarity_")) {
          const rar     = mode.replace("mode_rarity_", "");
          const targets = getAliveChickens(i.user.id).filter(c => c.rarity === rar);
          if (targets.length === 0) return msg.edit({ embeds: [gaEmbed("❌ KHÔNG CÓ GÀ", 0xe74c3c, `Không có gà ${RARITY[rar]?.label}!`)], components: [] });

          const totalSp = targets.reduce((s,c) => s + calcSellPrice(c), 0);
          const r       = RARITY[rar];
          const preview = [...targets]
            .sort((a,b) => calcSellPrice(b) - calcSellPrice(a))
            .slice(0, 5)
            .map(c => `${r.icon} **${c.name}** Lv.${c.level} +${c.nangCap||0} — ${formatMoney(calcSellPrice(c))}$`)
            .join("\n");
          const moreText = targets.length > 5 ? `\n*...và ${targets.length-5} con nữa*` : "";

          msg._sellRarity = { rar, targets, totalSp };
          await msg.edit({
            embeds: [gaEmbed(`💰 BÁN TẤT CẢ GÀ ${r.label.toUpperCase()}`, r.color,
`${r.icon} Bán **${targets.length}** gà ${r.label}

${preview}${moreText}

━━━━━━━━━━━━━━
💰 Tổng thu về: **${formatMoney(totalSp)}$**
⚠️ **Không thể hoàn tác!** Tất cả gà ${r.label} sẽ bị bán!`)],
            components: [new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId("sell_rarity_confirm").setLabel(`✅ Bán ${targets.length} con — ${formatMoney(totalSp)}$`).setStyle(ButtonStyle.Danger),
              new ButtonBuilder().setCustomId("sell_back").setLabel("◀ Quay lại").setStyle(ButtonStyle.Secondary)
            )]
          });
          return;
        }
      }

      // ── Xác nhận bán 1 con ──
      if (sel.customId === "sell_confirm") {
        await sel.deferUpdate();
        const { c, sp } = msg._sellSingle || {};
        if (!c) return msg.edit({ embeds: [gaEmbed("❌ LỖI", 0xe74c3c, "Phiên đã hết hạn.")], components: [] });
        const r = RARITY[c.rarity];
        chickenInventory[i.user.id] = (chickenInventory[i.user.id] || []).filter(x => x.id !== c.id);
        saveInventory();
        setBalance(i.user.id, getBalance(i.user.id) + sp);
        await msg.edit({ embeds: [gaEmbed("✅ BÁN THÀNH CÔNG!", 0x2ecc71,
          `${r.icon} **${c.name}** đã bán!\n${r.label} | Lv.${c.level}\n\n💰 +**${formatMoney(sp)}$**\n💳 Số dư: **${formatMoney(getBalance(i.user.id))}$**`)], components: [] });
        col.stop(); return;
      }

      // ── Xác nhận bán theo rarity ──
      if (sel.customId === "sell_rarity_confirm") {
        await sel.deferUpdate();
        const { rar, targets, totalSp } = msg._sellRarity || {};
        if (!targets) return msg.edit({ embeds: [gaEmbed("❌ LỖI", 0xe74c3c, "Phiên đã hết hạn.")], components: [] });
        const r = RARITY[rar];
        const ids = new Set(targets.map(c => c.id));
        chickenInventory[i.user.id] = (chickenInventory[i.user.id] || []).filter(c => !ids.has(c.id));
        saveInventory();
        setBalance(i.user.id, getBalance(i.user.id) + totalSp);
        await msg.edit({ embeds: [gaEmbed("✅ BÁN THÀNH CÔNG!", 0x2ecc71,
          `${r.icon} Đã bán **${targets.length}** gà ${r.label}!\n\n💰 +**${formatMoney(totalSp)}$**\n💳 Số dư: **${formatMoney(getBalance(i.user.id))}$**\n🐔 Kho còn: **${getAliveChickens(i.user.id).length}** con`)], components: [] });
        col.stop(); return;
      }
    });

    col.on("end", () => msg.edit({ components: [] }).catch(() => {}));
    return;
  }

  // ===================================================================
  // /ga choban — Đăng bán gà lên chợ
  // ===================================================================
  if (sub === "choban") {
    const chickens = getAliveChickens(i.user.id);
    if (chickens.length === 0) return i.editReply("❌ Bạn chưa có gà.");

    const listedChickenIds = Object.values(marketplaceData)
      .filter(l => l.sellerId === i.user.id && !l.sold && !l.cancelled)
      .map(l => l.chickenId);

    const availChickens = chickens.filter(c => !listedChickenIds.includes(c.id));
    if (availChickens.length === 0) return i.editReply("❌ Tất cả gà đang đăng bán rồi!");
    availChickens.sort((a, b) => calcPower({ ...b, ownerId: i.user.id }) - calcPower({ ...a, ownerId: i.user.id }));

    const msg = await i.editReply({ embeds: [gaEmbed("🏪 ĐĂNG BÁN GÀ", 0xf1c40f, "⏳ Đang tải...")], components: [], fetchReply: true });

    const chickenId = await awaitChickenSelect(
      msg, i.user.id, availChickens,
      "🏪 ĐĂNG BÁN GÀ", "Chọn gà muốn đăng bán lên chợ:",
      0xf1c40f, "choban_select_ga", "🐔 Chọn gà muốn bán...", "choban_page"
    );

    if (!chickenId) return;

    const c     = findChicken(i.user.id, chickenId);
    if (!c) return msg.edit({ content: "❌ Không tìm thấy gà", components: [] });

    const pw    = calcPower({ ...c, ownerId: i.user.id });
    const r     = RARITY[c.rarity];
    const e     = ELEMENTS[c.element] || { label: "" };
    const priceInput = i.options.getInteger("gia") || null;

    if (!priceInput || priceInput <= 0) {
      return msg.edit({ embeds: [gaEmbed("🏪 ĐĂNG BÁN GÀ", 0xf1c40f,
`${r.icon} **${c.name}** — ${r.label} ${e.label}
🏆 Lực chiến: **${pw.toLocaleString()}**

⚠️ Dùng lệnh: **/ga cho ban gia:[số tiền]** để đặt giá bán.

Ví dụ: **/ga cho ban gia:25000000**`)], components: [] });
    }

    const lid = newListingId();
    marketplaceData[lid] = {
      listingId:  lid,
      sellerId:   i.user.id,
      sellerName: i.user.username,
      chickenId:  c.id,
      chicken:    { ...c, ownerId: i.user.id },
      price:      priceInput,
      listedAt:   Date.now(),
      sold:       false,
      cancelled:  false
    };
    saveMarket();

    return msg.edit({ embeds: [gaEmbed("✅ ĐĂNG BÁN THÀNH CÔNG", 0x2ecc71,
`${r.icon} **${c.name}** đã đăng lên chợ!
${r.label} | 🏆${pw.toLocaleString()}
💰 Giá: **${formatMoney(priceInput)}$**

Xem: **/ga cho xem**
Hủy: **/ga cho huy**`)], components: [] });
  }

  // ===================================================================
  // /ga choxem — Xem chợ gà
  // ===================================================================
  if (sub === "choxem") {
    const listings = Object.values(marketplaceData).filter(l => !l.sold && !l.cancelled);
    if (listings.length === 0) {
      return i.editReply({ embeds: [gaEmbed("🏪 CHỢ GÀ", 0xf1c40f, "Chợ hiện trống!\n\nĐăng bán: **/ga cho ban**")] });
    }

    listings.sort((a, b) => calcPower(b.chicken) - calcPower(a.chicken));
    const top15 = listings.slice(0, 15);

    const selectOptions = top15.map(l => {
      const c  = l.chicken;
      const r  = RARITY[c.rarity];
      const pw = calcPower(c);
      const nc = c.nangCap > 0 ? ` +${c.nangCap}` : "";
      return new StringSelectMenuOptionBuilder()
        .setLabel(`${r.icon} ${c.name}${nc} | Lv${c.level}`.slice(0, 100))
        .setDescription(`🏆${pw.toLocaleString()} | 💰${l.price.toLocaleString()}$ | ${r.label}`.slice(0, 100))
        .setValue(l.listingId);
    });

    const selectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("cho_xem_select")
        .setPlaceholder("🐔 Chọn gà muốn xem chi tiết...")
        .addOptions(selectOptions)
    );

    const filterRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("mkt_sort_power").setLabel("🏆 Lực Chiến").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("mkt_sort_price").setLabel("💰 Giá").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("mkt_sort_rarity").setLabel("💎 Rarity").setStyle(ButtonStyle.Secondary)
    );

    const buildListText = (list) => list.map((l, idx) => {
      const c  = l.chicken;
      const r  = RARITY[c.rarity];
      const e  = ELEMENTS[c.element] || { label: "" };
      const pw = calcPower(c);
      const nc = c.nangCap > 0 ? ` +${c.nangCap}` : "";
      return `**${idx+1}.** ${r.icon} **${c.name}${nc}** | Lv${c.level}\n${r.label} ${e.label.split(" ")[0]} | 🏆${pw.toLocaleString()} | 💰**${l.price.toLocaleString()}$** | <@${l.sellerId}>`;
    }).join("\n\n");

    const msg = await i.editReply({
      embeds: [gaEmbed(`🏪 CHỢ GÀ (${listings.length} gà)`, 0xf1c40f, buildListText(top15))],
      components: [selectRow, filterRow],
      fetchReply: true
    });

    const col = msg.createMessageComponentCollector({
      filter: x => x.user.id === i.user.id,
      time: 60000
    });

    col.on("collect", async btn => {
      if (btn.customId === "cho_xem_select") {
        await btn.deferUpdate();
        const listing = marketplaceData[btn.values[0]];
        if (!listing || listing.sold || listing.cancelled) {
          return msg.edit({ embeds: [gaEmbed("❌ GÀ ĐÃ BÁN", 0xe74c3c, "Gà này đã được bán rồi!")], components: [] });
        }
        const c  = listing.chicken;
        const r  = RARITY[c.rarity];
        const e  = ELEMENTS[c.element] || { label: "" };
        const pw = calcPower(c);
        const nc = c.nangCap > 0 ? ` (+${c.nangCap})` : "";
        const skills = (c.skills || []).map(s => SKILLS_POOL[s]?.name || s).join("\n") || "Không có";

        const buyRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`mkt_buy_${listing.listingId}`).setLabel(`🛒 MUA ${formatMoney(listing.price)}$`).setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId("mkt_back").setLabel("↩️ Quay lại").setStyle(ButtonStyle.Secondary)
        );

        await msg.edit({ embeds: [gaEmbed(`${r.icon} ${c.name}${nc} — CHI TIẾT`, r.color,
`${r.label} | ${e.label}
🏆 **Lực Chiến: ${pw.toLocaleString()}**
👑 Chủ: <@${listing.sellerId}>
💰 Giá: **${formatMoney(listing.price)}$**

━━━━━━━━━━━━━━
📊 **CHỈ SỐ**

⭐ Lv${c.level} | ⚒️+${c.nangCap||0}
❤️${c.hp}/${c.maxHp} | ⚔️${c.damage} | 🛡️${c.armor}
💥${Math.round(c.crit*100)}% | 🌀${Math.round(c.dodge*100)}% | ☠️${Math.round((c.pierce||0)*100)}%

━━━━━━━━━━━━━━
⚔️ **SKILL**

${skills}

━━━━━━━━━━━━━━
📜 **LỊCH SỬ**

🏆${c.winCount}W/${c.loseCount}L | ⚔️${c.battleCount} trận`)], components: [buyRow] });

      } else if (btn.customId.startsWith("mkt_buy_")) {
        const lid = btn.customId.replace("mkt_buy_", "");
        await btn.deferUpdate();

        if (marketplaceLock.has(lid)) {
          return msg.edit({ embeds: [gaEmbed("❌ ĐANG XỬ LÝ", 0xe74c3c, "Thử lại sau.")], components: [] });
        }
        marketplaceLock.add(lid);
        col.stop("buying"); // Dừng outer collector — tránh duplicate col2

        try {
          const listing = marketplaceData[lid];
          if (!listing || listing.sold || listing.cancelled) {
            return msg.edit({ embeds: [gaEmbed("❌ GÀ ĐÃ BÁN", 0xe74c3c, "Gà này đã được bán rồi!")], components: [] });
          }
          if (listing.sellerId === i.user.id) {
            return msg.edit({ embeds: [gaEmbed("❌ KHÔNG THỂ MUA", 0xe74c3c, "Không thể mua gà của chính mình!")], components: [] });
          }
          if (getBalance(i.user.id) < listing.price) {
            return msg.edit({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c, `Cần **${formatMoney(listing.price)}$**`)], components: [] });
          }

          const confirmRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`mkt_confirm_${lid}`).setLabel(`✅ XÁC NHẬN MUA ${formatMoney(listing.price)}$`).setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId("mkt_cancel_buy").setLabel("❌ HỦY").setStyle(ButtonStyle.Danger)
          );

          await msg.edit({ embeds: [gaEmbed("🛒 XÁC NHẬN MUA GÀ", 0x2ecc71,
`${RARITY[listing.chicken.rarity].icon} **${listing.chicken.name}**
${RARITY[listing.chicken.rarity].label}
💰 Giá: **${formatMoney(listing.price)}$**

Bấm xác nhận để hoàn tất.`)], components: [confirmRow] });

          const col2 = msg.createMessageComponentCollector({
            filter: x => x.user.id === i.user.id && (x.customId.startsWith("mkt_confirm_") || x.customId === "mkt_cancel_buy"),
            time: 20000, max: 1
          });

          col2.on("collect", async btn2 => {
            if (btn2.customId === "mkt_cancel_buy") {
              marketplaceLock.delete(lid);
              return btn2.update({ embeds: [gaEmbed("❌ HỦY MUA", 0x95a5a6, "Đã hủy mua gà.")], components: [] });
            }

            const l2 = marketplaceData[lid];
            if (!l2 || l2.sold) {
              marketplaceLock.delete(lid);
              return btn2.update({ embeds: [gaEmbed("❌ ĐÃ BÁN", 0xe74c3c, "Gà vừa được người khác mua!")], components: [] });
            }

            setBalance(i.user.id, getBalance(i.user.id) - l2.price);
            setBalance(l2.sellerId, getBalance(l2.sellerId) + Math.floor(l2.price * 0.95));

            const chicken = { ...l2.chicken, ownerId: i.user.id };
            if (!chickenInventory[i.user.id]) chickenInventory[i.user.id] = [];
            chickenInventory[i.user.id].push(chicken);

            if (chickenInventory[l2.sellerId]) {
              chickenInventory[l2.sellerId] = chickenInventory[l2.sellerId].filter(c => c.id !== l2.chickenId);
            }

            marketplaceData[lid].sold   = true;
            marketplaceData[lid].soldTo = i.user.id;
            marketplaceData[lid].soldAt = Date.now();

            saveInventory();
            saveMarket();
            marketplaceLock.delete(lid);

            return btn2.update({ embeds: [gaEmbed("✅ MUA GÀ THÀNH CÔNG!", RARITY[chicken.rarity].color,
`${RARITY[chicken.rarity].icon} **${chicken.name}** đã về tay bạn!
${RARITY[chicken.rarity].label}
💰 Đã trả: **${formatMoney(l2.price)}$**
💡 Xem kho: **/ga kho**`)], components: [] });
          });

          col2.on("end", collected => {
            marketplaceLock.delete(lid);
            if (collected.size === 0) msg.edit({ components: [] }).catch(() => {});
          });

        } catch (err) {
          marketplaceLock.delete(lid);
          console.error("[marketplace buy error]", err);
        }

      } else if (btn.customId === "mkt_back") {
        await btn.deferUpdate();
        const freshListings = Object.values(marketplaceData).filter(l => !l.sold && !l.cancelled);
        freshListings.sort((a, b) => calcPower(b.chicken) - calcPower(a.chicken));
        const fresh15 = freshListings.slice(0, 15);
        await msg.edit({
          embeds: [gaEmbed(`🏪 CHỢ GÀ (${freshListings.length} gà)`, 0xf1c40f, buildListText(fresh15))],
          components: [selectRow, filterRow]
        });

      } else if (btn.customId === "mkt_sort_power" || btn.customId === "mkt_sort_price" || btn.customId === "mkt_sort_rarity") {
        await btn.deferUpdate();
        const sortType = btn.customId.replace("mkt_sort_", "");
        const sortedList = Object.values(marketplaceData).filter(l => !l.sold && !l.cancelled);
        if (sortType === "power") sortedList.sort((a, b) => calcPower(b.chicken) - calcPower(a.chicken));
        if (sortType === "price") sortedList.sort((a, b) => b.price - a.price);
        if (sortType === "rarity") {
          const ro = ["IMMORTAL","MYTHIC","LEGENDARY","EPIC","RARE","UNCOMMON","COMMON"];
          sortedList.sort((a, b) => ro.indexOf(a.chicken.rarity) - ro.indexOf(b.chicken.rarity));
        }
        await msg.edit({
          embeds: [gaEmbed(`🏪 CHỢ GÀ (${sortedList.length} gà) — Sort: ${sortType}`, 0xf1c40f, buildListText(sortedList.slice(0, 15)))],
          components: [selectRow, filterRow]
        });
      }
    });

    col.on("end", (_, reason) => {
      if (reason !== "buying") msg.edit({ components: [] }).catch(() => {});
    });
    return;
  }

  // ===================================================================
  // /ga chohuy — Hủy bán gà
  // ===================================================================
  if (sub === "chohuy") {
    const myListings = Object.values(marketplaceData).filter(
      l => l.sellerId === i.user.id && !l.sold && !l.cancelled
    );
    if (myListings.length === 0) return i.editReply("❌ Bạn không có gà nào đang bán.");

    const options = myListings.slice(0, 25).map(l => {
      const c = l.chicken;
      const r = RARITY[c.rarity];
      const nc = c.nangCap > 0 ? ` +${c.nangCap}` : "";
      return new StringSelectMenuOptionBuilder()
        .setLabel(`${r.icon} ${c.name}${nc} | Lv${c.level}`.slice(0, 100))
        .setDescription(`💰${l.price.toLocaleString()}$ | ${r.label}`.slice(0, 100))
        .setValue(l.listingId);
    });

    const selectRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("chohuy_select")
        .setPlaceholder("🐔 Chọn gà muốn hủy bán...")
        .addOptions(options)
    );

    const msg = await i.editReply({ embeds: [gaEmbed("🏪 HỦY ĐĂNG BÁN", 0xf39c12, "Chọn gà muốn hủy bán:")], components: [selectRow], fetchReply: true });

    const col = msg.createMessageComponentCollector({
      filter: x => x.user.id === i.user.id && x.customId === "chohuy_select",
      time: 30000, max: 1
    });

    col.on("collect", async btn => {
      const listing = marketplaceData[btn.values[0]];
      if (!listing || listing.sold || listing.cancelled) {
        return btn.update({ embeds: [gaEmbed("❌ LỖI", 0xe74c3c, "Listing không hợp lệ.")], components: [] });
      }
      listing.cancelled = true;
      saveMarket();
      const r = RARITY[listing.chicken.rarity];
      return btn.update({ embeds: [gaEmbed("✅ ĐÃ HỦY BÁN", 0x2ecc71,
        `${r.icon} **${listing.chicken.name}** đã hủy bán thành công!`)], components: [] });
    });

    col.on("end", collected => { if (collected.size === 0) msg.edit({ components: [] }).catch(() => {}); });
    return;
  }

  // ===================================================================
  // /ga chotop — Top lực chiến trong chợ
  // ===================================================================
  if (sub === "chotop") {
    const listings = Object.values(marketplaceData).filter(l => !l.sold && !l.cancelled);
    listings.sort((a, b) => calcPower(b.chicken) - calcPower(a.chicken));
    const top10 = listings.slice(0, 10);

    if (top10.length === 0) return i.editReply({ embeds: [gaEmbed("🏆 TOP CHỢ GÀ", 0xf1c40f, "Chợ trống!")] });

    const lines = top10.map((l, idx) => {
      const c  = l.chicken;
      const r  = RARITY[c.rarity];
      const pw = calcPower(c);
      return `**${idx+1}.** ${r.icon} **${c.name}** | Lv${c.level}\n${r.label} | 🏆${pw.toLocaleString()} | 💰${formatMoney(l.price)} | <@${l.sellerId}>`;
    }).join("\n\n");

    return i.editReply({ embeds: [gaEmbed("🏆 TOP GÀ MẠNH NHẤT CHỢ", 0xf1c40f, lines)] });
  }

  // ===================================================================
  // /ga top — Top gà toàn server
  // ===================================================================
  if (sub === "top") {
    const allChickens = [];
    for (const [uid, chickens] of Object.entries(chickenInventory)) {
      for (const c of (chickens || [])) {
        if (!c.isDead) allChickens.push({ ...c, ownerId: uid });
      }
    }
    allChickens.sort((a, b) => calcPower(b) - calcPower(a));
    const top10 = allChickens.slice(0, 10);

    if (top10.length === 0) return i.editReply({ embeds: [gaEmbed("📊 TOP CHIẾN KÊ", 0xf1c40f, "Chưa có dữ liệu")] });

    const lines = top10.map((c, idx) => {
      const r  = RARITY[c.rarity];
      const e  = ELEMENTS[c.element] || { label: "" };
      const pw = calcPower(c);
      const nc = c.nangCap > 0 ? ` +${c.nangCap}` : "";
      return `**${idx+1}.** ${r.icon} **${c.name}${nc}** (<@${c.ownerId}>)\n` +
             `${r.label} ${e.label.split(" ")[0]} | Lv${c.level} | 🏆**${pw.toLocaleString()}**\n` +
             `❤️${c.hp} | ⚔️${c.damage} | 🏅${c.winCount}W/${c.loseCount}L`;
    }).join("\n\n");

    return i.editReply({ embeds: [gaEmbed("📊 TOP CHIẾN KÊ SERVER", 0xf1c40f, lines)] });
  }

  // ===================================================================
  // /ga daga — PvP đá gà
  // ===================================================================
  if (sub === "daga") {
    const enemy  = i.options.getUser("user");
    const tienRaw = i.options.getString("tien");
    const amount  = parseMoney(tienRaw);

    if (!enemy)                         return i.editReply("❌ Không tìm thấy người chơi");
    if (enemy.bot)                      return i.editReply("❌ Không thể đấu với bot");
    if (enemy.id === i.user.id)         return i.editReply("❌ Không thể tự đấu");
    if (!amount)                        return i.editReply("❌ Tiền cược không hợp lệ!ỊDVD: `50m`, `1b`, `500k`");
    if (getBalance(i.user.id) < amount) return i.editReply("❌ Bạn không đủ tiền");
    if (battleLock.has(i.user.id))      return i.editReply("⏳ Bạn đang trong trận đấu");
    if (battleLock.has(enemy.id))       return i.editReply("⏳ Đối thủ đang trong trận đấu");

    const p1Chickens = getAliveChickens(i.user.id);
    if (p1Chickens.length === 0) return i.editReply("❌ Bạn chưa có gà. Mua: **/ga trung**");

    const acceptRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("daga_accept").setLabel("⚔️ CHẤP NHẬN").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("daga_decline").setLabel("❌ TỪ CHỐI").setStyle(ButtonStyle.Danger)
    );

    const msg = await i.editReply({
      embeds: [gaEmbed("🐔 LỜI MỜI ĐÁ GÀ", 0xf1c40f,
`⚔️ **${i.user}** thách đấu **${enemy}**!

💰 Tiền cược: **${formatMoney(amount)}$**
🏆 Người thắng nhận: **${formatMoney(Math.floor(amount * 1.95))}$**

⏳ ${enemy} hãy phản hồi trong 30 giây...`)],
      components: [acceptRow],
      fetchReply: true
    });

    const acceptCol = msg.createMessageComponentCollector({
      filter: x => x.user.id === enemy.id && (x.customId === "daga_accept" || x.customId === "daga_decline"),
      time: 30000, max: 1
    });

    acceptCol.on("collect", async btn => {
      if (btn.customId === "daga_decline") {
        return btn.update({ embeds: [gaEmbed("❌ TỪ CHỐI", 0xe74c3c, `${enemy} đã từ chối thách đấu.`)], components: [] });
      }

      if (getBalance(enemy.id) < amount) {
        return btn.update({ embeds: [gaEmbed("❌ KHÔNG ĐỦ TIỀN", 0xe74c3c, `${enemy} không đủ **${formatMoney(amount)}$**`)], components: [] });
      }

      const p2Chickens = getAliveChickens(enemy.id);
      if (p2Chickens.length === 0) {
        return btn.update({ embeds: [gaEmbed("❌ KHÔNG CÓ GÀ", 0xe74c3c, `${enemy} chưa có gà`)], components: [] });
      }

      // Validate trước khi lock để tránh lock leak
      const p1Avail = p1Chickens.filter(c => !canBattle(c));
      if (p1Avail.length === 0) {
        return btn.update({ embeds: [gaEmbed("❌ KHÔNG CÓ GÀ HỢP LỆ", 0xe74c3c,
          `**${i.user.username}**: Không có gà nào có thể chiến đấu`)], components: [] });
      }
      const p2ChickensFresh = getAliveChickens(enemy.id);
      const p2Avail0 = p2ChickensFresh.filter(c => !canBattle(c));
      if (p2Avail0.length === 0) {
        return btn.update({ embeds: [gaEmbed("❌ KHÔNG CÓ GÀ HỢP LỆ", 0xe74c3c,
          `**${enemy.username}**: Không có gà nào có thể chiến đấu`)], components: [] });
      }

      await btn.update({ embeds: [gaEmbed("✅ ĐÃ CHẤP NHẬN", 0x2ecc71,
        `⚔️ **${i.user}** vs **${enemy}**\n💰 Cược: **${formatMoney(amount)}$**\n\n🐔 Mỗi người chọn gà ra trận...`)], components: [] });

      battleLock.set(i.user.id, true);
      battleLock.set(enemy.id, true);

      try {
        // === P1 CHỌN GÀ ===
        p1Avail.sort((a, b) => calcPower({ ...b, ownerId: i.user.id }) - calcPower({ ...a, ownerId: i.user.id }));

        const p1ChickenId = await awaitChickenSelect(
          msg, i.user.id, p1Avail,
          `⚔️ CHỌN GÀ — ${i.user.username.toUpperCase()}`,
          `⏳ **${i.user}** chọn gà ra trận trong 30 giây...`,
          0x3498db, "select_p1_ga", `🐔 ${i.user.username} chọn gà...`, "p1_page", 30000
        );

        if (!p1ChickenId) {
          return msg.edit({ embeds: [gaEmbed("⌛ TIMEOUT", 0xe74c3c, `${i.user} không chọn gà. Trận hủy.`)], components: [] });
        }

        // === P2 CHỌN GÀ ===
        const p2Avail = getAliveChickens(enemy.id).filter(c => !canBattle(c));
        if (p2Avail.length === 0) {
          return msg.edit({ embeds: [gaEmbed("❌ KHÔNG CÓ GÀ HỢP LỆ", 0xe74c3c,
            `**${enemy.username}**: Không có gà nào có thể chiến đấu`)], components: [] });
        }
        p2Avail.sort((a, b) => calcPower({ ...b, ownerId: enemy.id }) - calcPower({ ...a, ownerId: enemy.id }));

        const p2ChickenId = await awaitChickenSelect(
          msg, enemy.id, p2Avail,
          `⚔️ CHỌN GÀ — ${enemy.username.toUpperCase()}`,
          `⏳ **${enemy}** chọn gà ra trận trong 30 giây...`,
          0x9b59b6, "select_p2_ga", `🐔 ${enemy.username} chọn gà...`, "p2_page", 30000
        );

        if (!p2ChickenId) {
          return msg.edit({ embeds: [gaEmbed("⌛ TIMEOUT", 0xe74c3c, `${enemy} không chọn gà. Trận hủy.`)], components: [] });
        }

        const c1 = findChicken(i.user.id, p1ChickenId);
        const c2 = findChicken(enemy.id,  p2ChickenId);
        if (!c1 || !c2) throw new Error("chicken not found");

        const c1err = canBattle(c1);
        const c2err = canBattle(c2);
        if (c1err || c2err) {
          return msg.edit({ embeds: [gaEmbed("❌ KHÔNG HỢP LỆ", 0xe74c3c, c1err || c2err)], components: [] });
        }

        setBalance(i.user.id, getBalance(i.user.id) - amount);
        setBalance(enemy.id,  getBalance(enemy.id)  - amount);

        const pw1 = calcPower({ ...c1, ownerId: i.user.id });
        const pw2 = calcPower({ ...c2, ownerId: enemy.id });
        const r1  = RARITY[c1.rarity];
        const r2  = RARITY[c2.rarity];

        await msg.edit({ embeds: [gaEmbed("⚔️ TRẬN ĐÁ GÀ BẮT ĐẦU!", 0xe74c3c,
`╔══════════════════════╗
⚔️ **${c1.name.toUpperCase()} VS ${c2.name.toUpperCase()}** ⚔️
╚══════════════════════╝

${r1.icon} **${c1.name}** (${i.user})
${r1.label} Lv${c1.level} +${c1.nangCap||0}
❤️${c1.hp} | ⚔️${c1.damage} | 🏆${pw1.toLocaleString()}

VS

${r2.icon} **${c2.name}** (${enemy})
${r2.label} Lv${c2.level} +${c2.nangCap||0}
❤️${c2.hp} | ⚔️${c2.damage} | 🏆${pw2.toLocaleString()}

🔥 **BO3 BẮT ĐẦU!**`)], components: [] });

        await new Promise(r => setTimeout(r, 2500));

        const { p1Wins, p2Wins } = await runBattle(msg, i.user, enemy, c1, c2);
        const p1Win = p1Wins > p2Wins;

        const reward    = Math.floor(amount * 1.95);
        const winChicken  = p1Win ? c1 : c2;
        const loseChicken = p1Win ? c2 : c1;
        const winOwner    = p1Win ? i.user.id : enemy.id;
        const loseOwner   = p1Win ? enemy.id  : i.user.id;
        const winnerUser  = p1Win ? i.user : enemy;
        const loserUser   = p1Win ? enemy  : i.user;

        if (p1Win) setBalance(i.user.id, getBalance(i.user.id) + reward);
        else       setBalance(enemy.id,  getBalance(enemy.id)  + reward);

        winChicken.battleCount++;  winChicken.winCount++;
        loseChicken.battleCount++; loseChicken.loseCount++;
        c1.hunger = Math.min(100, c1.hunger + 20);
        c2.hunger = Math.min(100, c2.hunger + 20);
        battleCooldown[c1.id] = Date.now();
        battleCooldown[c2.id] = Date.now();
        saveCooldown();

        if (!winChicken.exp) winChicken.exp = 0;
        winChicken.exp += Math.floor(Math.random() * 50 + 30);

        let loseExtra = "";
        const deathRoll  = Math.random();
        const deathChance = 0.01 + (loseChicken.hunger > 70 ? 0.02 : 0);

        if (deathRoll < deathChance) {
          loseChicken.isDead = true;
          deadChicken[loseChicken.id] = { ...loseChicken, diedAt: Date.now() };
          if (chickenInventory[loseOwner]) {
            chickenInventory[loseOwner] = chickenInventory[loseOwner].filter(c => c.id !== loseChicken.id);
          }
          saveDead();
          loseExtra = `\n💀 **${loseChicken.name} ĐÃ CHẾT!** Mất khỏi kho.`;
        } else if (deathRoll < 0.30) {
          loseChicken.injured      = true;
          loseChicken.injuredUntil = Date.now() + 5 * 60 * 1000;
          loseExtra = `\n🩸 **${loseChicken.name} bị thương!** Nghỉ 5 phút.`;
        } else if (deathRoll < 0.55 && loseChicken.level > 1) {
          loseChicken.level--;
          loseExtra = `\n⬇️ **${loseChicken.name} rớt LV${loseChicken.level}!**`;
        }

        if (!chickenStats[winOwner])  chickenStats[winOwner]  = { wins:0, losses:0, streak:0 };
        if (!chickenStats[loseOwner]) chickenStats[loseOwner] = { wins:0, losses:0, streak:0 };
        chickenStats[winOwner].wins++;
        chickenStats[winOwner].streak++;
        chickenStats[loseOwner].losses++;
        chickenStats[loseOwner].streak = 0;

        saveStats();
        saveInventory();

        if (client && i.guild && amount >= 10000000) {
          await broadcast(client, i.guild.id, i.channel.id,
            `🏆 **${winnerUser.username}** đánh bại **${loserUser.username}** với **${winChicken.name}** — giành **${formatMoney(reward)}$**! ⚔️`);
        }

        const wR = RARITY[winChicken.rarity];
        await msg.edit({ embeds: [gaEmbed("🏆 KẾT QUẢ ĐÁ GÀ", wR.color,
`╔══════════════════════╗
🏆 **${winChicken.name.toUpperCase()} CHIẾN THẮNG!** 🏆
╚══════════════════════╝

👑 **${winnerUser}**
${wR.icon} **${winChicken.name}** | ${p1Win ? p1Wins : p2Wins} - ${p1Win ? p2Wins : p1Wins}

💰 Nhận: **+${formatMoney(reward)}$**
🔥 Win Streak: **${chickenStats[winOwner].streak}**
${loseExtra}

━━━━━━━━━━━━━━

💀 **${loserUser}** thua
${RARITY[loseChicken.rarity].icon} **${loseChicken.name}** | Đói **${loseChicken.hunger}%**`)], components: [] });

      } catch (err) {
        console.error("[battle error]", err);
        try {
          await msg.edit({ embeds: [gaEmbed("❌ LỖI TRẬN ĐẤU", 0xe74c3c, "Đã xảy ra lỗi. Trận hủy.")], components: [] });
        } catch {}
      } finally {
        battleLock.delete(i.user.id);
        battleLock.delete(enemy.id);
      }
    });

    acceptCol.on("end", collected => {
      if (collected.size === 0) {
        msg.edit({ embeds: [gaEmbed("⌛ TIMEOUT", 0xe74c3c, "Không có phản hồi. Thách đấu hủy.")], components: [] }).catch(() => {});
      }
    });

    return;
  }

  // ===================================================================
  // Fallback
  // ===================================================================
  return i.editReply("❌ Lệnh /ga không hợp lệ.");
}

// ===================================================================
// SECTION: SLASH COMMAND DEFINITIONS
// ===================================================================
const DAGA_COMMANDS = [
  {
    name: "ga",
    description: "🐔 Hệ thống Đá Gà Casino",
    options: [
      { type: 1, name: "trung",    description: "🥚 Mua và mở trứng gà"               },
      { type: 1, name: "kho",      description: "📦 Xem kho gà của bạn"               },
      { type: 1, name: "info",     description: "📋 Xem chi tiết gà"                  },
      { type: 1, name: "nangcap",  description: "⬆️ Nâng cấp level gà"               },
      { type: 1, name: "nangdo",   description: "⚒️ Nâng độ gà (+N, vô hạn)"         },
      { type: 1, name: "choan",    description: "🍗 Cho gà ăn miễn phí"               },
      { type: 1, name: "muadoan",  description: "🛒 Mua đồ ăn cho gà"                 },
      { type: 1, name: "doan",     description: "🍗 Dùng đồ ăn cho gà"               },
      { type: 1, name: "muaskill", description: "📚 Mua sách skill ngẫu nhiên"         },
      { type: 1, name: "hochoi",   description: "📖 Dạy skill cho gà"                 },
      { type: 1, name: "epskill",  description: "⚗️ Ép 2 sách skill để nâng rarity"  },
      { type: 1, name: "sell",     description: "💰 Bán gà lấy tiền"                  },
      { type: 1, name: "top",      description: "📊 Top gà mạnh nhất server"          },
      {
        type: 1, name: "daga", description: "⚔️ Thách đấu PvP đá gà",
        options: [
          { type: 6, name: "user", description: "Người chơi muốn thách đấu", required: true },
          { type: 4, name: "tien", description: "Số tiền cược", required: true, minValue: 1000 }
        ]
      },
      {
        type: 1, name: "choban", description: "🏪 Đăng bán gà lên chợ người chơi",
        options: [
          { type: 4, name: "gia", description: "Giá bán (số tiền)", required: true, minValue: 1000 }
        ]
      },
      { type: 1, name: "choxem",  description: "🔍 Xem chợ gà người chơi"            },
      { type: 1, name: "chohuy",  description: "❌ Hủy đăng bán gà"                  },
      { type: 1, name: "chotop",  description: "🏆 Top gà lực chiến cao nhất trong chợ" }
    ]
  }
];

// ===================================================================
// EXPORTS
// ===================================================================
module.exports = {
  handleDaGa,
  DAGA_COMMANDS,
  getChickenInventory: () => chickenInventory,
  getMarketplace:      () => marketplaceData,
  getSkillInventory:   () => skillInventory,
  RARITY,
  SKILLS_POOL,
  CHICKEN_NAMES,
  ELEMENTS,
  calcPower,
  createChicken
};