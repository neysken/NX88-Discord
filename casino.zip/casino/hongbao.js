// ===================================================================
// MODULE HỒNG BAO — hongbao.js
// discord.js v14 | Node.js
// Tích hợp vào index.js qua handleHongBao + handleHongBaoButton
// ===================================================================

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

// ===================================================================
// SECTION: PARSE MONEY
// ===================================================================
function parseMoney(str) {
  if (str === null || str === undefined) return null;
  str = str.toString().trim().toLowerCase().replace(/,/g, "");
  const match = str.match(/^(\d+(?:\.\d+)?)\s*([kmbt]?)$/);
  if (!match) {
    const n = parseInt(str.replace(/[^0-9]/g, ""));
    return isNaN(n) || n <= 0 ? null : n;
  }
  const units = { k: 1_000, m: 1_000_000, b: 1_000_000_000, t: 1_000_000_000_000 };
  const result = Math.floor(parseFloat(match[1]) * (units[match[2]] || 1));
  return isNaN(result) || result <= 0 ? null : result;
}

// ===================================================================
// SECTION: IN-MEMORY STORE
// Không cần file JSON — hồng bao hết sau khi đủ người nhận hoặc expire
// ===================================================================

// Map<hongbaoId, HongBaoData>
const hongbaoStore = new Map();

// Anti-spam: Map<userId, timestamp> — khóa user click quá nhanh
const claimCooldown = new Map();
const CLAIM_COOLDOWN_MS = 1000;

// ===================================================================
// SECTION: UTILITY
// ===================================================================
function hbId() {
  return `hb_${Date.now()}_${Math.floor(Math.random() * 9999)}`;
}

function formatMoney(x) {
  return Number(x || 0).toLocaleString("vi-VN");
}

/**
 * Random phân phối tiền cho qty người — tổng đúng bằng total.
 * Dùng thuật toán "broken stick": random điểm cắt.
 */
function splitMoney(total, qty) {
  if (qty === 1) return [total];
  const MIN = 1;
  // Mỗi người tối thiểu 1đ
  let remaining = total - qty * MIN;
  if (remaining < 0) remaining = 0;

  // Tạo qty-1 điểm cắt ngẫu nhiên trong [0, remaining]
  const points = Array.from({ length: qty - 1 }, () =>
    Math.floor(Math.random() * (remaining + 1))
  ).sort((a, b) => a - b);

  const parts = [];
  let prev = 0;
  for (const p of points) {
    parts.push(p - prev + MIN);
    prev = p;
  }
  parts.push(remaining - prev + MIN);
  return parts;
}

// ===================================================================
// SECTION: BUILD EMBED
// ===================================================================
function buildHongBaoEmbed(hb) {
  const claimedList = hb.claims
    .slice(-10) // chỉ hiển thị 10 người cuối để tránh embed quá dài
    .map(c => `• <@${c.userId}> nhận **${formatMoney(c.amount)}$**`)
    .join("\n");

  const remaining = hb.slots - hb.claims.length;
  const claimedTotal = hb.claims.reduce((s, c) => s + c.amount, 0);
  const expired = hb.expired || remaining === 0;

  const desc =
`🧧 **${hb.creatorName}** tặng hồng bao!

💰 Tổng tiền: **${formatMoney(hb.total)}$**
👥 Số lượt: **${hb.slots}** người
🎁 Còn lại: **${remaining}** lượt
💸 Đã phát: **${formatMoney(claimedTotal)}$**

━━━━━━━━━━━━━━
${claimedList || "*(Chưa có ai nhận)*"}
${hb.claims.length > 10 ? `\n*...và ${hb.claims.length - 10} người khác*` : ""}
${expired ? "\n\n🔴 **Hồng bao đã hết!**" : ""}`;

  return new EmbedBuilder()
    .setTitle("🧧 HỒNG BAO MAY MẮN")
    .setColor(expired ? 0x95a5a6 : 0xe74c3c)
    .setDescription(desc)
    .setFooter({ text: "🎰 Royal Baccarat • Nhấn nút để nhận!" })
    .setTimestamp();
}

function buildHongBaoRow(hb) {
  const remaining = hb.slots - hb.claims.length;
  const expired   = hb.expired || remaining === 0;
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`hongbao_claim_${hb.id}`)
      .setLabel(expired ? "🔴 Hết hồng bao" : `🧧 Nhận hồng bao (còn ${remaining})`)
      .setStyle(expired ? ButtonStyle.Secondary : ButtonStyle.Danger)
      .setDisabled(expired)
  );
}

// ===================================================================
// SECTION: HANDLER — /hongbao
// ===================================================================
async function handleHongBao(i, { getBalance, setBalance }) {
  const totalRaw = i.options.getString("sotien");
  const total    = parseMoney(totalRaw);
  const slots    = i.options.getInteger("soluong");

  // Validate
  if (!total) {
    return i.editReply(`❌ Số tiền không hợp lệ!\nVD: \`50m\`, \`1b\`, \`500k\``);
  }
  if (!slots || slots < 1 || slots > 200) {
    return i.editReply("❌ Số lượng phải từ 1 đến 200 người!");
  }
  if (total < slots) {
    return i.editReply(`❌ Tổng tiền phải ít nhất **${formatMoney(slots)}$** (mỗi người tối thiểu 1$)`);
  }
  if (total > 10_000_000_000) {
    return i.editReply("❌ Tổng tiền tối đa 10 tỷ!");
  }

  const bal = getBalance(i.user.id);
  if (bal < total) {
    return i.editReply(`❌ Không đủ tiền!\n💳 Số dư: **${formatMoney(bal)}$** | Cần: **${formatMoney(total)}$**`);
  }

  // Trừ tiền ngay
  setBalance(i.user.id, bal - total);

  // Pre-generate phân phối (lazy: sẽ pop từng phần khi claim)
  const pool = splitMoney(total, slots);
  // Shuffle pool để random hơn
  for (let k = pool.length - 1; k > 0; k--) {
    const j = Math.floor(Math.random() * (k + 1));
    [pool[k], pool[j]] = [pool[j], pool[k]];
  }

  const id = hbId();
  const hb = {
    id,
    creatorId:   i.user.id,
    creatorName: i.user.username,
    total,
    slots,
    pool,         // mảng tiền còn chờ nhận
    claims: [],   // [{ userId, username, amount, ts }]
    expired: false,
    createdAt: Date.now(),
    messageId: null,
    channelId: i.channel.id
  };

  hongbaoStore.set(id, hb);

  // Auto-expire sau 24h
  setTimeout(() => {
    const h = hongbaoStore.get(id);
    if (h && !h.expired) {
      h.expired = true;
      // Hoàn tiền phần chưa phát
      const claimedTotal = h.claims.reduce((s, c) => s + c.amount, 0);
      const refund = total - claimedTotal;
      if (refund > 0) {
        setBalance(h.creatorId, getBalance(h.creatorId) + refund);
      }
    }
  }, 24 * 60 * 60 * 1000);

  const msg = await i.editReply({
    embeds:     [buildHongBaoEmbed(hb)],
    components: [buildHongBaoRow(hb)],
    fetchReply: true
  });

  hb.messageId = msg.id;
}

// ===================================================================
// SECTION: BUTTON HANDLER — hongbao_claim_*
// ===================================================================
async function handleHongBaoButton(i, { getBalance, setBalance, sendLog }) {
  // Chỉ xử lý button hongbao_claim_*
  if (!i.customId.startsWith("hongbao_claim_")) return false;

  const id = i.customId.replace("hongbao_claim_", "");
  const hb = hongbaoStore.get(id);

  if (!hb) {
    return i.reply({ content: "❌ Hồng bao không còn tồn tại!", ephemeral: true });
  }

  // Anti-spam cooldown
  const lastClaim = claimCooldown.get(i.user.id) || 0;
  if (Date.now() - lastClaim < CLAIM_COOLDOWN_MS) {
    return i.reply({ content: "⏳ Chậm thôi! Thử lại ngay.", ephemeral: true });
  }
  claimCooldown.set(i.user.id, Date.now());

  // Đã nhận rồi
  if (hb.claims.some(c => c.userId === i.user.id)) {
    return i.reply({ content: "❌ Bạn đã nhận hồng bao này rồi!", ephemeral: true });
  }

  // Hết lượt hoặc expired
  if (hb.expired || hb.claims.length >= hb.slots || hb.pool.length === 0) {
    hb.expired = true;
    await i.reply({ content: "❌ Hồng bao đã hết lượt!", ephemeral: true });
    // Update message để disable button
    try {
      await i.message.edit({ embeds: [buildHongBaoEmbed(hb)], components: [buildHongBaoRow(hb)] });
    } catch {}
    return true;
  }

  // Nhận tiền — pop từ pool (đã shuffle)
  const amount = hb.pool.pop();
  hb.claims.push({ userId: i.user.id, username: i.user.username, amount, ts: Date.now() });
  setBalance(i.user.id, getBalance(i.user.id) + amount);

  // Kiểm tra hết
  const done = hb.claims.length >= hb.slots || hb.pool.length === 0;
  if (done) hb.expired = true;

  // Ghi log nếu có
  if (typeof sendLog === "function") {
    sendLog("hongbao",
      `🧧 **${i.user.username}** nhận **${formatMoney(amount)}$** từ hồng bao của **${hb.creatorName}** | ID: \`${id}\``
    );
  }

  // Update message
  try {
    await i.message.edit({ embeds: [buildHongBaoEmbed(hb)], components: [buildHongBaoRow(hb)] });
  } catch {}

  // Ephemeral reply cho người nhận
  return i.reply({
    content: `🧧 Bạn nhận được **${formatMoney(amount)}$** từ hồng bao của **${hb.creatorName}**!`,
    ephemeral: true
  });
}

// ===================================================================
// SECTION: CLEANUP — dọn hồng bao cũ khỏi memory mỗi 1h
// ===================================================================
function startHongBaoCleanup() {
  setInterval(() => {
    const cutoff = Date.now() - 25 * 60 * 60 * 1000; // 25h
    for (const [id, hb] of hongbaoStore.entries()) {
      if (hb.createdAt < cutoff) hongbaoStore.delete(id);
    }
  }, 60 * 60 * 1000);
}

module.exports = { handleHongBao, handleHongBaoButton, startHongBaoCleanup };
