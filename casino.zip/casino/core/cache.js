'use strict';

const cfg = require('../config/config');

// ─────────────────────────────────────────────────────────────────────────────
// SlidingWindowCache — O(1) amortized per operation, auto-GC, no memory leaks
// ─────────────────────────────────────────────────────────────────────────────
class SlidingWindowCache {
  constructor() {
    this._map = new Map();           // key → { ts: number[], violations: number, meta: {} }
    this._lastGC = Date.now();
    this._gcInterval = cfg.performance.cacheCleanupMs;
    this._max = cfg.performance.maxCacheEntries;
    this._gc = cfg.performance.gcThreshold;
  }

  record(key, windowMs, meta = {}) {
    this._maybeGC();
    const now = Date.now();
    let e = this._map.get(key);
    if (!e) { e = { ts: [], violations: 0, meta: {} }; this._map.set(key, e); }
    e.ts = e.ts.filter(t => t > now - windowMs);
    e.ts.push(now);
    Object.assign(e.meta, meta);
    return e.ts.length;
  }

  count(key, windowMs) {
    const e = this._map.get(key);
    if (!e) return 0;
    const now = Date.now();
    return e.ts.filter(t => t > now - windowMs).length;
  }

  bump(key) {
    const e = this._map.get(key);
    if (e) e.violations++;
    return e ? e.violations : 0;
  }

  getViolations(key) { return this._map.get(key)?.violations ?? 0; }
  resetViolations(key) { const e = this._map.get(key); if (e) e.violations = 0; }
  getMeta(key) { return this._map.get(key)?.meta ?? {}; }
  setMeta(key, meta) {
    let e = this._map.get(key);
    if (!e) { e = { ts: [], violations: 0, meta: {} }; this._map.set(key, e); }
    Object.assign(e.meta, meta);
  }
  has(key) { return this._map.has(key); }
  del(key) { this._map.delete(key); }
  clearPrefix(prefix) { for (const k of this._map.keys()) if (k.startsWith(prefix)) this._map.delete(k); }
  get size() { return this._map.size; }

  _maybeGC() {
    const now = Date.now();
    if (now - this._lastGC < this._gcInterval && this._map.size < this._gc) return;
    this._lastGC = now;
    for (const [k, e] of this._map) {
      if (!e.ts.length && !e.violations) this._map.delete(k);
    }
    // Emergency eviction (LRU-approximate by insertion order)
    if (this._map.size > this._max) {
      const over = this._map.size - this._max;
      let i = 0;
      for (const k of this._map.keys()) {
        if (i++ >= over) break;
        this._map.delete(k);
      }
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// DuplicateTracker — trigram similarity, no external deps
// ─────────────────────────────────────────────────────────────────────────────
class DuplicateTracker {
  constructor() {
    this._hist = new Map(); // userId → [{ text, ts }]
    this._window = cfg.spam.duplicate.window;
    this._limit  = cfg.spam.duplicate.limit;
    this._thresh = cfg.spam.duplicate.similarity;
  }

  check(userId, content) {
    const now  = Date.now();
    const norm = this._norm(content);
    if (!this._hist.has(userId)) this._hist.set(userId, []);
    const hist = this._hist.get(userId).filter(e => now - e.ts < this._window);
    const sim  = hist.filter(e => this._sim(e.text, norm) >= this._thresh).length;
    hist.push({ text: norm, ts: now });
    this._hist.set(userId, hist.slice(-30));
    return sim + 1;
  }

  clear(userId) { this._hist.delete(userId); }

  _norm(s) { return s.toLowerCase().replace(/\s+/g, ' ').trim().slice(0, 200); }

  _sim(a, b) {
    if (a === b) return 1;
    if (a.length < 3 || b.length < 3) return 0;
    const ag = new Set(this._tri(a));
    const bg = this._tri(b);
    let inter = 0;
    for (const g of bg) if (ag.has(g)) inter++;
    return (2 * inter) / (ag.size + bg.length);
  }

  _tri(s) {
    const r = [];
    for (let i = 0; i < s.length - 2; i++) r.push(s.slice(i, i + 3));
    return r;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ViolationTracker — per-user server violation score with decay
// ─────────────────────────────────────────────────────────────────────────────
class ViolationTracker {
  constructor() {
    this._scores = new Map(); // guildId:userId → { score, ts, history[] }
    this._decayMs = 3600000; // score halves every hour
    this._interval = setInterval(() => this._decay(), 300000).unref();
  }

  add(guildId, userId, points, reason) {
    const key = `${guildId}:${userId}`;
    let e = this._scores.get(key);
    if (!e) { e = { score: 0, ts: Date.now(), history: [] }; this._scores.set(key, e); }
    e.score += points;
    e.ts = Date.now();
    e.history.push({ reason, points, ts: Date.now() });
    if (e.history.length > 20) e.history.shift();
    return e.score;
  }

  get(guildId, userId) {
    const e = this._scores.get(`${guildId}:${userId}`);
    return e?.score ?? 0;
  }

  reset(guildId, userId) { this._scores.delete(`${guildId}:${userId}`); }

  getHistory(guildId, userId) {
    return this._scores.get(`${guildId}:${userId}`)?.history ?? [];
  }

  _decay() {
    const now = Date.now();
    for (const [k, e] of this._scores) {
      const hrs = (now - e.ts) / this._decayMs;
      e.score = Math.max(0, e.score * Math.pow(0.5, hrs));
      if (e.score < 0.1) this._scores.delete(k);
    }
  }

  destroy() { clearInterval(this._interval); }
}

// ─────────────────────────────────────────────────────────────────────────────
// GuildState — per-guild runtime state (lockdown, panic, raid mode)
// ─────────────────────────────────────────────────────────────────────────────
class GuildState {
  constructor() {
    this._states = new Map();
  }

  get(guildId) {
    if (!this._states.has(guildId)) {
      this._states.set(guildId, {
        lockdown: false,
        panic: false,
        raidMode: false,
        raidModeTs: 0,
        lockdownTs: 0,
        panicTs: 0,
        antiraidEnabled: true,
        violations: 0,
        // channel permission snapshots for restore
        channelSnapshots: new Map(),
      });
    }
    return this._states.get(guildId);
  }

  setLockdown(guildId, val) { this.get(guildId).lockdown = val; this.get(guildId).lockdownTs = Date.now(); }
  setPanic(guildId, val)    { this.get(guildId).panic = val;    this.get(guildId).panicTs = Date.now(); }
  setRaidMode(guildId, val) { this.get(guildId).raidMode = val; this.get(guildId).raidModeTs = Date.now(); }
  isLockdown(guildId)       { return this.get(guildId).lockdown; }
  isPanic(guildId)          { return this.get(guildId).panic; }
  isRaidMode(guildId)       { return this.get(guildId).raidMode; }
  isEnabled(guildId)        { return this.get(guildId).antiraidEnabled; }
  setEnabled(guildId, val)  { this.get(guildId).antiraidEnabled = val; }
  bumpViolations(guildId)   { return ++this.get(guildId).violations; }
  resetViolations(guildId)  { this.get(guildId).violations = 0; }
}

// Singletons
const cache   = new SlidingWindowCache();
const dupTrack = new DuplicateTracker();
const violations = new ViolationTracker();
const guildState = new GuildState();

module.exports = { SlidingWindowCache, DuplicateTracker, ViolationTracker, GuildState, cache, dupTrack, violations, guildState };
