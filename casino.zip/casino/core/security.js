'use strict';

const { PermissionFlagsBits } = require('discord.js');
const cfg = require('../config/config');

class SecurityChecker {
  constructor(client) {
    this.client = client;
  }

  // Returns true → skip all moderation for this member
  isImmune(member) {
    if (!member) return true;
    if (member.user?.bot && this._isTrustedBot(member)) return true;
    if (this._isOwner(member.user?.id ?? member.id)) return true;
    if (member.id === member.guild?.ownerId) return true;
    if (cfg.security.trustedUsers.includes(member.id)) return true;
    const roles = member.roles?.cache;
    if (roles && cfg.security.trustedRoles.some(r => roles.has(r))) return true;
    for (const perm of cfg.security.immunePermissions) {
      if (member.permissions?.has(PermissionFlagsBits[perm])) return true;
    }
    return false;
  }

  isStaff(member) {
    if (!member) return false;
    if (this.isImmune(member)) return true;
    return cfg.security.staffRoles.some(r => member.roles?.cache?.has(r));
  }

  canModerate(guild, target) {
    const bot = guild.members.me;
    if (!bot) return false;
    if (target.id === guild.ownerId) return false;
    if (!target.roles?.highest) return true;
    return bot.roles.highest.comparePositionTo(target.roles.highest) > 0;
  }

  // Score a joining member for alt/fake account likelihood (0-100)
  altScore(member) {
    let score = 0;
    const ageDays = (Date.now() - member.user.createdTimestamp) / 86400000;
    const s = cfg.smart.altAccountScore;
    if (ageDays < 1)  score += s.newAccount * 2;
    else if (ageDays < 3)  score += Math.floor(s.newAccount * 1.5);
    else if (ageDays < 7)  score += s.newAccount;
    if (!member.user.avatar) score += s.noAvatar;
    if (/^[a-z]+\d{4}$/.test(member.user.username)) score += s.defaultUsername;
    return Math.min(score, 100);
  }

  _isOwner(userId) {
    if (!userId) return false;
    if (cfg.security.ownerIds.includes(userId)) return true;
    const app = this.client.application;
    if (!app) return false;
    if (app.owner?.id === userId) return true;
    if (app.owner?.members?.has(userId)) return true;
    return false;
  }

  _isTrustedBot(member) {
    // Discord-verified bots (blue checkmark) are somewhat trusted
    return member.user?.flags?.has('VerifiedBot') ?? false;
  }
}

module.exports = SecurityChecker;
