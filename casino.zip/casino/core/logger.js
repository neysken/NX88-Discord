'use strict';

const { EmbedBuilder, time, TimestampStyles } = require('discord.js');
const cfg = require('../config/config');

const EMOJI = {
  warn: '⚠️', timeout: '⏱️', kick: '👢', ban: '🔨', mute: '🔇',
  delete: '🗑️', lockdown: '🔒', unlock: '🔓', panic: '🚨',
  raid: '🛡️', nuke: '💣', info: 'ℹ️', resolved: '✅', webhook: '🪝',
};

class Logger {
  constructor(client) {
    this.client = client;
    this._q = [];
    this._flushing = false;
    this._timer = setInterval(() => this._flush(), cfg.logging.flushIntervalMs).unref();
  }

  // ── Public API ────────────────────────────────────────────────────────────

  action(guild, member, type, fields = {}, urgent = false) {
    this._enq(guild, {
      title: `${EMOJI[type] ?? '🛡️'} AntiRaid V2 — ${type.toUpperCase()}`,
      color: cfg.logging.colors[type] ?? cfg.logging.colors.info,
      member, fields, urgent,
    });
  }

  raidAlert(guild, type, stats = {}) {
    this._enq(guild, {
      title: `🚨 RAID DETECTED — ${type}`,
      color: cfg.logging.colors.raid,
      fields: stats,
      urgent: true,
    });
  }

  lockdown(guild, active, stats = {}) {
    this._enq(guild, {
      title: active ? '🔒 SERVER LOCKDOWN ACTIVATED' : '🔓 Server Unlocked',
      color: active ? cfg.logging.colors.lockdown : cfg.logging.colors.resolved,
      fields: stats,
      urgent: active,
    });
  }

  panic(guild, active) {
    this._enq(guild, {
      title: active ? '🚨 PANIC MODE ON' : '✅ Panic Mode Off',
      color: active ? cfg.logging.colors.panic : cfg.logging.colors.resolved,
      fields: {},
      urgent: active,
    });
  }

  bulk(guild, channel, count, reason) {
    this._enq(guild, {
      title: `🗑️ Bulk Delete — ${count} msgs`,
      color: cfg.logging.colors.info,
      fields: { Channel: `${channel}`, Count: `${count}`, Reason: reason },
    });
  }

  nuke(guild, executor, action) {
    this._enq(guild, {
      title: `💣 NUKE ATTEMPT — ${action}`,
      color: cfg.logging.colors.nuke,
      fields: executor ? { Executor: `${executor.user?.tag} (${executor.id})` } : {},
      urgent: true,
    });
  }

  // ── Internal ──────────────────────────────────────────────────────────────

  _enq(guild, payload) {
    if (this._q.length >= cfg.logging.maxQueueSize) this._q.shift(); // drop oldest
    this._q.push({ guild, payload, ts: Date.now() });
  }

  async _flush() {
    if (this._flushing || !this._q.length) return;
    this._flushing = true;
    const batch = this._q.splice(0, 6);
    for (const { guild, payload } of batch) {
      try { await this._send(guild, payload); }
      catch (e) { /* never crash on log failure */ }
    }
    this._flushing = false;
  }

  async _send(guild, { title, color, member, fields, urgent }) {
    const chId = this._resolveChannel(urgent);
    if (!chId) return;
    let ch;
    try { ch = await guild.channels.fetch(chId); } catch { return; }
    if (!ch?.isTextBased()) return;

    const embed = new EmbedBuilder().setTitle(title).setColor(color).setTimestamp();

    if (member) {
      const tag = member.user?.tag ?? member.tag ?? 'Unknown';
      const id  = member.id ?? member.user?.id ?? '?';
      embed.setDescription(`**User:** ${tag} (\`${id}\`)`);
      if (member.user?.displayAvatarURL)
        embed.setThumbnail(member.user.displayAvatarURL({ size: 64 }));
    }

    if (fields && Object.keys(fields).length) {
      embed.addFields(
        Object.entries(fields)
          .filter(([, v]) => v != null)
          .map(([k, v]) => ({ name: k, value: String(v).slice(0, 1024), inline: true }))
      );
    }

    embed.addFields({ name: 'Time', value: time(new Date(), TimestampStyles.LongDateTime), inline: true });
    await ch.send({ embeds: [embed] }).catch(() => {});
  }

  _resolveChannel(urgent) {
    const l = cfg.logging;
    if (urgent && l.raidAlertChannelId) return l.raidAlertChannelId;
    return l.modLogChannelId || l.logChannelId;
  }

  destroy() { clearInterval(this._timer); }
}

module.exports = Logger;
