'use strict';

const cfg = require('../config/config');

class BulkDeleter {
  constructor() {
    this._queue = [];
    this._running = false;
    this._activeChannels = new Set(); // prevent duplicate ops on same channel
  }

  // Queue a delete job, returns Promise<number> (deleted count)
  enqueue(channel, messages, reason = 'AntiRaid V2') {
    return new Promise((resolve, reject) => {
      this._queue.push({ channel, messages, reason, resolve, reject });
      this._drain();
    });
  }

  // Delete recent messages from specific users across ALL channels in guild
  async purgeUsersGuild(guild, userIds, limitPerChannel = 100) {
    if (!userIds?.length) return 0;
    const channels = guild.channels.cache.filter(c => c.isTextBased?.() && c.viewable);
    const arr = [...channels.values()];
    let total = 0;

    // Concurrent batches of N channels
    const N = cfg.bulkDelete.concurrentChannels;
    for (let i = 0; i < arr.length; i += N) {
      const batch = arr.slice(i, i + N);
      const results = await Promise.allSettled(
        batch.map(ch => this._purgeUsersInChannel(ch, userIds, limitPerChannel))
      );
      for (const r of results) if (r.status === 'fulfilled') total += r.value;
      if (i + N < arr.length) await this._sleep(600);
    }
    return total;
  }

  // Delete messages from specific users in one channel
  async purgeUsersChannel(channel, userIds, limit = 100) {
    return this._purgeUsersInChannel(channel, userIds, limit);
  }

  // Delete last N messages in channel regardless of author
  async nukeChannel(channel, limit = 100) {
    try {
      const msgs = await channel.messages.fetch({ limit: Math.min(limit, 100) });
      if (!msgs.size) return 0;
      return this.enqueue(channel, [...msgs.values()], 'AntiRaid: Channel Nuke');
    } catch { return 0; }
  }

  // ── Internal ──────────────────────────────────────────────────────────────

  async _purgeUsersInChannel(channel, userIds, limit) {
    try {
      if (!channel.viewable) return 0;
      const msgs = await channel.messages.fetch({ limit: Math.min(limit, 100) });
      const toDelete = msgs.filter(m => userIds.includes(m.author.id));
      if (!toDelete.size) return 0;
      return this.enqueue(channel, [...toDelete.values()], `AntiRaid: Purge ${userIds.join(',')}`);
    } catch { return 0; }
  }

  async _drain() {
    if (this._running || !this._queue.length) return;
    this._running = true;

    while (this._queue.length) {
      const job = this._queue.shift();
      try {
        const count = await this._execute(job);
        job.resolve(count);
      } catch (e) {
        job.reject(e);
      }
    }

    this._running = false;
  }

  async _execute({ channel, messages, reason }) {
    if (!messages?.length) return 0;

    const maxAge = cfg.bulkDelete.maxAgeDays * 86400000;
    const cutoff = Date.now() - maxAge;

    const fresh = [];
    const old   = [];
    for (const m of messages) {
      const ts = m.createdTimestamp ?? m.createdAt?.getTime() ?? 0;
      (ts > cutoff ? fresh : old).push(m);
    }

    let deleted = 0;

    // Bulk delete fresh messages in batches of 100
    for (let i = 0; i < fresh.length; i += cfg.bulkDelete.batchSize) {
      const batch = fresh.slice(i, i + cfg.bulkDelete.batchSize);
      try {
        if (batch.length === 1) {
          await batch[0].delete().catch(() => {});
          deleted++;
        } else {
          const ids = batch.map(m => m.id ?? m);
          const res = await channel.bulkDelete(ids, true).catch(() => null);
          deleted += res?.size ?? 0;
        }
      } catch (e) {
        if (e.code !== 50034) console.error('[BulkDeleter]', e.message);
      }
      if (i + cfg.bulkDelete.batchSize < fresh.length)
        await this._sleep(cfg.bulkDelete.delayMs);
    }

    // Single-delete old messages (rate-limit friendly)
    for (const m of old) {
      try { await m.delete().catch(() => {}); deleted++; }
      catch {}
      await this._sleep(350);
    }

    return deleted;
  }

  _sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
}

const bulkDeleter = new BulkDeleter();
module.exports = { BulkDeleter, bulkDeleter };
