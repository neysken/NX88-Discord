'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { guildState, violations } = require('../core/cache');
const cfg = require('../config/config');

// Build all AntiRaid V2 slash command definitions
const commandDefs = [

  new SlashCommandBuilder()
    .setName('antiraid')
    .setDescription('🛡️ Quản lý hệ thống Anti-Raid V2')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('on').setDescription('Bật Anti-Raid'))
    .addSubcommand(s => s.setName('off').setDescription('Tắt Anti-Raid'))
    .addSubcommand(s => s.setName('status').setDescription('Xem trạng thái hệ thống')),

  new SlashCommandBuilder()
    .setName('lockdown')
    .setDescription('🔒 Lockdown toàn bộ server ngay lập tức')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName('unlockdown')
    .setDescription('🔓 Mở khóa server')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName('panic')
    .setDescription('🚨 Kích hoạt PANIC MODE - bảo vệ tối đa')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName('panic-off')
    .setDescription('✅ Tắt Panic Mode')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('✅ Quản lý danh sách miễn trừ')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s =>
      s.setName('add-user')
        .setDescription('Thêm user vào whitelist')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    )
    .addSubcommand(s =>
      s.setName('remove-user')
        .setDescription('Xóa user khỏi whitelist')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    )
    .addSubcommand(s =>
      s.setName('add-role')
        .setDescription('Thêm role vào whitelist')
        .addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true))
    )
    .addSubcommand(s =>
      s.setName('remove-role')
        .setDescription('Xóa role khỏi whitelist')
        .addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true))
    )
    .addSubcommand(s => s.setName('list').setDescription('Xem danh sách whitelist')),

  new SlashCommandBuilder()
    .setName('logs')
    .setDescription('📋 Xem log Anti-Raid của user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption(o => o.setName('user').setDescription('User cần xem log').setRequired(false)),

];

// ── Command handler ────────────────────────────────────────────────────────

async function handleAntiRaidCommands(interaction, eventHandler) {
  if (!interaction.isChatInputCommand()) return false;

  const cmd = interaction.commandName;
  const sub = interaction.options.getSubcommand?.(false);

  switch (cmd) {

    // ── /antiraid ────────────────────────────────────────────────────────────
    case 'antiraid': {
      await interaction.deferReply({ ephemeral: true });

      if (sub === 'on') {
        eventHandler.enableAntiRaid(interaction.guildId);
        return interaction.editReply({
          embeds: [_embed('✅ Anti-Raid V2 BẬT', 0x00FF88,
            'Hệ thống bảo vệ đang hoạt động toàn bộ.')],
        });
      }

      if (sub === 'off') {
        eventHandler.disableAntiRaid(interaction.guildId);
        return interaction.editReply({
          embeds: [_embed('⚠️ Anti-Raid V2 TẮT', 0xFF6600,
            '⚠️ Server không còn được bảo vệ tự động!')],
        });
      }

      if (sub === 'status') {
        const state   = guildState.get(interaction.guildId);
        const enabled = state.antiraidEnabled;
        const embed   = new EmbedBuilder()
          .setTitle('🛡️ AntiRaid V2 — Status')
          .setColor(enabled ? 0x00FF88 : 0xFF6600)
          .setTimestamp()
          .addFields(
            { name: 'Anti-Raid',  value: enabled ? '✅ ON' : '❌ OFF', inline: true },
            { name: 'Lockdown',   value: state.lockdown ? '🔒 ACTIVE' : '🔓 Off', inline: true },
            { name: 'Panic Mode', value: state.panic ? '🚨 ACTIVE' : '✅ Off', inline: true },
            { name: 'Raid Mode',  value: state.raidMode ? '🛡️ ACTIVE' : '✅ Off', inline: true },
            { name: 'Server Violations', value: `${state.violations}`, inline: true },
            { name: 'Trusted Roles', value: `${cfg.security.trustedRoles.length} roles`, inline: true },
            { name: 'Trusted Users', value: `${cfg.security.trustedUsers.length} users`, inline: true },
          );
        return interaction.editReply({ embeds: [embed] });
      }
      break;
    }

    // ── /lockdown ────────────────────────────────────────────────────────────
    case 'lockdown': {
      await interaction.deferReply({ ephemeral: true });
      await eventHandler.manualLockdown(interaction.guild);
      return interaction.editReply({
        embeds: [_embed('🔒 Server Locked Down', 0x8B0000,
          `Tất cả kênh đã bị khóa.\nAuto-unlock sau ${cfg.lockdown.autoUnlockMs / 60000} phút.`)],
      });
    }

    // ── /unlockdown ───────────────────────────────────────────────────────────
    case 'unlockdown': {
      await interaction.deferReply({ ephemeral: true });
      await eventHandler.manualUnlock(interaction.guild);
      return interaction.editReply({
        embeds: [_embed('🔓 Server Unlocked', 0x00FF88, 'Server đã được mở khóa.')],
      });
    }

    // ── /panic ────────────────────────────────────────────────────────────────
    case 'panic': {
      await interaction.deferReply({ ephemeral: true });
      eventHandler.setPanic(interaction.guild, true);
      // Also trigger lockdown
      if (!guildState.isLockdown(interaction.guildId)) {
        await eventHandler.manualLockdown(interaction.guild);
      }
      return interaction.editReply({
        embeds: [_embed('🚨 PANIC MODE ACTIVATED', 0x000000,
          '🚨 Chế độ khẩn cấp đang hoạt động!\n• Server đã bị lockdown\n• Tài khoản mới sẽ bị kick tự động\n• Owner đã được thông báo')],
      });
    }

    // ── /panic-off ────────────────────────────────────────────────────────────
    case 'panic-off': {
      await interaction.deferReply({ ephemeral: true });
      eventHandler.setPanic(interaction.guild, false);
      // Tự động restore permissions về trạng thái ban đầu
      await eventHandler.manualUnlock(interaction.guild);
      return interaction.editReply({
        embeds: [_embed('✅ Panic Mode Deactivated', 0x00FF88,
          'Panic mode đã tắt.\n• Tất cả kênh đã được khôi phục quyền ban đầu\n• Server hoạt động bình thường trở lại')],
      });
    }

    // ── /whitelist ────────────────────────────────────────────────────────────
    case 'whitelist': {
      await interaction.deferReply({ ephemeral: true });

      if (sub === 'add-user') {
        const user = interaction.options.getUser('user');
        if (!cfg.security.trustedUsers.includes(user.id)) {
          cfg.security.trustedUsers.push(user.id);
        }
        return interaction.editReply({
          embeds: [_embed('✅ Whitelist Updated', 0x00FF88,
            `${user.tag} đã được thêm vào whitelist.\nBot sẽ bỏ qua hoàn toàn user này.`)],
        });
      }

      if (sub === 'remove-user') {
        const user = interaction.options.getUser('user');
        const idx  = cfg.security.trustedUsers.indexOf(user.id);
        if (idx > -1) cfg.security.trustedUsers.splice(idx, 1);
        return interaction.editReply({
          embeds: [_embed('✅ Whitelist Updated', 0xFFA500, `${user.tag} đã bị xóa khỏi whitelist.`)],
        });
      }

      if (sub === 'add-role') {
        const role = interaction.options.getRole('role');
        if (!cfg.security.trustedRoles.includes(role.id)) {
          cfg.security.trustedRoles.push(role.id);
        }
        return interaction.editReply({
          embeds: [_embed('✅ Whitelist Updated', 0x00FF88,
            `Role ${role.name} đã được thêm vào whitelist.`)],
        });
      }

      if (sub === 'remove-role') {
        const role = interaction.options.getRole('role');
        const idx  = cfg.security.trustedRoles.indexOf(role.id);
        if (idx > -1) cfg.security.trustedRoles.splice(idx, 1);
        return interaction.editReply({
          embeds: [_embed('✅ Whitelist Updated', 0xFFA500, `Role ${role.name} đã bị xóa khỏi whitelist.`)],
        });
      }

      if (sub === 'list') {
        const users = cfg.security.trustedUsers.map(id => `<@${id}>`).join(', ') || 'Trống';
        const roles = cfg.security.trustedRoles.map(id => `<@&${id}>`).join(', ') || 'Trống';
        return interaction.editReply({
          embeds: [new EmbedBuilder()
            .setTitle('✅ Whitelist — AntiRaid V2')
            .setColor(0x00AAFF)
            .addFields(
              { name: '👤 Trusted Users', value: users },
              { name: '🎭 Trusted Roles', value: roles },
            )
            .setTimestamp()],
        });
      }
      break;
    }

    // ── /logs ──────────────────────────────────────────────────────────────
    case 'logs': {
      await interaction.deferReply({ ephemeral: true });
      const user    = interaction.options.getUser('user');
      const guildId = interaction.guildId;

      if (user) {
        const history = violations.getHistory(guildId, user.id);
        const score   = violations.get(guildId, user.id);
        const lines   = history.length
          ? history.slice(-10).map(h => `• \`${h.reason}\` +${h.points}pts`).join('\n')
          : 'Không có vi phạm';
        return interaction.editReply({
          embeds: [new EmbedBuilder()
            .setTitle(`📋 Violation Log — ${user.tag}`)
            .setColor(score > 50 ? 0xFF0000 : score > 20 ? 0xFFA500 : 0x00FF88)
            .setDescription(lines)
            .addFields({ name: 'Total Score', value: `${Math.round(score)} pts`, inline: true })
            .setTimestamp()],
        });
      } else {
        // Server-wide state summary
        const state = guildState.get(guildId);
        return interaction.editReply({
          embeds: [new EmbedBuilder()
            .setTitle('📋 Server Log — AntiRaid V2')
            .setColor(0x00AAFF)
            .addFields(
              { name: 'Lockdown',        value: state.lockdown ? `🔒 Since ${new Date(state.lockdownTs).toLocaleTimeString()}` : 'Off', inline: true },
              { name: 'Panic',           value: state.panic    ? `🚨 Since ${new Date(state.panicTs).toLocaleTimeString()}` : 'Off', inline: true },
              { name: 'Raid Mode',       value: state.raidMode ? `🛡️ Since ${new Date(state.raidModeTs).toLocaleTimeString()}` : 'Off', inline: true },
              { name: 'Total Violations', value: `${state.violations}`, inline: true },
            )
            .setTimestamp()],
        });
      }
    }

    default:
      return false;
  }

  return true;
}

function _embed(title, color, desc) {
  return new EmbedBuilder().setTitle(title).setColor(color).setDescription(desc).setTimestamp();
}

module.exports = { commandDefs, handleAntiRaidCommands };
