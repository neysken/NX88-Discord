const {
  REST,
  Routes
} = require("discord.js");

const config =
  require("./config.json");

const rest = new REST({
  version: "10"
}).setToken(config.token);

(async () => {

  try {

    console.log(
      "🗑 Đang xóa slash commands cũ..."
    );

    await rest.put(

      Routes.applicationGuildCommands(
        config.clientId,
        config.guildId
      ),

      {
        body: []
      }

    );

    console.log(
      "✅ Đã xóa toàn bộ lệnh cũ!"
    );

  } catch (err) {

    console.error(err);

  }

})();