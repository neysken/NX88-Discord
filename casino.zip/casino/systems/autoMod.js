'use strict';

const { PermissionFlagsBits, ChannelType } = require('discord.js');
const cfg = require('../config/config');
const { cache, violations, guildState } = require('../core/cache');
const SecurityChecker = require('../core/security');
const Logger = require('../core/logger');
const { bulkDeleter } = require('../core/bulkDelete');

class AutoModerator {
  constructor(client) {
    this.client = client;
    this.security = new SecurityChecker(client);
    this.logger = new Logger(client);
    this._lockedChannels = new Map(); // channelId → { timer, snapshot }
  }

  // ── Main entry: decide & apply action based on score ─────────────────────

  async handle(member, reason, score = 10, messagesToDelete = []) {
    if (!member || !member.guild) return;
    if (this.security.isImmune(member)) return;
    if (!this.security.canModerate(member.guild, member)) return;
    if (!guildState.isEnabled(member.guild.id)) return;

    const gKey = `violations:${member.guild.id}:${member.id}`;
    const total = violations.add(member.guild.id, member.id, score, reason);
    const gv    = guildState.bumpViolations(member.guild.id);

    // Delete messages first (non-blocking)
    if (messagesToDelete.length) {
      const ch = messagesToDelete[0]?.channel;
      if (ch) {
        bulkDeleter.enqueue(ch, messagesToDelete, `AntiRaid: ${reason}`)
          .then(n => { if (n) this.logger.bulk(member.guild, ch, n, reason); })
          .catch(() => {});
      }
    }

    const { actions } = cfg;

    // Apply action based on accumulated violation score
    if (total >= actions.ban.threshold * 10) {
      await this._ban(member, reason, total);
    } else if (total >= actions.kick.threshold * 10) {
      await this._kick(member, reason, total);
    } else if (total >= actions.timeout.threshold * 10) {
      await this._timeout(member, reason, total);
    } else {
      await this._warn(member, reason, total);
    }

    // Set slowmode on member's channel if threshold crossed
    if (messagesToDelete.length && total >= actions.slowmode.threshold * 10) {
      const ch = messagesToDelete[0]?.channel;
      if (ch?.isTextBased()) await this._slowmode(ch, actions.slowmode.seconds);
    }

    // Trigger full lockdown if server violation count too high
    if (gv >= cfg.lockdown.triggerViolations && !guildState.isLockdown(member.guild.id)) {
      await this.lockdownServer(member.guild, `Auto: high violation count (${gv})`, true);
    }
  }

  // ── Server Lockdown ───────────────────────────────────────────────────────

  async lockdownServer(guild, reason = 'AntiRaid V2: Lockdown', withMessage = true) {
    if (guildState.isLockdown(guild.id)) return;
    guildState.setLockdown(guild.id, true);

    const state = guildState.get(guild.id);
    const evRole = guild.roles.everyone;
    const channels = guild.channels.cache.filter(c =>
      [ChannelType.GuildText, ChannelType.GuildForum, ChannelType.GuildAnnouncement].includes(c.type)
    );

    const lockPromises = [];
    for (const [, ch] of channels) {
      lockPromises.push(this._lockChannel(ch, evRole, state));
    }
    await Promise.allSettled(lockPromises);

    // Set server-wide slowmode via guild edit if possible
    try {
      if (guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
        // Cannot set server-wide slowmode via API but set on default channel
      }
    } catch {}

    this.logger.lockdown(guild, true, { Reason: reason, Channels: `${channels.size}` });

    if (withMessage) await this._broadcastLockdown(guild, reason);

    // Auto-unlock timer
    const dur = cfg.lockdown.autoUnlockMs;
    if (dur > 0) {
      const t = setTimeout(() => this.unlockServer(guild, 'Auto-unlock'), dur);
      t.unref();
    }
  }

  async unlockServer(guild, reason = 'AntiRaid V2: Unlock') {
    if (!guildState.isLockdown(guild.id)) return;
    guildState.setLockdown(guild.id, false);
    guildState.resetViolations(guild.id);

    const state = guildState.get(guild.id);
    const snapshots = state.channelSnapshots;

    const unlockPromises = [];
    for (const [chId, snap] of snapshots) {
      unlockPromises.push(this._restoreChannel(guild, chId, snap, reason));
    }
    await Promise.allSettled(unlockPromises);
    snapshots.clear();

    this.logger.lockdown(guild, false, { Reason: reason });
  }

  // ── Single Channel Lock ───────────────────────────────────────────────────

  async lockChannel(channel, reason = 'AntiRaid', durationMs = cfg.actions.lockChannel.autoUnlockMs) {
    const state = guildState.get(channel.guild.id);
    await this._lockChannel(channel, channel.guild.roles.everyone, state);
    this.logger.action(channel.guild, null, 'lockdown', { Channel: `${channel}`, Reason: reason });

    if (durationMs > 0 && !this._lockedChannels.has(channel.id)) {
      const t = setTimeout(() => this._unlockSingleChannel(channel), durationMs);
      t.unref();
      this._lockedChannels.set(channel.id, t);
    }
  }

  async _unlockSingleChannel(channel) {
    this._lockedChannels.delete(channel.id);
    try {
      const evRole = channel.guild.roles.everyone;
      await channel.permissionOverwrites.edit(evRole, {
        SendMessages: null, AddReactions: null,
        CreatePublicThreads: null, CreatePrivateThreads: null,
      }, { reason: 'AntiRaid: Auto-unlock' });
    } catch {}
  }

  // ── Actions ───────────────────────────────────────────────────────────────

  async _warn(member, reason, score) {
    try {
      await member.send(
        `⚠️ **Warning** | ${member.guild.name}\n**Reason:** ${reason}\n**Score:** ${Math.round(score)}\nFurther violations will escalate.`
      ).catch(() => {});
      this.logger.action(member.guild, member, 'warn', { Reason: reason, Score: `${Math.round(score)}` });
    } catch {}
  }

  async _timeout(member, reason, score) {
    try {
      const base = cfg.actions.timeout.baseSec * 1000;
      const mult = Math.min(Math.pow(2, Math.floor(score / 20)), 24);
      const dur  = Math.min(base * mult, cfg.actions.timeout.maxSec * 1000);
      await member.timeout(dur, `AntiRaid V2: ${reason}`);
      this.logger.action(member.guild, member, 'timeout', {
        Reason: reason, Duration: `${Math.round(dur / 1000)}s`, Score: `${Math.round(score)}`,
      });
    } catch (e) { console.error('[AutoMod] timeout:', e.message); }
  }

  async _kick(member, reason, score) {
    try {
      await member.kick(`AntiRaid V2: ${reason} (score:${Math.round(score)})`);
      this.logger.action(member.guild, member, 'kick', { Reason: reason, Score: `${Math.round(score)}` });
    } catch (e) { console.error('[AutoMod] kick:', e.message); }
  }

  async _ban(member, reason, score) {
    try {
      await member.ban({
        reason: `AntiRaid V2: ${reason} (score:${Math.round(score)})`,
        deleteMessageSeconds: cfg.actions.ban.delMsgDays * 86400,
      });
      this.logger.action(member.guild, member, 'ban', { Reason: reason, Score: `${Math.round(score)}` });
    } catch (e) { console.error('[AutoMod] ban:', e.message); }
  }

  async _slowmode(channel, seconds) {
    try {
      if (!channel.manageable) return;
      await channel.setRateLimitPerUser(seconds, 'AntiRaid: Slowmode');
    } catch {}
  }

  async _lockChannel(channel, evRole, state) {
    try {
      // Save snapshot
      const existing = channel.permissionOverwrites.cache.get(evRole.id);
      state.channelSnapshots.set(channel.id, {
        allow: existing?.allow.bitfield ?? 0n,
        deny:  existing?.deny.bitfield  ?? 0n,
      });
      await channel.permissionOverwrites.edit(evRole, {
        SendMessages: false, SendMessagesInThreads: false,
        AddReactions: false, CreatePublicThreads: false, CreatePrivateThreads: false,
      }, { reason: 'AntiRaid V2: Lockdown' });
    } catch {}
  }

  async _restoreChannel(guild, chId, snap, reason) {
    try {
      const ch = guild.channels.cache.get(chId) ?? await guild.channels.fetch(chId).catch(() => null);
      if (!ch) return;
      const evRole = guild.roles.everyone;

      // Nếu trước khi lock không có override nào → xóa override đi (trả về default)
      if (snap.allow === 0n && snap.deny === 0n) {
        await ch.permissionOverwrites.delete(evRole, reason).catch(() => {});
        return;
      }

      // Có override cũ → restore đúng bitfield ban đầu
      const { PermissionsBitField } = require('discord.js');
      const allowPerms = new PermissionsBitField(snap.allow);
      const denyPerms  = new PermissionsBitField(snap.deny);

      await ch.permissionOverwrites.edit(evRole, {
        SendMessages:            allowPerms.has('SendMessages')            ? true  : denyPerms.has('SendMessages')            ? false : null,
        SendMessagesInThreads:   allowPerms.has('SendMessagesInThreads')   ? true  : denyPerms.has('SendMessagesInThreads')   ? false : null,
        AddReactions:            allowPerms.has('AddReactions')            ? true  : denyPerms.has('AddReactions')            ? false : null,
        CreatePublicThreads:     allowPerms.has('CreatePublicThreads')     ? true  : denyPerms.has('CreatePublicThreads')     ? false : null,
        CreatePrivateThreads:    allowPerms.has('CreatePrivateThreads')    ? true  : denyPerms.has('CreatePrivateThreads')    ? false : null,
      }, { reason }).catch(() => {});
    } catch {}
  }

  async _broadcastLockdown(guild, reason) {
    const target = guild.channels.cache.find(c =>
      [ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(c.type) &&
      c.permissionsFor(guild.members.me)?.has(PermissionFlagsBits.SendMessages)
    );
    if (!target) return;
    try {
      await target.send({
        content: [
          '🔒 **SERVER LOCKDOWN ACTIVE**',
          `> **Reason:** ${reason}`,
          `> All channels locked. Bot is handling the threat.`,
          `> Auto-unlock in ${cfg.lockdown.autoUnlockMs / 60000} minutes.`,
        ].join('\n'),
      });
    } catch {}
  }

  // ── Notify owner ──────────────────────────────────────────────────────────

  async notifyOwner(guild, message) {
    try {
      const owner = await guild.fetchOwner();
      await owner.send(`🚨 **${guild.name}** — ${message}`).catch(() => {});
    } catch {}
  }

  destroy() { this.logger.destroy(); }
}

module.exports = AutoModerator;
