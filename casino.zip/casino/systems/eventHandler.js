'use strict';

const { AuditLogEvent, PermissionFlagsBits } = require('discord.js');
const SpamDetector  = require('../systems/spamDetector');
const RaidDetector  = require('../systems/raidDetector');
const AutoModerator = require('../systems/autoMod');
const Logger        = require('../core/logger');
const { bulkDeleter } = require('../core/bulkDelete');
const { cache, guildState } = require('../core/cache');
const cfg = require('../config/config');

// Severity → violation score map
const SCORE = {
  CRITICAL: 50,
  HIGH:     25,
  MEDIUM:   15,
  LOW:       8,
};

class EventHandler {
  constructor(client) {
    this.client   = client;
    this.spam     = new SpamDetector(client);
    this.raid     = new RaidDetector(client);
    this.autoMod  = new AutoModerator(client);
    this.logger   = new Logger(client);

    this._activeBulkOps = new Set();  // prevent double-delete on same channel
  }

  register() {
    const c = this.client;
    c.on('messageCreate',       m  => this._onMessage(m));
    c.on('guildMemberAdd',      m  => this._onJoin(m));
    c.on('guildMemberUpdate',   (o, n) => this._onMemberUpdate(o, n));
    c.on('channelCreate',       ch => this._onChannelCreate(ch));
    c.on('channelDelete',       ch => this._onChannelDelete(ch));
    c.on('roleCreate',          r  => this._onRoleCreate(r));
    c.on('guildMemberRemove',   m  => this._onMemberRemove(m));
    c.on('guildBanAdd',         b  => this._onBanAdd(b));
    c.on('webhookUpdate',       ch => this._onWebhookUpdate(ch));
    c.on('messageDelete',       m  => this._onMessageDelete(m));

    console.log('[AntiRaid V2] ✓ All event handlers registered');
    return this;
  }

  // ── Message ───────────────────────────────────────────────────────────────

  async _onMessage(msg) {
    if (!msg.guild || msg.author?.bot || !msg.member) return;
    if (!guildState.isEnabled(msg.guild.id)) return;

    try {
      const result = this.spam.analyze(msg);
      if (!result) return;

      const { type, severity, pending, message } = result;
      const score = SCORE[severity] ?? 10;

      // Log raid alert for critical severity
      if (severity === 'CRITICAL' || severity === 'HIGH') {
        this.logger.raidAlert(msg.guild, type, {
          User: `${msg.author.tag} (${msg.author.id})`,
          Detail: result.detail,
          Channel: `${msg.channel}`,
        });
      }

      // Delete the offending message immediately
      if (severity !== 'LOW') {
        await this._safeDelete(msg);
      }

      // Auto-mod action
      await this.autoMod.handle(
        msg.member, type, score,
        severity === 'CRITICAL' || severity === 'HIGH' ? pending : [msg]
      );

    } catch (e) {
      console.error('[AntiRaid V2] _onMessage:', e.message);
    }
  }

  // ── Member join ───────────────────────────────────────────────────────────

  async _onJoin(member) {
    if (!guildState.isEnabled(member.guild.id)) return;
    try {
      const result = this.raid.onMemberJoin(member);

      // Panic mode: kick immediately
      if (result.isPanic && guildState.isPanic(member.guild.id)) {
        const joinRate = cache.count(`join:${member.guild.id}`, 60000);
        if (joinRate > cfg.panic.maxJoinPerMin) {
          if (this.autoMod.security.canModerate(member.guild, member)) {
            await member.kick('AntiRaid V2: Panic mode - mass join').catch(() => {});
            this.logger.action(member.guild, member, 'kick', { Reason: 'PANIC MODE: Mass join' });
          }
          return;
        }
      }

      // Join raid
      if (result.type === 'JOIN_RAID') {
        await this.autoMod.lockdownServer(
          member.guild,
          `Join Raid (${result.joinCount} joins/${cfg.raid.joinSpike.window / 1000}s)`
        );
        if (cfg.panic.notifyOwner) {
          await this.autoMod.notifyOwner(
            member.guild,
            `🚨 Join RAID detected! ${result.joinCount} joins in ${cfg.raid.joinSpike.window / 1000}s`
          );
        }
      }

      // Suspicious join (alt account)
      if (result.type === 'SUSPICIOUS_JOIN' || result.altScore >= cfg.smart.suspiciousScore) {
        this.logger.action(member.guild, member, 'warn', {
          Reason: 'Suspicious join (alt score)',
          'Alt Score': `${result.altScore}/100`,
          'Account Age': `${Math.floor((Date.now() - member.user.createdTimestamp) / 86400000)}d`,
        });

        // In panic/raid mode, kick alts immediately
        if ((guildState.isPanic(member.guild.id) || guildState.isRaidMode(member.guild.id)) &&
            result.isNewAccount &&
            this.autoMod.security.canModerate(member.guild, member)) {
          await member.kick('AntiRaid V2: Suspicious new account during raid').catch(() => {});
        }
      }

    } catch (e) {
      console.error('[AntiRaid V2] _onJoin:', e.message);
    }
  }

  // ── Member update (nickname spam, role changes) ───────────────────────────

  async _onMemberUpdate(oldM, newM) {
    if (!guildState.isEnabled(newM.guild.id)) return;
    if (this.autoMod.security.isImmune(newM)) return;

    // Nickname spam
    if (oldM.nickname !== newM.nickname) {
      const result = this.raid.onNicknameChange(newM);
      if (result) {
        await this.autoMod.handle(newM, 'NICKNAME_SPAM', SCORE.MEDIUM);
      }
    }
  }

  // ── Channel create ────────────────────────────────────────────────────────

  async _onChannelCreate(channel) {
    if (!channel.guild || !guildState.isEnabled(channel.guild.id)) return;
    try {
      const executor = await this._getAuditExecutor(channel.guild, AuditLogEvent.ChannelCreate);
      const result   = this.raid.onChannelCreate(channel, executor);
      if (!result) return;

      if (executor && this.autoMod.security.canModerate(channel.guild, executor)) {
        await this.autoMod.handle(executor, 'CHANNEL_CREATE_RAID', SCORE.HIGH);
      }
      // Delete the spammed channel
      await channel.delete('AntiRaid V2: Channel spam').catch(() => {});

    } catch (e) { console.error('[AntiRaid V2] _onChannelCreate:', e.message); }
  }

  // ── Channel delete (nuke protection) ─────────────────────────────────────

  async _onChannelDelete(channel) {
    if (!channel.guild || !guildState.isEnabled(channel.guild.id)) return;
    try {
      const executor = await this._getAuditExecutor(channel.guild, AuditLogEvent.ChannelDelete);
      const result   = this.raid.onChannelDelete(channel, executor);
      if (!result) return;

      if (executor && this.autoMod.security.canModerate(channel.guild, executor)) {
        // Immediately ban nuker
        await this.autoMod.handle(executor, 'CHANNEL_DELETE_NUKE', SCORE.CRITICAL);
      }

    } catch (e) { console.error('[AntiRaid V2] _onChannelDelete:', e.message); }
  }

  // ── Role create ───────────────────────────────────────────────────────────

  async _onRoleCreate(role) {
    if (!role.guild || !guildState.isEnabled(role.guild.id)) return;
    try {
      const executor = await this._getAuditExecutor(role.guild, AuditLogEvent.RoleCreate);
      const result   = this.raid.onRoleCreate(role, executor);
      if (!result) return;

      if (executor && this.autoMod.security.canModerate(role.guild, executor)) {
        await this.autoMod.handle(executor, 'ROLE_CREATE_RAID', SCORE.HIGH);
      }
      await role.delete('AntiRaid V2: Role spam').catch(() => {});

    } catch (e) { console.error('[AntiRaid V2] _onRoleCreate:', e.message); }
  }

  // ── Member remove (mass kick detection) ──────────────────────────────────

  async _onMemberRemove(member) {
    if (!member.guild || !guildState.isEnabled(member.guild.id)) return;
    try {
      const executor = await this._getAuditExecutor(member.guild, AuditLogEvent.MemberKick, 4000);
      if (!executor) return;
      const result = this.raid.onMemberKick(member.guild, executor);
      if (!result) return;

      if (this.autoMod.security.canModerate(member.guild, executor)) {
        await this.autoMod.handle(executor, 'MASS_KICK', SCORE.CRITICAL);
      }

    } catch (e) { console.error('[AntiRaid V2] _onMemberRemove:', e.message); }
  }

  // ── Ban add (mass ban detection) ──────────────────────────────────────────

  async _onBanAdd(ban) {
    if (!ban.guild || !guildState.isEnabled(ban.guild.id)) return;
    try {
      const executor = await this._getAuditExecutor(ban.guild, AuditLogEvent.MemberBanAdd);
      if (!executor) return;
      const result = this.raid.onMemberBan(ban.guild, executor);
      if (!result) return;

      if (this.autoMod.security.canModerate(ban.guild, executor)) {
        await this.autoMod.handle(executor, 'MASS_BAN', SCORE.CRITICAL);
      }

    } catch (e) { console.error('[AntiRaid V2] _onBanAdd:', e.message); }
  }

  // ── Webhook update ────────────────────────────────────────────────────────

  async _onWebhookUpdate(channel) {
    if (!channel?.guild || !guildState.isEnabled(channel.guild.id)) return;
    try {
      const executor = await this._getAuditExecutor(channel.guild, AuditLogEvent.WebhookCreate);
      const result   = this.raid.onWebhookCreate(channel, executor);
      if (!result) return;

      if (executor && this.autoMod.security.canModerate(channel.guild, executor)) {
        await this.autoMod.handle(executor, 'WEBHOOK_RAID', SCORE.HIGH);
      }

      // Disable all webhooks in channel if possible
      if (cfg.webhook.autoDisableOnRaid) {
        try {
          const hooks = await channel.fetchWebhooks();
          await Promise.allSettled(hooks.map(h => h.delete('AntiRaid V2: Webhook raid')));
        } catch {}
      }

    } catch (e) { console.error('[AntiRaid V2] _onWebhookUpdate:', e.message); }
  }

  // ── Message delete (ghost ping detection) ────────────────────────────────

  async _onMessageDelete(msg) {
    if (!msg.guild || !msg.author || msg.author.bot) return;
    if (!msg.mentions?.users.size && !msg.mentions?.roles.size) return;
    if (this.autoMod.security.isImmune(msg.member)) return;

    const age = Date.now() - (msg.createdTimestamp ?? 0);
    if (age > 20000) return; // only flag if deleted within 20s

    const key = `ghostping:${msg.guild.id}:${msg.author.id}`;
    const cnt = cache.record(key, 30000);
    if (cnt >= 3 && msg.member) {
      this.logger.raidAlert(msg.guild, 'GHOST_PING', {
        User: `${msg.author.tag}`,
        Count: `${cnt}`,
      });
      await this.autoMod.handle(msg.member, 'GHOST_PING_SPAM', SCORE.MEDIUM);
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  async _safeDelete(msg) {
    try { if (msg.deletable) await msg.delete(); } catch {}
  }

  async _getAuditExecutor(guild, eventType, maxAgeMs = 5000) {
    try {
      if (!guild.members.me?.permissions.has(PermissionFlagsBits.ViewAuditLog)) return null;
      const logs  = await guild.fetchAuditLogs({ limit: 1, type: eventType });
      const entry = logs.entries.first();
      if (!entry) return null;
      if (Date.now() - entry.createdTimestamp > maxAgeMs) return null;
      return guild.members.cache.get(entry.executor.id)
        ?? await guild.members.fetch(entry.executor.id).catch(() => null);
    } catch { return null; }
  }

  // ── Public API for slash commands ─────────────────────────────────────────

  async manualLockdown(guild)   { await this.autoMod.lockdownServer(guild, 'Manual lockdown by staff'); }
  async manualUnlock(guild)     { await this.autoMod.unlockServer(guild, 'Manual unlock by staff'); }
  async enableAntiRaid(guildId) { guildState.setEnabled(guildId, true); }
  async disableAntiRaid(guildId){ guildState.setEnabled(guildId, false); }

  setPanic(guild, active) {
    guildState.setPanic(guild.id, active);
    this.logger.panic(guild, active);
    if (active && cfg.panic.notifyOwner) {
      this.autoMod.notifyOwner(guild, '🚨 PANIC MODE activated by staff!');
    }
  }

  destroy() {
    this.raid.destroy();
    this.autoMod.destroy();
    this.logger.destroy();
  }
}

module.exports = EventHandler;
