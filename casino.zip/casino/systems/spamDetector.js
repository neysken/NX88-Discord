'use strict';

const cfg = require('../config/config');
const { cache, dupTrack } = require('../core/cache');
const SecurityChecker = require('../core/security');

// Pre-compiled patterns (compiled once at startup for performance)
const RE_INVITE   = /discord(?:\.gg|app\.com\/invite|\.com\/invite)\/([a-zA-Z0-9-]+)/gi;
const RE_URL      = /https?:\/\/[^\s]+/gi;
const RE_EMOJI    = /<a?:[a-zA-Z0-9_]+:\d+>|[\u{1F300}-\u{1FAFF}]/gu;
const RE_MENTION  = /@(everyone|here)/g;
const RE_UNICODE  = /[^\u0000-\u007F]/g;
const RE_INVISIBLE = /[\u200B-\u200F\u2028-\u202F\u205F-\u206F\uFEFF\u00AD]/g;
const RE_EMBED_PREVIEW = /https?:\/\/\S+/g; // links that Discord auto-embeds

class SpamDetector {
  constructor(client) {
    this.client = client;
    this.security = new SecurityChecker(client);
    this._pending = new Map(); // userId → Message[]
  }

  // Returns DetectionResult | null
  analyze(message) {
    if (!message.guild || message.author?.bot || !message.member) return null;
    if (this.security.isImmune(message.member)) return null;

    this._track(message.author.id, message);

    return (
      this._checkMaliciousLinks(message)  ||
      this._checkScamDomains(message)     ||
      this._checkInviteLinks(message)     ||
      this._checkMassMention(message)     ||
      this._checkMessageSpam(message)     ||
      this._checkDuplicates(message)      ||
      this._checkEmojiSpam(message)       ||
      this._checkLinkSpam(message)        ||
      this._checkCommandSpam(message)     ||
      this._checkUnicodeSpam(message)     ||
      this._checkInvisibleChars(message)  ||
      this._checkMassEmbed(message)       ||
      null
    );
  }

  getPending(userId) { return this._pending.get(userId) ?? []; }
  clearPending(userId) { this._pending.delete(userId); }

  // ── Checks ────────────────────────────────────────────────────────────────

  _checkMaliciousLinks(msg) {
    const content = msg.content;
    for (const pat of cfg.smart.maliciousLinks) {
      pat.lastIndex = 0;
      if (pat.test(content)) return this._res('MALICIOUS_LINK', msg, 'CRITICAL', content.slice(0, 80));
    }
    return null;
  }

  _checkScamDomains(msg) {
    const urls = msg.content.match(RE_URL) ?? [];
    for (const url of urls) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        if (cfg.smart.scamDomains.some(d => host.includes(d)))
          return this._res('SCAM_DOMAIN', msg, 'CRITICAL', host);
      } catch {}
    }
    return null;
  }

  _checkInviteLinks(msg) {
    const matches = [...(msg.content.matchAll(RE_INVITE) ?? [])];
    if (!matches.length) return null;
    const key = `invite:${msg.guild.id}:${msg.author.id}`;
    const cnt = cache.record(key, cfg.spam.invite.window);
    if (cnt >= cfg.spam.invite.limit)
      return this._res('INVITE_SPAM', msg, 'HIGH', matches[0]?.[0]);
    return null;
  }

  _checkMassMention(msg) {
    const userM  = msg.mentions.users.size;
    const roleM  = msg.mentions.roles.size;
    const total  = userM + roleM;
    if (total >= cfg.spam.mention.limit)
      return this._res('MASS_MENTION', msg, 'CRITICAL', `${total} mentions`);

    const evM = (msg.content.match(RE_MENTION) ?? []).length;
    if (evM > 0) {
      const key = `evmention:${msg.guild.id}:${msg.author.id}`;
      const cnt = cache.record(key, cfg.spam.mention.window);
      if (cnt >= 3) return this._res('EVERYONE_SPAM', msg, 'HIGH', `${cnt}x @everyone/@here`);
    }
    return null;
  }

  _checkMessageSpam(msg) {
    const { message: ms, burst: bs } = cfg.spam;
    const key = `msg:${msg.guild.id}:${msg.author.id}`;
    const cnt = cache.record(key, ms.window);
    if (cnt >= bs.limit)
      return this._res('MESSAGE_BURST', msg, 'HIGH', `${cnt}/${bs.limit} msgs`);
    if (cnt >= ms.limit)
      return this._res('MESSAGE_SPAM', msg, 'MEDIUM', `${cnt} msgs/${ms.window/1000}s`);
    return null;
  }

  _checkDuplicates(msg) {
    if (msg.content.length < 5) return null;
    const cnt = dupTrack.check(msg.author.id, msg.content);
    if (cnt >= cfg.spam.duplicate.limit)
      return this._res('DUPLICATE_SPAM', msg, 'MEDIUM', `${cnt}x similar`);
    return null;
  }

  _checkEmojiSpam(msg) {
    const emojis = (msg.content.match(RE_EMOJI) ?? []).length;
    if (emojis < cfg.spam.emoji.limit) return null;
    const key = `emoji:${msg.guild.id}:${msg.author.id}`;
    const cnt = cache.record(key, cfg.spam.emoji.window);
    if (cnt >= 3) return this._res('EMOJI_SPAM', msg, 'LOW', `${emojis} emojis`);
    return null;
  }

  _checkLinkSpam(msg) {
    const urls = (msg.content.match(RE_URL) ?? []).length;
    if (!urls) return null;
    const key = `link:${msg.guild.id}:${msg.author.id}`;
    const cnt = cache.record(key, cfg.spam.link.window);
    if (cnt >= cfg.spam.link.limit)
      return this._res('LINK_SPAM', msg, 'MEDIUM', `${cnt} link msgs`);
    return null;
  }

  _checkCommandSpam(msg) {
    if (!/^[!/$?.>]/.test(msg.content)) return null;
    const key = `cmd:${msg.guild.id}:${msg.author.id}`;
    const cnt = cache.record(key, cfg.spam.command.window);
    if (cnt >= cfg.spam.command.limit)
      return this._res('COMMAND_SPAM', msg, 'LOW', `${cnt} commands`);
    return null;
  }

  _checkUnicodeSpam(msg) {
    const { unicode } = cfg.spam;
    if (msg.content.length < unicode.minLen) return null;
    const uCount = (msg.content.match(RE_UNICODE) ?? []).length;
    const ratio  = uCount / msg.content.length;
    if (ratio >= unicode.ratio)
      return this._res('UNICODE_SPAM', msg, 'LOW', `${Math.round(ratio * 100)}% unicode`);
    return null;
  }

  _checkInvisibleChars(msg) {
    if (!cfg.spam.invisible.enabled) return null;
    const inv = (msg.content.match(RE_INVISIBLE) ?? []).length;
    if (inv >= 5) return this._res('INVISIBLE_CHARS', msg, 'MEDIUM', `${inv} invisible chars`);
    return null;
  }

  _checkMassEmbed(msg) {
    const links = (msg.content.match(RE_EMBED_PREVIEW) ?? []).length;
    if (!links) return null;
    const key = `embed:${msg.guild.id}:${msg.author.id}`;
    const cnt = cache.record(key, cfg.spam.embed.window);
    if (cnt >= cfg.spam.embed.limit)
      return this._res('EMBED_SPAM', msg, 'LOW', `${cnt} embed msgs`);
    return null;
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  _res(type, msg, severity, detail) {
    return {
      type, severity, detail,
      message: msg,
      userId: msg.author.id,
      guildId: msg.guild.id,
      pending: this.getPending(msg.author.id),
    };
  }

  _track(userId, msg) {
    if (!this._pending.has(userId)) this._pending.set(userId, []);
    const arr = this._pending.get(userId);
    arr.push(msg);
    if (arr.length > 50) arr.shift();
  }
}

module.exports = SpamDetector;
