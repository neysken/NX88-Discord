'use strict';

const cfg = require('../config/config');
const { cache, guildState } = require('../core/cache');
const SecurityChecker = require('../core/security');
const Logger = require('../core/logger');

class RaidDetector {
  constructor(client) {
    this.client = client;
    this.security = new SecurityChecker(client);
    this.logger = new Logger(client);
    this._raidTimers = new Map(); // guildId → timeout
    this._joinBatch = new Map();  // guildId → [{ member, ts }]
  }

  // ── Member join ───────────────────────────────────────────────────────────

  onMemberJoin(member) {
    const { guild } = member;
    const { joinSpike, newAccount } = cfg.raid;
    const altScore = this.security.altScore(member);

    // Track join batch
    if (!this._joinBatch.has(guild.id)) this._joinBatch.set(guild.id, []);
    const batch = this._joinBatch.get(guild.id);
    batch.push({ member, ts: Date.now(), altScore });

    // Prune old joins
    const cutoff = Date.now() - joinSpike.window;
    const fresh  = batch.filter(e => e.ts > cutoff);
    this._joinBatch.set(guild.id, fresh);

    const key = `join:${guild.id}`;
    const cnt = cache.record(key, joinSpike.window);

    const isRaidJoin   = cnt >= joinSpike.limit;
    const isSuspicious = altScore >= cfg.smart.suspiciousScore;
    const isPanic      = guildState.isPanic(guild.id);

    if (isRaidJoin && !guildState.isRaidMode(guild.id)) {
      this._activateRaidMode(guild, { joinCount: cnt, window: joinSpike.window });
    }

    return {
      type: isRaidJoin ? 'JOIN_RAID' : (isSuspicious ? 'SUSPICIOUS_JOIN' : 'NORMAL'),
      member, altScore,
      isNewAccount: (Date.now() - member.user.createdTimestamp) / 86400000 < newAccount.ageDays,
      joinCount: cnt,
      isPanic,
    };
  }

  // ── Channel create ────────────────────────────────────────────────────────

  onChannelCreate(channel, executor) {
    if (!channel.guild) return null;
    if (executor && this.security.isImmune(executor)) return null;
    const { channelCreate } = cfg.raid;
    const key = `chancreate:${channel.guild.id}:${executor?.id ?? 'x'}`;
    const cnt = cache.record(key, channelCreate.window);
    if (cnt >= channelCreate.limit) {
      this.logger.nuke(channel.guild, executor, 'CHANNEL_CREATE_SPAM');
      return { type: 'CHANNEL_CREATE_RAID', guild: channel.guild, executor, count: cnt };
    }
    return null;
  }

  // ── Channel delete ────────────────────────────────────────────────────────

  onChannelDelete(channel, executor) {
    if (!channel.guild) return null;
    if (executor && this.security.isImmune(executor)) return null;
    const { nukeAttempt } = cfg.raid;
    const key = `chandelete:${channel.guild.id}:${executor?.id ?? 'x'}`;
    const cnt = cache.record(key, nukeAttempt.window);
    if (cnt >= nukeAttempt.channelDelete) {
      this.logger.nuke(channel.guild, executor, 'CHANNEL_DELETE_NUKE');
      return { type: 'CHANNEL_DELETE_NUKE', guild: channel.guild, executor, count: cnt };
    }
    return null;
  }

  // ── Role create ───────────────────────────────────────────────────────────

  onRoleCreate(role, executor) {
    if (!role.guild) return null;
    if (executor && this.security.isImmune(executor)) return null;
    const { roleCreate } = cfg.raid;
    const key = `rolecreate:${role.guild.id}:${executor?.id ?? 'x'}`;
    const cnt = cache.record(key, roleCreate.window);
    if (cnt >= roleCreate.limit) {
      this.logger.nuke(role.guild, executor, 'ROLE_CREATE_SPAM');
      return { type: 'ROLE_CREATE_RAID', guild: role.guild, executor, count: cnt };
    }
    return null;
  }

  // ── Mass kick / ban ───────────────────────────────────────────────────────

  onMemberKick(guild, executor) {
    if (!executor || this.security.isImmune(executor)) return null;
    const { massKick } = cfg.raid;
    const key = `kick:${guild.id}:${executor.id}`;
    const cnt = cache.record(key, massKick.window);
    if (cnt >= massKick.limit) {
      this.logger.nuke(guild, executor, 'MASS_KICK');
      return { type: 'MASS_KICK', guild, executor, count: cnt };
    }
    return null;
  }

  onMemberBan(guild, executor) {
    if (!executor || this.security.isImmune(executor)) return null;
    const { massBan } = cfg.raid;
    const key = `ban:${guild.id}:${executor.id}`;
    const cnt = cache.record(key, massBan.window);
    if (cnt >= massBan.limit) {
      this.logger.nuke(guild, executor, 'MASS_BAN');
      return { type: 'MASS_BAN', guild, executor, count: cnt };
    }
    return null;
  }

  // ── Webhook ───────────────────────────────────────────────────────────────

  onWebhookCreate(channel, executor) {
    if (!channel?.guild) return null;
    if (executor && this.security.isImmune(executor)) return null;
    const { webhookCreate } = cfg.raid;
    const key = `webhook:${channel.guild.id}:${executor?.id ?? 'x'}`;
    const cnt = cache.record(key, webhookCreate.window);
    if (cnt >= webhookCreate.limit) {
      this.logger.raidAlert(channel.guild, 'WEBHOOK_RAID', {
        Count: `${cnt}`, Channel: `${channel}`,
        Executor: executor ? `${executor.user?.tag} (${executor.id})` : 'Unknown',
      });
      return { type: 'WEBHOOK_RAID', guild: channel.guild, executor, count: cnt };
    }
    return null;
  }

  // ── Nickname spam ─────────────────────────────────────────────────────────

  onNicknameChange(member) {
    if (!member.guild) return null;
    if (this.security.isImmune(member)) return null;
    const key = `nick:${member.guild.id}:${member.id}`;
    const cnt = cache.record(key, cfg.spam.nickname.window);
    if (cnt >= cfg.spam.nickname.limit) {
      return { type: 'NICKNAME_SPAM', member, count: cnt };
    }
    return null;
  }

  // ── Raid mode ─────────────────────────────────────────────────────────────

  isRaidMode(guildId) { return guildState.isRaidMode(guildId); }

  _activateRaidMode(guild, stats) {
    guildState.setRaidMode(guild.id, true);
    this.logger.raidAlert(guild, 'JOIN_RAID', {
      'Join Count': `${stats.joinCount}`,
      Window: `${stats.window / 1000}s`,
    });

    // Auto deactivate after lockdown duration
    const prev = this._raidTimers.get(guild.id);
    if (prev) clearTimeout(prev);
    const t = setTimeout(() => {
      guildState.setRaidMode(guild.id, false);
      this.logger.raidAlert(guild, 'RAID_MODE_EXPIRED', { Duration: `${cfg.lockdown.autoUnlockMs / 1000}s` });
    }, cfg.lockdown.autoUnlockMs);
    t.unref();
    this._raidTimers.set(guild.id, t);
  }

  deactivateRaidMode(guildId) {
    guildState.setRaidMode(guildId, false);
    const t = this._raidTimers.get(guildId);
    if (t) { clearTimeout(t); this._raidTimers.delete(guildId); }
  }

  destroy() {
    for (const t of this._raidTimers.values()) clearTimeout(t);
    this._raidTimers.clear();
    this.logger.destroy();
  }
}

module.exports = RaidDetector;
